import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import Footer from './components/Footer.jsx';
import Home from './pages/Home.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Categories from './pages/Categories.jsx';
import CategoryDetails from './pages/CategoryDetails.jsx';
import Quiz from './pages/Quiz.jsx';
import PracticeQuiz from './pages/PracticeQuiz.jsx';
import Result from './pages/Result.jsx';
import Review from './pages/Review.jsx';
import Progress from './pages/Progress.jsx';
import Topics from './pages/Topics.jsx';
import MyMistakes from './pages/MyMistakes.jsx';
import Roadmap from './pages/Roadmap.jsx';
import Interview from './pages/Interview.jsx';
import Debugging from './pages/Debugging.jsx';
import Coding from './pages/Coding.jsx';
import Companies from './pages/Companies.jsx';
import CompanyDetail from './pages/CompanyDetail.jsx';
import StudyCoach from './pages/StudyCoach.jsx';
import NotFound from './pages/NotFound.jsx';

function App() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/categories" element={<Categories />} />
          <Route path="/category/:category" element={<CategoryDetails />} />
          <Route path="/quiz/:category/:difficulty" element={<Quiz />} />
          <Route path="/practice/:mode" element={<PracticeQuiz />} />
          <Route path="/result" element={<Result />} />
          <Route path="/review" element={<Review />} />
          <Route path="/progress" element={<Progress />} />
          <Route path="/topics" element={<Topics />} />
          <Route path="/mistakes" element={<MyMistakes />} />
          <Route path="/roadmap" element={<Roadmap />} />
          <Route path="/interview" element={<Interview />} />
          <Route path="/debugging" element={<Debugging />} />
          <Route path="/coding" element={<Coding />} />
          <Route path="/companies" element={<Companies />} />
          <Route path="/companies/:slug" element={<CompanyDetail />} />
          <Route path="/coach" element={<StudyCoach />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;
