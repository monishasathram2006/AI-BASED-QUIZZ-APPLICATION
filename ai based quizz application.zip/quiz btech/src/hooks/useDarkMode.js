import { useEffect } from 'react';
import { useLocalStorage } from './useLocalStorage.js';

export function useDarkMode() {
  const [isDark, setIsDark] = useLocalStorage('codeprep_dark_mode', false);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDark);
  }, [isDark]);

  return [isDark, setIsDark];
}
