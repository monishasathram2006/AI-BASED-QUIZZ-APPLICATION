import { Link } from 'react-router-dom';
import { companies } from '../data/companies.js';
import { getBucketAccuracy } from '../utils/progressStorage.js';

function overallReadiness(company) {
  const scores = company.focusAreas.map((area) => getBucketAccuracy(area)).filter((v) => v !== null);
  if (scores.length === 0) return null;
  return Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
}

export default function Companies() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl dark:text-white">Company Preparation</h1>
        <p className="mt-2 text-slate-500 dark:text-slate-400">
          A Preparation Score for each company, estimated from your real quiz performance in the areas they
          emphasize. This is a readiness estimate, not a guarantee of hiring outcomes.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {companies.map((company) => {
          const readiness = overallReadiness(company);
          return (
            <Link
              key={company.slug}
              to={`/companies/${company.slug}`}
              className="focus-ring flex flex-col items-center rounded-2xl border border-slate-200 bg-white p-6 text-center shadow-sm transition hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
            >
              <span className="text-4xl">{company.icon}</span>
              <span className="mt-3 text-lg font-bold text-slate-900 dark:text-white">{company.name}</span>
              <span className="mt-2 text-2xl font-extrabold text-indigo-600 dark:text-indigo-400">
                {readiness === null ? '—' : `${readiness}%`}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                {readiness === null ? 'Not started' : 'Preparation Score'}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
