import { Link } from 'react-router-dom';
import { getMistakeQuestions } from '../utils/progressStorage.js';

export default function MyMistakes() {
  const grouped = getMistakeQuestions();
  const categories = Object.keys(grouped);
  const totalMistakes = categories.reduce(
    (sum, cat) => sum + Object.values(grouped[cat]).reduce((s, arr) => s + arr.length, 0),
    0
  );

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl dark:text-white">My Mistakes</h1>
          <p className="mt-2 text-slate-500 dark:text-slate-400">
            Questions you've previously gotten wrong, grouped by category and topic.
          </p>
        </div>
        {totalMistakes > 0 && (
          <Link
            to="/practice/mistakes"
            className="focus-ring rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-700"
          >
            Practice My Mistakes
          </Link>
        )}
      </div>

      {categories.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center dark:border-slate-800">
          <span className="text-4xl">🎉</span>
          <h3 className="mt-3 text-lg font-bold text-slate-900 dark:text-white">No mistakes recorded yet</h3>
          <p className="mx-auto mt-1 max-w-md text-sm text-slate-500 dark:text-slate-400">
            Great job! Keep taking quizzes, and any missed questions will automatically be gathered here for targeted revision.
          </p>
          <Link
            to="/categories"
            className="focus-ring mt-5 inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-700"
          >
            Explore Quiz Categories
          </Link>
        </div>
      ) : (
        <div className="space-y-5">
          {categories.map((category) => (
            <div key={category} className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">{category}</h2>
              <div className="mt-3 space-y-2">
                {Object.entries(grouped[category]).map(([topic, items]) => (
                  <div
                    key={topic}
                    className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950/40"
                  >
                    <span className="font-medium text-slate-700 dark:text-slate-300">├── {topic}</span>
                    <span className="rounded-full bg-red-100 px-2.5 py-1 text-xs font-semibold text-red-700 dark:bg-red-500/10 dark:text-red-400">
                      {items.length} wrong
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
