import { useEffect, useRef } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { useQuiz } from '../hooks/useQuiz.js';
import { getCategoryBySlug } from '../data/categories.js';
import { questionBank } from '../data/questionBank.js';
import {
  selectQuizQuestions,
  difficultyParamToLabel,
  TIMER_MINUTES,
  computeQuizResult,
} from '../utils/quizUtils.js';
import { selectAdaptiveQuestions } from '../utils/adaptiveQuiz.js';
import { getTopicStats, recordQuizCompletion } from '../utils/progressStorage.js';
import { saveLastResult } from '../services/progressService.js';
import QuizRunner from '../components/Quiz/QuizRunner.jsx';

export default function Quiz() {
  const { category: slug, difficulty: difficultyParam } = useParams();
  const navigate = useNavigate();
  const quiz = useQuiz();
  const { state } = quiz;

  const category = getCategoryBySlug(slug);
  const difficultyLabel = difficultyParamToLabel(difficultyParam);
  const isValidRoute = Boolean(category && difficultyLabel);

  const hasInitialized = useRef(false);

  // Start a fresh quiz session, or leave an already-resumed matching
  // session (restored from localStorage on refresh) untouched (#30).
  useEffect(() => {
    if (!isValidRoute) return;
    hasInitialized.current = false;
  }, [slug, difficultyParam, isValidRoute]);

  useEffect(() => {
    if (!isValidRoute || hasInitialized.current) return;

    const alreadyResumed =
      state.status === 'active' && state.categorySlug === slug && state.difficultyParam === difficultyParam;

    if (!alreadyResumed) {
      const topicStats = getTopicStats(category.name)[category.name];
      const questions = selectAdaptiveQuestions(questionBank, category.name, difficultyLabel, topicStats);
      if (questions.length > 0) {
        quiz.startQuiz({
          categorySlug: slug,
          categoryName: category.name,
          difficultyParam,
          difficultyLabel,
          questions,
          totalSeconds: TIMER_MINUTES[difficultyLabel] * 60,
        });
      }
    }
    hasInitialized.current = true;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isValidRoute, slug, difficultyParam]);

  const handleSubmit = useRef(() => {});
  handleSubmit.current = () => {
    if (state.status !== 'active') return;
    const elapsed = Math.min(
      state.totalSeconds,
      Math.round((Date.now() - new Date(state.startedAt).getTime()) / 1000)
    );
    const result = computeQuizResult(state.questions, state.answers, elapsed);

    const completion = recordQuizCompletion({
      questions: state.questions,
      answers: state.answers,
      result,
      category: state.categoryName,
      difficulty: state.difficultyLabel,
      mode: 'quiz',
    });

    saveLastResult({
      category: state.categoryName,
      categorySlug: state.categorySlug,
      difficulty: state.difficultyLabel,
      ...result,
      ...completion,
    });

    quiz.submit();
    quiz.reset();
    navigate('/result', { replace: true });
  };

  // Ticks once per second while the quiz is active; stops automatically
  // once the session is submitted/reset. Independent of question
  // navigation so switching questions never resets the countdown.
  useEffect(() => {
    if (state.status !== 'active') return undefined;
    const id = setInterval(() => quiz.tick(), 1000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.status]);

  useEffect(() => {
    if (state.status === 'active' && state.remainingSeconds <= 0) {
      handleSubmit.current();
    }
  }, [state.status, state.remainingSeconds]);

  if (!isValidRoute) {
    return (
      <ErrorState
        title="Quiz not available"
        message="This category or difficulty level doesn't exist."
      />
    );
  }

  if (state.status !== 'active' || state.categorySlug !== slug || state.difficultyParam !== difficultyParam) {
    const questionsExist = selectQuizQuestions(questionBank, category.name, difficultyLabel).length > 0;
    if (!questionsExist) {
      return (
        <ErrorState
          title="No questions available"
          message={`We don't have any ${difficultyLabel} questions for ${category.name} yet.`}
        />
      );
    }
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <p className="text-slate-500 dark:text-slate-400">Preparing your quiz...</p>
      </div>
    );
  }

  return (
    <QuizRunner
      headerContent={
        <p className="text-lg font-bold text-slate-900 dark:text-white">
          {category.name} <span className="text-slate-300 dark:text-slate-600">|</span> {state.difficultyLabel}
        </p>
      }
      onSubmit={() => handleSubmit.current()}
    />
  );
}

function ErrorState({ title, message }) {
  return (
    <div className="mx-auto max-w-xl px-4 py-24 text-center">
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{title}</h1>
      <p className="mt-2 text-slate-500 dark:text-slate-400">{message}</p>
      <Link to="/categories" className="focus-ring mt-6 inline-block rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700">
        Browse Categories
      </Link>
    </div>
  );
}
