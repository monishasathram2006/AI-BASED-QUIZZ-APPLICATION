import { useEffect, useRef } from 'react';
import { useNavigate, useParams, useSearchParams, Link } from 'react-router-dom';
import { useQuiz } from '../hooks/useQuiz.js';
import { questionBank } from '../data/questionBank.js';
import { computeQuizResult } from '../utils/quizUtils.js';
import { getMistakeQuestionList, getWeakTopics, recordQuizCompletion } from '../utils/progressStorage.js';
import { getTodaysChallenge, getDailyChallengeState, recordDailyChallengeCompletion } from '../utils/dailyChallenge.js';
import { saveLastResult } from '../services/progressService.js';
import QuizRunner from '../components/Quiz/QuizRunner.jsx';

const MODE_LABELS = {
  mistakes: 'Practice: My Mistakes',
  weak: 'Practice: Weak Areas',
  daily: "Practice: Today's Challenge",
};

function buildWeakAreaQuestions(category, topic) {
  if (category && topic) {
    const directMatches = questionBank.filter(
      (q) => q.category === category && q.topic.toLowerCase() === topic.toLowerCase()
    );
    if (directMatches.length > 0) return directMatches;
    const categoryMatches = questionBank.filter((q) => q.category === category);
    if (categoryMatches.length > 0) return categoryMatches.slice(0, 10);
  }
  if (category) {
    const categoryMatches = questionBank.filter((q) => q.category === category);
    if (categoryMatches.length > 0) return categoryMatches.slice(0, 10);
  }
  const weakTopics = getWeakTopics(category ? 20 : 5, 1).filter((w) => !category || w.category === category);
  if (weakTopics.length > 0) {
    const wanted = new Set(weakTopics.map((w) => `${w.category}::${w.topic}`));
    const matches = questionBank.filter((q) => wanted.has(`${q.category}::${q.topic}`));
    if (matches.length > 0) return matches.slice(0, 10);
  }
  return questionBank.slice(0, 10);
}

export default function PracticeQuiz() {
  const { mode } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const quiz = useQuiz();
  const { state } = quiz;

  const category = searchParams.get('category');
  const topic = searchParams.get('topic');

  const hasInitialized = useRef(false);
  const emptyRef = useRef(false);
  const dailyAlreadyDoneRef = useRef(false);

  useEffect(() => {
    hasInitialized.current = false;
  }, [mode, category, topic]);

  useEffect(() => {
    if (hasInitialized.current) return;
    hasInitialized.current = true;

    const alreadyResumed = state.status === 'active' && state.categorySlug === 'practice' && state.difficultyParam === mode;
    if (alreadyResumed) return;

    if (mode === 'daily') {
      if (getDailyChallengeState().completed) {
        dailyAlreadyDoneRef.current = true;
        return;
      }
      const question = getTodaysChallenge();
      quiz.startQuiz({
        categorySlug: 'practice',
        categoryName: MODE_LABELS.daily,
        difficultyParam: mode,
        difficultyLabel: 'Daily Challenge',
        questions: [question],
        totalSeconds: 120,
      });
      return;
    }

    const questions = mode === 'mistakes' ? getMistakeQuestionList() : buildWeakAreaQuestions(category, topic);
    if (questions.length === 0) {
      emptyRef.current = true;
      return;
    }

    quiz.startQuiz({
      categorySlug: 'practice',
      categoryName: MODE_LABELS[mode] ?? 'Practice',
      difficultyParam: mode,
      difficultyLabel: 'Practice',
      questions,
      totalSeconds: Math.max(300, questions.length * 60),
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, category, topic]);

  const handleSubmit = useRef(() => {});
  handleSubmit.current = () => {
    if (state.status !== 'active') return;
    const elapsed = Math.min(
      state.totalSeconds,
      Math.round((Date.now() - new Date(state.startedAt).getTime()) / 1000)
    );
    const result = computeQuizResult(state.questions, state.answers, elapsed);

    const isDaily = mode === 'daily';
    const singleQuestion = isDaily ? state.questions[0] : null;

    const completion = recordQuizCompletion({
      questions: state.questions,
      answers: state.answers,
      result,
      category: isDaily ? singleQuestion.category : null,
      difficulty: isDaily ? singleQuestion.difficulty : null,
      mode: isDaily ? 'daily' : 'practice',
    });

    if (isDaily) {
      recordDailyChallengeCompletion({ correct: result.correct, xpAwarded: completion.xpGained });
    }

    saveLastResult({
      category: state.categoryName,
      categorySlug: state.categorySlug,
      difficulty: state.difficultyLabel,
      ...result,
      ...completion,
    });

    quiz.submit();
    quiz.reset();
    navigate('/result', { replace: true });
  };

  useEffect(() => {
    if (state.status !== 'active') return undefined;
    const id = setInterval(() => quiz.tick(), 1000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.status]);

  useEffect(() => {
    if (state.status === 'active' && state.remainingSeconds <= 0) {
      handleSubmit.current();
    }
  }, [state.status, state.remainingSeconds]);

  if (dailyAlreadyDoneRef.current) {
    return (
      <EmptyState
        title="Today's challenge is done!"
        message="You've already completed today's challenge. Come back tomorrow for a new one."
        ctaTo="/dashboard"
        ctaLabel="Back to Dashboard"
      />
    );
  }

  if (emptyRef.current) {
    return (
      <EmptyState
        title={mode === 'mistakes' ? 'No mistakes to practice yet' : 'Not enough data yet'}
        message={
          mode === 'mistakes'
            ? "You haven't gotten any questions wrong yet — keep it up!"
            : 'Complete a few quizzes first so weak areas can be identified.'
        }
        ctaTo="/categories"
        ctaLabel="Start a Quiz"
      />
    );
  }

  if (state.status !== 'active' || state.categorySlug !== 'practice' || state.difficultyParam !== mode) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <p className="text-slate-500 dark:text-slate-400">Preparing your practice session...</p>
      </div>
    );
  }

  return (
    <QuizRunner
      headerContent={
        <p className="text-lg font-bold text-slate-900 dark:text-white">{state.categoryName}</p>
      }
      onSubmit={() => handleSubmit.current()}
    />
  );
}

function EmptyState({ title, message, ctaTo, ctaLabel }) {
  return (
    <div className="mx-auto max-w-xl px-4 py-24 text-center">
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{title}</h1>
      <p className="mt-2 text-slate-500 dark:text-slate-400">{message}</p>
      <Link to={ctaTo} className="focus-ring mt-6 inline-block rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700">
        {ctaLabel}
      </Link>
    </div>
  );
}
