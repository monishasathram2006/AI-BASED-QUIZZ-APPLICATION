import { Link, useNavigate } from 'react-router-dom';
import { getLastResult } from '../services/progressService.js';
import { difficultyLabelToParam } from '../utils/quizUtils.js';
import ResultCard from '../components/ResultCard.jsx';

const NEXT_DIFFICULTY = { Easy: 'Medium', Medium: 'Hard', Hard: 'Mixed', Mixed: null };

export default function Result() {
  const navigate = useNavigate();
  const result = getLastResult();

  if (!result) {
    return (
      <div className="mx-auto max-w-xl px-4 py-24 text-center">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">No recent quiz result</h1>
        <p className="mt-2 text-slate-500 dark:text-slate-400">Finish a quiz to see your results here.</p>
        <Link to="/categories" className="focus-ring mt-6 inline-block rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700">
          Browse Categories
        </Link>
      </div>
    );
  }

  const nextDifficulty = NEXT_DIFFICULTY[result.difficulty];

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
      <ResultCard result={result} />

      <div className="mt-6 flex flex-wrap justify-center gap-3">
        <button
          type="button"
          onClick={() => navigate(`/quiz/${result.categorySlug}/${difficultyLabelToParam(result.difficulty)}`)}
          className="focus-ring rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-700"
        >
          Retry Quiz
        </button>
        <Link
          to="/review"
          className="focus-ring rounded-lg border border-slate-300 bg-white px-5 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
        >
          Review Answers
        </Link>
        {result.wrong > 0 && (
          <Link
            to={`/practice/weak?category=${encodeURIComponent(result.category)}`}
            className="focus-ring rounded-lg border border-amber-300 bg-amber-50 px-5 py-2.5 text-sm font-semibold text-amber-700 transition hover:bg-amber-100 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-400"
          >
            Practice Weak Areas
          </Link>
        )}
        {nextDifficulty && (
          <button
            type="button"
            onClick={() => navigate(`/quiz/${result.categorySlug}/${difficultyLabelToParam(nextDifficulty)}`)}
            className="focus-ring rounded-lg border border-emerald-300 bg-emerald-50 px-5 py-2.5 text-sm font-semibold text-emerald-700 transition hover:bg-emerald-100 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-400"
          >
            Next Difficulty: {nextDifficulty}
          </button>
        )}
        <Link
          to="/"
          className="focus-ring rounded-lg border border-slate-300 bg-white px-5 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
        >
          Back to Dashboard
        </Link>
      </div>
    </div>
  );
}
