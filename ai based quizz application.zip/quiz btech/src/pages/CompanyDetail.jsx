import { Link, useParams } from 'react-router-dom';
import { getCompanyBySlug } from '../data/companies.js';
import { getBucketAccuracy } from '../utils/progressStorage.js';
import ProgressBar from '../components/ProgressBar.jsx';

function barColor(accuracy) {
  if (accuracy === null) return 'slate';
  if (accuracy >= 75) return 'emerald';
  if (accuracy >= 50) return 'amber';
  return 'red';
}

export default function CompanyDetail() {
  const { slug } = useParams();
  const company = getCompanyBySlug(slug);

  if (!company) {
    return (
      <div className="mx-auto max-w-xl px-4 py-24 text-center">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Company not found</h1>
        <Link to="/companies" className="focus-ring mt-6 inline-block rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700">
          Browse Companies
        </Link>
      </div>
    );
  }

  const scores = company.focusAreas.map((area) => ({ area, accuracy: getBucketAccuracy(area) }));
  const known = scores.filter((s) => s.accuracy !== null);
  const overall = known.length > 0 ? Math.round(known.reduce((sum, s) => sum + s.accuracy, 0) / known.length) : null;

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
      <Link to="/companies" className="focus-ring mb-6 inline-block text-sm font-semibold text-indigo-600 hover:underline dark:text-indigo-400">
        ← All Companies
      </Link>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <div className="mb-6 flex items-center gap-4">
          <span className="text-4xl">{company.icon}</span>
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">{company.name} Preparation</h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">Readiness Estimate — not a hiring guarantee</p>
          </div>
        </div>

        <div className="space-y-4">
          {scores.map(({ area, accuracy }) => (
            <ProgressBar
              key={area}
              label={area}
              value={accuracy ?? 0}
              color={barColor(accuracy)}
              showPercentage={accuracy !== null}
              className={accuracy === null ? 'opacity-60' : ''}
            />
          ))}
          {scores.some((s) => s.accuracy === null) && (
            <p className="text-xs text-slate-400 dark:text-slate-500">
              Areas showing 0% with no percentage label are "Not started" — no question content or attempts yet.
            </p>
          )}
        </div>

        <div className="mt-6 rounded-xl border border-slate-200 bg-slate-50 p-4 text-center dark:border-slate-800 dark:bg-slate-950/40">
          <p className="text-3xl font-extrabold text-indigo-600 dark:text-indigo-400">
            {overall === null ? '—' : `${overall}%`}
          </p>
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
            Overall Preparation Score {known.length < scores.length && `(based on ${known.length} of ${scores.length} areas with data)`}
          </p>
        </div>
      </div>
    </div>
  );
}
