import { useState, useMemo } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { getCategoryBySlug } from '../data/categories.js';
import { getQuestionsByCategory } from '../data/questionBank.js';
import { DIFFICULTY_COUNTS, difficultyLabelToParam } from '../utils/quizUtils.js';
import { getCategoryProgress } from '../services/progressService.js';
import DifficultyCard from '../components/DifficultyCard.jsx';

export default function CategoryDetails() {
  const { category: slug } = useParams();
  const navigate = useNavigate();
  const category = getCategoryBySlug(slug);

  const [topicSearch, setTopicSearch] = useState('');

  const questions = useMemo(() => {
    return category ? getQuestionsByCategory(category.name) : [];
  }, [category]);

  const easyCount = useMemo(() => questions.filter((q) => q.difficulty === 'Easy').length, [questions]);
  const mediumCount = useMemo(() => questions.filter((q) => q.difficulty === 'Medium').length, [questions]);
  const hardCount = useMemo(() => questions.filter((q) => q.difficulty === 'Hard').length, [questions]);

  const userProgress = useMemo(() => {
    return category ? getCategoryProgress(category.name) : { progress: 0, attempted: 0 };
  }, [category]);

  const filteredTopics = useMemo(() => {
    if (!category?.topics) return [];
    if (!topicSearch.trim()) return category.topics;
    return category.topics.filter((t) => t.toLowerCase().includes(topicSearch.toLowerCase().trim()));
  }, [category, topicSearch]);

  if (!category) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-24 text-center">
        <div className="text-5xl" role="img" aria-label="Error">
          ⚠️
        </div>
        <h1 className="mt-4 text-2xl font-bold text-slate-900 dark:text-white">Track not found</h1>
        <p className="mt-2 text-slate-500 dark:text-slate-400">
          "{slug}" isn't a recognized quiz track. Please choose from our catalog of tracks.
        </p>
        <Link
          to="/categories"
          className="focus-ring mt-6 inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700"
        >
          ← Browse All Categories
        </Link>
      </div>
    );
  }

  const startQuiz = (difficultyLabel) =>
    navigate(`/quiz/${slug}/${difficultyLabelToParam(difficultyLabel)}`);

  return (
    <div className="min-h-screen bg-slate-50/50 py-8 dark:bg-slate-950 sm:py-12">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb Navigation */}
        <nav className="mb-6 flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400" aria-label="Breadcrumb">
          <Link to="/" className="hover:text-indigo-600 dark:hover:text-indigo-400">
            Home
          </Link>
          <span>/</span>
          <Link to="/categories" className="hover:text-indigo-600 dark:hover:text-indigo-400">
            Categories
          </Link>
          <span>/</span>
          <span className="font-semibold text-slate-900 dark:text-white">{category.name}</span>
        </nav>

        {/* Hero Card */}
        <div className="relative mb-8 overflow-hidden rounded-3xl border border-slate-200/80 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 sm:p-10">
          <div className="relative z-10 flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div className="flex items-start gap-5">
              <span
                className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-indigo-50 text-4xl shadow-inner dark:bg-indigo-500/10"
                aria-hidden="true"
              >
                {category.icon}
              </span>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  {category.domain && (
                    <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                      {category.domain}
                    </span>
                  )}
                  {category.badge && (
                    <span className="rounded-full border border-indigo-200 bg-indigo-50 px-2.5 py-0.5 text-xs font-bold text-indigo-700 dark:border-indigo-500/30 dark:bg-indigo-500/10 dark:text-indigo-300">
                      {category.badge}
                    </span>
                  )}
                </div>

                <h1 className="mt-2 text-2xl font-extrabold tracking-tight text-slate-900 sm:text-3xl lg:text-4xl dark:text-white">
                  {category.name}
                </h1>
                <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-600 dark:text-slate-300 sm:text-base">
                  {category.description}
                </p>
              </div>
            </div>

            {/* Quick Action Button */}
            <div className="flex shrink-0 flex-col gap-2 sm:flex-row md:flex-col">
              <button
                type="button"
                onClick={() => startQuiz('Mixed')}
                className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 text-sm font-bold text-white shadow-sm transition hover:bg-indigo-700"
              >
                <span>⚡ Quick Mixed Quiz (25 Qs)</span>
              </button>
              <Link
                to="/roadmap"
                className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-5 py-2.5 text-xs font-semibold text-slate-700 transition hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-800/60 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                <span>🗺️ View Learning Roadmap</span>
              </Link>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="mb-10 grid grid-cols-2 gap-3 sm:grid-cols-5">
          <StatBox label="Total Questions" value={questions.length} accent="text-indigo-600 dark:text-indigo-400" />
          <StatBox label="Easy (10 mins)" value={easyCount} accent="text-emerald-600 dark:text-emerald-400" />
          <StatBox label="Medium (15 mins)" value={mediumCount} accent="text-amber-600 dark:text-amber-400" />
          <StatBox label="Hard (10 mins)" value={hardCount} accent="text-rose-600 dark:text-rose-400" />
          <StatBox
            label="Your Mastery"
            value={userProgress.attempted > 0 ? `${userProgress.progress}%` : 'Not Started'}
            accent={userProgress.attempted > 0 ? 'text-teal-600 dark:text-teal-400' : 'text-slate-400 dark:text-slate-500'}
          />
        </div>

        {/* Choose a Difficulty Section */}
        <div className="mb-12">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Choose a Difficulty Tier</h2>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Select your targeted challenge level. Every attempt dynamically logs XP and adaptive mastery.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            <DifficultyCard
              difficulty="Easy"
              questionCount={DIFFICULTY_COUNTS.Easy}
              onStart={() => startQuiz('Easy')}
            />
            <DifficultyCard
              difficulty="Medium"
              questionCount={DIFFICULTY_COUNTS.Medium}
              onStart={() => startQuiz('Medium')}
            />
            <DifficultyCard
              difficulty="Hard"
              questionCount={DIFFICULTY_COUNTS.Hard}
              onStart={() => startQuiz('Hard')}
            />
            <DifficultyCard
              difficulty="Mixed"
              questionCount={DIFFICULTY_COUNTS.Mixed}
              onStart={() => startQuiz('Mixed')}
            />
          </div>
        </div>

        {/* Interactive Topic Explorer */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Topics Covered in {category.name}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Comprehensive subject areas tested in top technical placement interviews.
              </p>
            </div>

            {/* Topic Search Input */}
            <div className="relative max-w-xs">
              <input
                type="text"
                value={topicSearch}
                onChange={(e) => setTopicSearch(e.target.value)}
                placeholder="Filter topics..."
                className="focus-ring rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-900 placeholder-slate-400 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
              {topicSearch && (
                <button
                  type="button"
                  onClick={() => setTopicSearch('')}
                  className="absolute right-2.5 top-1.5 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {filteredTopics.map((topic) => (
              <span
                key={topic}
                className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200/80 bg-slate-50/80 px-3 py-1.5 text-xs font-semibold text-slate-700 transition hover:border-indigo-300 hover:bg-indigo-50/50 hover:text-indigo-700 dark:border-slate-800 dark:bg-slate-800/80 dark:text-slate-300 dark:hover:border-indigo-500/40 dark:hover:bg-indigo-500/10 dark:hover:text-indigo-300"
              >
                <span>🏷️</span>
                {topic}
              </span>
            ))}
            {filteredTopics.length === 0 && (
              <p className="py-4 text-xs text-slate-400">No topics match "{topicSearch}".</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatBox({ label, value, accent = 'text-slate-900 dark:text-white' }) {
  return (
    <div className="rounded-2xl border border-slate-200/80 bg-white p-4 text-center shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <p className={`text-2xl font-extrabold ${accent}`}>{value}</p>
      <p className="mt-1 text-xs font-medium text-slate-500 dark:text-slate-400">{label}</p>
    </div>
  );
}
