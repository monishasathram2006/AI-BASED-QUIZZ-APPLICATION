import { useState } from 'react';
import { Link } from 'react-router-dom';
import { getWeakTopics } from '../utils/progressStorage.js';
import { safeGet, safeSet, STORAGE_KEYS } from '../utils/storage.js';

const FOUNDATION_DAYS = [
  {
    title: 'Data Structures & Algorithms Kickoff',
    desc: 'Master array patterns, hash maps, strings, and asymptotic complexity.',
    category: 'dsa',
    badge: 'Core CS',
    link: '/quiz/dsa/easy',
  },
  {
    title: 'Database Systems & SQL Mastery',
    desc: 'Review SQL joins, transactions (ACID), indexes, and schema normalization.',
    category: 'dbms',
    badge: 'Core CS',
    link: '/quiz/dbms/easy',
  },
  {
    title: 'Operating Systems & Concurrency',
    desc: 'Deep dive into processes vs threads, deadlock conditions, and virtual memory.',
    category: 'os',
    badge: 'Core CS',
    link: '/quiz/os/easy',
  },
  {
    title: 'Computer Networks & Web Protocols',
    desc: 'Explore OSI layers, TCP vs UDP handshakes, HTTP/HTTPS, and DNS resolution.',
    category: 'networks',
    badge: 'Core CS',
    link: '/quiz/networks/easy',
  },
  {
    title: 'System Design & Scalability Patterns',
    desc: 'Understand caching strategies, load balancers, database sharding, and CAP theorem.',
    category: 'system-design',
    badge: 'Architecture',
    link: '/quiz/system-design/easy',
  },
  {
    title: 'Hands-on Interactive Coding Arena',
    desc: 'Implement live algorithms in the multi-language in-browser code editor.',
    badge: 'Coding',
    link: '/coding',
  },
  {
    title: 'Full Technical Mock Interview',
    desc: 'Simulate a real 3-round technical placement drive under strict timed pressure.',
    badge: 'Interview',
    link: '/interview',
  },
];

function buildWeakAreaPlan(weakTopics) {
  const [a, b, c] = weakTopics;
  const days = [];

  if (a) {
    days.push({
      title: `${a.topic} Fundamentals`,
      desc: `Focus on your lowest accuracy topic (${a.accuracy}% accuracy in ${a.category}).`,
      category: a.category,
      badge: 'Target Weakness',
      link: `/practice/weak?category=${encodeURIComponent(a.category)}&topic=${encodeURIComponent(a.topic)}`,
    });
    days.push({
      title: `${a.topic} Deep Practice`,
      desc: `Solve timed questions to turn ${a.topic} into a strength.`,
      category: a.category,
      badge: 'Target Weakness',
      link: `/practice/weak?category=${encodeURIComponent(a.category)}&topic=${encodeURIComponent(a.topic)}`,
    });
  }

  if (b) {
    days.push({
      title: `${b.topic} Reinforcement`,
      desc: `Improve conceptual clarity in ${b.topic} (${b.accuracy}% accuracy).`,
      category: b.category,
      badge: 'Target Weakness',
      link: `/practice/weak?category=${encodeURIComponent(b.category)}&topic=${encodeURIComponent(b.topic)}`,
    });
    days.push({
      title: `${b.topic} Problem Set`,
      desc: `Targeted scenario and logic drills for ${b.topic}.`,
      category: b.category,
      badge: 'Target Weakness',
      link: `/practice/weak?category=${encodeURIComponent(b.category)}&topic=${encodeURIComponent(b.topic)}`,
    });
  }

  if (c) {
    days.push({
      title: `${c.topic} Review`,
      desc: `Address edge cases and common traps in ${c.topic}.`,
      category: c.category,
      badge: 'Target Weakness',
      link: `/practice/weak?category=${encodeURIComponent(c.category)}&topic=${encodeURIComponent(c.topic)}`,
    });
  }

  while (days.length < 5) {
    days.push({
      title: 'Targeted Core Practice',
      desc: 'Reinforce foundational data structures & algorithm patterns.',
      badge: 'Core Drills',
      link: '/quiz/dsa/medium',
    });
  }

  days.push({
    title: 'Hands-on Code Implementation',
    desc: 'Test your problem-solving skills in the live coding sandbox.',
    badge: 'Coding Arena',
    link: '/coding',
  });

  days.push({
    title: 'Full Placement Mock Interview',
    desc: '3-Round technical evaluation simulating real tech campus placements.',
    badge: 'Mock Interview',
    link: '/interview',
  });

  return {
    type: 'personalized',
    createdAt: new Date().toISOString(),
    weakTopics: weakTopics.map((t) => `${t.category} — ${t.topic} (${t.accuracy}%)`),
    days: days.slice(0, 7).map((d, i) => ({ ...d, day: i + 1, done: false })),
  };
}

function buildFoundationPlan() {
  return {
    type: 'foundation',
    createdAt: new Date().toISOString(),
    weakTopics: ['Curated 7-Day CS Core Placement Curriculum'],
    days: FOUNDATION_DAYS.map((d, i) => ({ ...d, day: i + 1, done: false })),
  };
}

export default function StudyCoach() {
  const [plan, setPlan] = useState(() => safeGet(STORAGE_KEYS.STUDY_PLAN, null));
  const weakTopics = getWeakTopics(3, 2);

  const startWeakPlan = () => {
    const newPlan = buildWeakAreaPlan(weakTopics);
    safeSet(STORAGE_KEYS.STUDY_PLAN, newPlan);
    setPlan(newPlan);
  };

  const startFoundationPlan = () => {
    const newPlan = buildFoundationPlan();
    safeSet(STORAGE_KEYS.STUDY_PLAN, newPlan);
    setPlan(newPlan);
  };

  const resetPlan = () => {
    safeSet(STORAGE_KEYS.STUDY_PLAN, null);
    setPlan(null);
  };

  const toggleDay = (dayIndex) => {
    if (!plan) return;
    const updated = {
      ...plan,
      days: plan.days.map((d, i) => (i === dayIndex ? { ...d, done: !d.done } : d)),
    };
    safeSet(STORAGE_KEYS.STUDY_PLAN, updated);
    setPlan(updated);
  };

  const completedDays = plan ? plan.days.filter((d) => d.done).length : 0;
  const totalDays = plan ? plan.days.length : 7;
  const progressPercent = Math.round((completedDays / totalDays) * 100);

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-100 text-2xl dark:bg-indigo-950/60">
                🎯
              </span>
              <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl dark:text-white">
                CodePrep Study Coach
              </h1>
            </div>
            <p className="mt-2 text-sm text-slate-600 sm:text-base dark:text-slate-400">
              Personalized, data-driven daily study plans designed to systematically build technical placement readiness.
            </p>
          </div>

          {plan && (
            <button
              type="button"
              onClick={resetPlan}
              className="focus-ring rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              🔄 Reset / Change Plan
            </button>
          )}
        </div>
      </div>

      {/* State A: No Plan & No weak areas yet */}
      {weakTopics.length === 0 && !plan && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-indigo-200 bg-gradient-to-br from-indigo-50/70 via-white to-purple-50/50 p-6 dark:border-indigo-900/40 dark:from-indigo-950/30 dark:via-slate-900 dark:to-purple-950/20 sm:p-8">
            <div className="flex flex-col items-center text-center">
              <span className="text-5xl">🧭</span>
              <h2 className="mt-4 text-xl font-bold text-slate-900 dark:text-white">
                Kickstart Your 7-Day CS Preparation
              </h2>
              <p className="mt-2 max-w-xl text-sm text-slate-600 dark:text-slate-300">
                You haven't completed enough quizzes yet for the Coach to isolate specific weak topics. You can either generate our curated 7-day Core CS curriculum right now, or take a diagnostic quiz to benchmark your skills.
              </p>

              <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={startFoundationPlan}
                  className="focus-ring inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-indigo-700"
                >
                  <span>⚡</span>
                  <span>Generate 7-Day CS Foundation Plan</span>
                </button>
                <Link
                  to="/quiz/dsa/easy"
                  className="focus-ring inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                >
                  <span>🎯</span>
                  <span>Take Diagnostic Quiz (DSA)</span>
                </Link>
              </div>
            </div>
          </div>

          {/* Quick Curriculum Preview */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h3 className="font-semibold text-slate-900 dark:text-white">What's in the 7-Day Plan?</h3>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">Structured day-by-day roadmap targeting high-frequency campus placement topics:</p>
            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {FOUNDATION_DAYS.map((d, i) => (
                <div key={d.title} className="flex items-start gap-3 rounded-xl border border-slate-100 bg-slate-50/70 p-3 dark:border-slate-800/80 dark:bg-slate-950/40">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-indigo-100 text-xs font-bold text-indigo-700 dark:bg-indigo-900/60 dark:text-indigo-300">
                    {i + 1}
                  </span>
                  <div>
                    <p className="text-xs font-bold text-slate-900 dark:text-white">{d.title}</p>
                    <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">{d.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* State B: Weak Topics Identified & No Plan Selected */}
      {weakTopics.length > 0 && !plan && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-amber-200 bg-gradient-to-br from-amber-50/60 via-white to-orange-50/40 p-6 dark:border-amber-900/40 dark:from-amber-950/20 dark:via-slate-900 dark:to-orange-950/20 sm:p-8">
            <div className="flex items-center gap-2">
              <span className="text-2xl">📊</span>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Coach Performance Diagnosis
              </h2>
            </div>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
              Based on your quiz history, here are the topics where you have the most room for growth:
            </p>

            <div className="mt-4 space-y-2">
              {weakTopics.map((t) => (
                <div
                  key={`${t.category}-${t.topic}`}
                  className="flex items-center justify-between rounded-xl border border-amber-200/80 bg-white/90 p-3.5 shadow-xs dark:border-slate-800 dark:bg-slate-900/90"
                >
                  <div>
                    <p className="font-semibold text-slate-900 dark:text-white">{t.topic}</p>
                    <p className="text-xs text-slate-500 uppercase tracking-wide dark:text-slate-400">{t.category}</p>
                  </div>
                  <div className="text-right">
                    <span className="inline-flex items-center rounded-full bg-rose-100 px-2.5 py-0.5 text-xs font-bold text-rose-700 dark:bg-rose-950/50 dark:text-rose-400">
                      {t.accuracy}% Accuracy
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={startWeakPlan}
                className="focus-ring inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-indigo-700"
              >
                <span>🎯</span>
                <span>Start Weakness-Focused Plan</span>
              </button>
              <button
                type="button"
                onClick={startFoundationPlan}
                className="focus-ring inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-5 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
              >
                <span>⚡</span>
                <span>Generate CS Foundation Plan Instead</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* State C: Active 7-Day Plan */}
      {plan && (
        <div className="space-y-6">
          {/* Progress Overview */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center rounded-md bg-indigo-100 px-2 py-0.5 text-xs font-semibold text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300">
                    {plan.type === 'foundation' ? 'CS Foundation Curriculum' : 'Targeted Weakness Curriculum'}
                  </span>
                  <span className="text-xs text-slate-400">
                    Started {new Date(plan.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <h2 className="mt-1 text-lg font-bold text-slate-900 dark:text-white">
                  {completedDays === totalDays ? '🎉 Plan Complete! Great job!' : `Day ${Math.min(completedDays + 1, totalDays)} of ${totalDays}`}
                </h2>
              </div>
              <div className="text-right">
                <span className="text-2xl font-black text-indigo-600 dark:text-indigo-400">{progressPercent}%</span>
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                  {completedDays} / {totalDays} Days Completed
                </p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mt-4 h-2.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
              <div
                className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-emerald-500 transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Day Cards */}
          <div className="space-y-3">
            {plan.days.map((d, i) => (
              <div
                key={d.day}
                className={`flex flex-col gap-3 rounded-2xl border p-5 transition sm:flex-row sm:items-center sm:justify-between ${
                  d.done
                    ? 'border-emerald-200/90 bg-emerald-50/40 dark:border-emerald-500/30 dark:bg-emerald-950/15'
                    : 'border-slate-200 bg-white shadow-xs dark:border-slate-800 dark:bg-slate-900'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <div
                    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-sm font-bold ${
                      d.done
                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-300'
                        : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300'
                    }`}
                  >
                    {d.done ? '✓' : `D${d.day}`}
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <p className={`font-bold ${d.done ? 'text-slate-600 line-through dark:text-slate-400' : 'text-slate-900 dark:text-white'}`}>
                        {d.title}
                      </p>
                      {d.badge && (
                        <span className="inline-flex items-center rounded-md bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                          {d.badge}
                        </span>
                      )}
                    </div>
                    {d.desc && (
                      <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{d.desc}</p>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <Link
                    to={d.link}
                    className="focus-ring inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs transition hover:bg-indigo-700"
                  >
                    <span>Start</span>
                    <span>→</span>
                  </Link>

                  <button
                    type="button"
                    onClick={() => toggleDay(i)}
                    aria-pressed={d.done}
                    className={`focus-ring inline-flex items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-semibold transition ${
                      d.done
                        ? 'border-emerald-300 bg-white text-emerald-700 hover:bg-emerald-50 dark:border-emerald-700/60 dark:bg-slate-800 dark:text-emerald-300'
                        : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    <span>{d.done ? '✓ Completed' : 'Mark Done'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
