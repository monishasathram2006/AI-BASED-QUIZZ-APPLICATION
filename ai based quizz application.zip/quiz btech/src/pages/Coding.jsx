import { useState } from 'react';
import { CODING_LANGUAGES, CODING_LANGUAGE_LABELS, getChallengesByLanguage } from '../data/codingChallenges.js';
import { runCode } from '../utils/codeRunner.js';
import { safeGet, safeSet, STORAGE_KEYS } from '../utils/storage.js';
import { awardXP, XP_RULES, recordActivityToday } from '../utils/gamification.js';
import { checkAndUnlock } from '../utils/achievements.js';

const LANGUAGE_ICONS = { javascript: '🌐', python: '🐍', c: '🔧', cpp: '⚙️', java: '☕', sql: '🗄️' };

function recordCodingAttempt(challengeId, passed) {
  const attempts = safeGet(STORAGE_KEYS.CODING_ATTEMPTS, []);
  attempts.push({ challengeId, passed, timestamp: new Date().toISOString() });
  safeSet(STORAGE_KEYS.CODING_ATTEMPTS, attempts);
  if (passed) {
    const xpResult = awardXP(XP_RULES.codingChallenge);
    const streakInfo = recordActivityToday();
    const newBadges = checkAndUnlock();
    return { xpGained: XP_RULES.codingChallenge, leveledUp: xpResult.leveledUp, newLevel: xpResult.newLevel, streakDay: streakInfo.currentStreak, newBadges };
  }
  return null;
}

export default function Coding() {
  const [language, setLanguage] = useState(null);
  const [challenge, setChallenge] = useState(null);
  const [code, setCode] = useState('');
  const [running, setRunning] = useState(false);
  const [runResult, setRunResult] = useState(null);
  const [xpFeedback, setXpFeedback] = useState(null);

  const openChallenge = (c) => {
    setChallenge(c);
    setCode(c.starterCode);
    setRunResult(null);
    setXpFeedback(null);
  };

  const handleSubmit = async () => {
    setRunning(true);
    setRunResult(null);
    const outcome = await runCode(challenge.language, code, challenge.testCases);
    setRunResult(outcome);
    setRunning(false);

    if (outcome.status === 'ran') {
      const allPassed = outcome.results.every((r) => r.pass);
      const feedback = recordCodingAttempt(challenge.id, allPassed);
      if (feedback) setXpFeedback(feedback);
    }
  };

  if (!language) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl dark:text-white">Coding Challenges</h1>
          <p className="mt-2 text-slate-500 dark:text-slate-400">
            JavaScript challenges run for real in your browser. Other languages show the full problem, ready for a backend execution service.
          </p>
        </div>
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {CODING_LANGUAGES.map((lang) => (
            <button
              key={lang}
              type="button"
              onClick={() => setLanguage(lang)}
              className="focus-ring group flex flex-col items-center rounded-2xl border border-slate-200 bg-white p-6 text-center shadow-sm transition hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
            >
              <span className="text-4xl">{LANGUAGE_ICONS[lang]}</span>
              <span className="mt-3 text-lg font-bold text-slate-900 dark:text-white">{CODING_LANGUAGE_LABELS[lang]}</span>
              <span className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                {getChallengesByLanguage(lang).length} challenges
              </span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (!challenge) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
        <button
          type="button"
          onClick={() => setLanguage(null)}
          className="focus-ring mb-6 text-sm font-semibold text-indigo-600 hover:underline dark:text-indigo-400"
        >
          ← All Languages
        </button>
        <h1 className="mb-6 text-2xl font-bold text-slate-900 dark:text-white">{CODING_LANGUAGE_LABELS[language]} Challenges</h1>
        <div className="space-y-4">
          {getChallengesByLanguage(language).map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => openChallenge(c)}
              className="focus-ring flex w-full items-center justify-between rounded-xl border border-slate-200 bg-white p-5 text-left transition hover:border-indigo-300 hover:bg-indigo-50/40 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-indigo-500/40 dark:hover:bg-indigo-500/5"
            >
              <div>
                <p className="font-semibold text-slate-900 dark:text-white">{c.title}</p>
                <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{c.description}</p>
              </div>
              <span className="ml-4 shrink-0 rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                {c.difficulty}
              </span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <button
        type="button"
        onClick={() => setChallenge(null)}
        className="focus-ring mb-6 text-sm font-semibold text-indigo-600 hover:underline dark:text-indigo-400"
      >
        ← {CODING_LANGUAGE_LABELS[language]} Challenges
      </button>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <h1 className="text-xl font-bold text-slate-900 dark:text-white">{challenge.title}</h1>
          <div className="flex gap-2 text-xs font-semibold">
            <span className="rounded-full bg-slate-100 px-3 py-1 text-slate-600 dark:bg-slate-800 dark:text-slate-300">{challenge.difficulty}</span>
            <span className="rounded-full bg-slate-100 px-3 py-1 text-slate-600 dark:bg-slate-800 dark:text-slate-300">{challenge.timeLimitSeconds}s</span>
          </div>
        </div>

        <p className="text-sm text-slate-700 dark:text-slate-300">{challenge.description}</p>

        <div className="mt-4 space-y-1 text-sm">
          {challenge.examples.map((ex, i) => (
            <p key={i} className="text-slate-500 dark:text-slate-400">
              <span className="font-mono">Input:</span> {ex.input} &nbsp;→&nbsp; <span className="font-mono">Output:</span> {ex.output}
            </p>
          ))}
        </div>

        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          spellCheck={false}
          aria-label="Code editor"
          className="focus-ring mt-5 h-56 w-full rounded-xl border border-slate-800 bg-[#282c34] p-4 font-mono text-sm text-slate-100"
        />

        <div className="mt-4 flex items-center gap-3">
          <button
            type="button"
            onClick={handleSubmit}
            disabled={running}
            className="focus-ring rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {running ? 'Running…' : 'Run & Submit'}
          </button>
          {xpFeedback && (
            <span className="rounded-full bg-indigo-100 px-3 py-1 text-sm font-semibold text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-400">
              +{xpFeedback.xpGained} XP
            </span>
          )}
        </div>

        {runResult && runResult.status === 'unsupported' && (
          <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-400">
            {runResult.message}
          </div>
        )}

        {runResult && runResult.status === 'error' && (
          <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-400">
            {runResult.message}
          </div>
        )}

        {runResult && runResult.status === 'ran' && (
          <div className="mt-4 space-y-2">
            {runResult.results.map((r, i) => (
              <div
                key={i}
                className={`rounded-lg border p-3 text-sm ${
                  r.pass
                    ? 'border-emerald-300 bg-emerald-50 text-emerald-800 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-300'
                    : 'border-red-300 bg-red-50 text-red-800 dark:border-red-500/40 dark:bg-red-500/10 dark:text-red-300'
                }`}
              >
                {r.pass ? '✓ Passed' : '✕ Failed'} — expected {JSON.stringify(r.expected)}, got {JSON.stringify(r.actual)}
                {r.error && ` (${r.error})`}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
