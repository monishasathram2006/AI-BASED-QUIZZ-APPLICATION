import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { categories } from '../data/categories.js';
import { searchQuestions, questionBank } from '../data/questionBank.js';
import SearchBar from '../components/SearchBar.jsx';
import FilterDropdown from '../components/FilterDropdown.jsx';

const DIFFICULTIES = ['Easy', 'Medium', 'Hard'];

export default function Topics() {
  const [term, setTerm] = useState('');
  const [category, setCategory] = useState('');
  const [difficulty, setDifficulty] = useState('');
  const [expandedTopic, setExpandedTopic] = useState(null);

  const results = useMemo(
    () => searchQuestions(term, { category: category || undefined, difficulty: difficulty || undefined }),
    [term, category, difficulty]
  );

  const grouped = useMemo(() => {
    const map = new Map();
    for (const q of results) {
      const key = `${q.category}::${q.topic}`;
      if (!map.has(key)) {
        map.set(key, { category: q.category, topic: q.topic, count: 0, questions: [] });
      }
      const entry = map.get(key);
      entry.count += 1;
      entry.questions.push(q);
    }
    return [...map.values()].sort(
      (a, b) => a.category.localeCompare(b.category) || a.topic.localeCompare(b.topic)
    );
  }, [results]);

  const toggleExpand = (key) => {
    setExpandedTopic(expandedTopic === key ? null : key);
  };

  return (
    <div className="min-h-screen bg-slate-50/50 py-10 dark:bg-slate-950 sm:py-12">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="inline-flex items-center gap-2 rounded-full border border-indigo-200 bg-indigo-50 px-3 py-1 text-xs font-bold text-indigo-700 dark:border-indigo-500/30 dark:bg-indigo-500/10 dark:text-indigo-300">
            <span>🏷️</span> Search Across {questionBank.length}+ Questions
          </div>
          <h1 className="mt-3 text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl dark:text-white">
            Topic Explorer &amp; Practice
          </h1>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
            Search across all 14 categories, explore topic breakdowns, and launch focused practice quizzes for any concept.
          </p>
        </div>

        {/* Search & Filter Bar */}
        <div className="mb-6 flex flex-col gap-4 rounded-2xl border border-slate-200/90 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <SearchBar
            value={term}
            onChange={setTerm}
            placeholder='Search keywords (e.g. "inheritance", "recursion", "docker", "indexing", "tcp")...'
          />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <FilterDropdown
              label="Track / Category"
              value={category}
              onChange={setCategory}
              options={categories.map((c) => c.name)}
            />
            <FilterDropdown
              label="Difficulty Tier"
              value={difficulty}
              onChange={setDifficulty}
              options={DIFFICULTIES}
            />
          </div>
        </div>

        {/* Results Count & Quick Reset */}
        <div className="mb-4 flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
          <span>
            Found <strong className="text-slate-900 dark:text-white">{results.length}</strong> matching question{results.length === 1 ? '' : 's'} in{' '}
            <strong className="text-slate-900 dark:text-white">{grouped.length}</strong> topic group{grouped.length === 1 ? '' : 's'}
          </span>
          {(term || category || difficulty) && (
            <button
              type="button"
              onClick={() => {
                setTerm('');
                setCategory('');
                setDifficulty('');
              }}
              className="text-indigo-600 hover:underline dark:text-indigo-400"
            >
              Clear filters
            </button>
          )}
        </div>

        {/* Grouped Topic Accordions */}
        <div className="space-y-3">
          {grouped.map((g) => {
            const key = `${g.category}-${g.topic}`;
            const isExpanded = expandedTopic === key;
            const catObj = categories.find((c) => c.name === g.category);

            return (
              <div
                key={key}
                className="overflow-hidden rounded-2xl border border-slate-200/90 bg-white shadow-sm transition hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-slate-700"
              >
                <div
                  onClick={() => toggleExpand(key)}
                  className="flex cursor-pointer items-center justify-between p-4.5 sm:px-6"
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => e.key === 'Enter' && toggleExpand(key)}
                >
                  <div className="flex items-center gap-3">
                    <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-50 text-base dark:bg-indigo-500/10">
                      {catObj?.icon || '🏷️'}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                          {g.category}
                        </span>
                        <span className="text-slate-300 dark:text-slate-600">&bull;</span>
                        <span className="text-sm font-bold text-slate-900 dark:text-white">
                          {g.topic}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                      {g.count} Question{g.count === 1 ? '' : 's'}
                    </span>
                    <span
                      className={`text-slate-400 transition-transform duration-200 ${
                        isExpanded ? 'rotate-180' : ''
                      }`}
                      aria-hidden="true"
                    >
                      ▾
                    </span>
                  </div>
                </div>

                {/* Expanded Details Panel */}
                {isExpanded && (
                  <div className="border-t border-slate-100 bg-slate-50/70 p-4 sm:px-6 dark:border-slate-800/80 dark:bg-slate-950/40">
                    <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                      <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                        Questions in this topic:
                      </span>
                      <div className="flex items-center gap-2">
                        <Link
                          to={`/practice/weak?category=${encodeURIComponent(g.category)}&topic=${encodeURIComponent(g.topic)}`}
                          className="focus-ring inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm transition hover:bg-indigo-700"
                        >
                          <span>⚡ Practice This Topic</span>
                        </Link>
                        {catObj && (
                          <Link
                            to={`/category/${catObj.slug}`}
                            className="focus-ring inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
                          >
                            <span>Explore {catObj.shortName || catObj.name}</span> &rarr;
                          </Link>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2">
                      {g.questions.map((q, idx) => (
                        <div
                          key={q.id || idx}
                          className="flex items-start justify-between gap-3 rounded-xl border border-slate-200/80 bg-white p-3 text-xs shadow-xs dark:border-slate-800 dark:bg-slate-900"
                        >
                          <span className="font-medium leading-relaxed text-slate-800 dark:text-slate-200">
                            {idx + 1}. {q.question}
                          </span>
                          <span
                            className={`shrink-0 rounded-md px-2 py-0.5 text-[10px] font-bold ${
                              q.difficulty === 'Easy'
                                ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400'
                                : q.difficulty === 'Medium'
                                ? 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400'
                                : 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-400'
                            }`}
                          >
                            {q.difficulty}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {grouped.length === 0 && (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center text-sm text-slate-500 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400">
              <span className="text-4xl" role="img" aria-label="No results">
                🔎
              </span>
              <p className="mt-3 font-semibold text-slate-800 dark:text-slate-200">
                No questions match your current filters.
              </p>
              <p className="mt-1 text-xs text-slate-500">
                Try searching a different concept, or clear the category and difficulty filters.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
