import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { questionBank } from '../data/questionBank.js';
import { shuffleArray, formatTime } from '../utils/quizUtils.js';
import { getDebuggingQuestionsByLanguage } from '../data/debuggingQuestions.js';
import { calculateQuizResult } from '../utils/quizScoring.js';
import QuestionCard from '../components/QuestionCard.jsx';
import { safeGet, safeSet, STORAGE_KEYS } from '../utils/storage.js';
import { awardXP, XP_RULES, recordActivityToday } from '../utils/gamification.js';
import { checkAndUnlock } from '../utils/achievements.js';

const ROLE_CONFIG = {
  'Software Developer': { categories: ['Data Structures & Algorithms', 'Python', 'Java Development', 'C++', 'Operating Systems', 'DBMS & SQL'], debugLang: 'javascript' },
  'Backend Developer': { categories: ['Data Structures & Algorithms', 'DBMS & SQL', 'System Design', 'Operating Systems', 'Computer Networks'], debugLang: 'javascript' },
  'Full Stack Developer': { categories: ['Full Stack', 'Web Development', 'DBMS & SQL', 'System Design'], debugLang: 'javascript' },
  'Python Developer': { categories: ['Python', 'Data Structures & Algorithms', 'DBMS & SQL'], debugLang: 'python' },
  'Java Developer': { categories: ['Java Development', 'Data Structures & Algorithms', 'DBMS & SQL'], debugLang: 'java' },
  'C++ Developer': { categories: ['C++', 'Data Structures & Algorithms', 'Operating Systems'], debugLang: 'cpp' },
  'DevOps & Cloud Engineer': { categories: ['Cloud & DevOps', 'Operating Systems', 'Computer Networks', 'System Design'], debugLang: 'python' },
  'AI / ML Engineer': { categories: ['AI & Machine Learning', 'Python', 'Data Structures & Algorithms'], debugLang: 'python' },
  'Cybersecurity Analyst': { categories: ['Cybersecurity', 'Computer Networks', 'Operating Systems'], debugLang: 'python' },
  'Embedded Developer': { categories: ['C', 'C++', 'Operating Systems'], debugLang: 'c' },
  'Data Analyst': { categories: ['Python', 'DBMS & SQL'], debugLang: 'python' },
};

const LEVEL_DIFFICULTY = { Beginner: 'Easy', Intermediate: 'Medium', Advanced: 'Hard' };
const DSA_KEYWORDS = ['array', 'list', 'stack', 'vector', 'map', 'pointer', 'structure', 'recursion', 'tree', 'graph', 'string'];

function readinessBand(pct) {
  if (pct >= 90) return 'Highly Prepared';
  if (pct >= 75) return 'Interview Ready';
  if (pct >= 60) return 'Practitioner';
  if (pct >= 40) return 'Learning';
  return 'Beginner';
}

function buildRounds(role, level) {
  const config = ROLE_CONFIG[role] || ROLE_CONFIG['Software Developer'];
  const difficulty = LEVEL_DIFFICULTY[level];
  const pool = questionBank.filter((q) => config.categories.includes(q.category));
  const usedIds = new Set();

  const takeFrom = (candidates, n) => {
    const available = shuffleArray(candidates.filter((q) => !usedIds.has(q.id)));
    const picked = available.slice(0, n);
    picked.forEach((q) => usedIds.add(q.id));
    return picked;
  };

  const sameDifficulty = pool.filter((q) => q.difficulty === difficulty);
  const round1 = takeFrom(sameDifficulty, 4);
  const round2 = takeFrom(sameDifficulty, 4);

  let dsaCandidates = questionBank.filter((q) => q.category === 'Data Structures & Algorithms');
  if (dsaCandidates.length < 4) {
    dsaCandidates = pool.filter((q) => DSA_KEYWORDS.some((k) => q.topic.toLowerCase().includes(k)));
  }
  const round3 = takeFrom(dsaCandidates, 4);

  const round4 = shuffleArray(getDebuggingQuestionsByLanguage(config.debugLang))
    .slice(0, 4)
    .map((q) => ({ ...q, question: 'Find the bug in this code.' }));

  const round5 = takeFrom(pool.filter((q) => q.difficulty === 'Easy'), 6);

  return [
    { key: 'technical', title: 'Round 1: Technical Fundamentals', questions: round1, timeSeconds: 90 },
    { key: 'programming', title: 'Round 2: Programming', questions: round2, timeSeconds: 90 },
    { key: 'dsa', title: 'Round 3: Data Structures', questions: round3, timeSeconds: 90 },
    { key: 'debugging', title: 'Round 4: Debugging', questions: round4, timeSeconds: 90 },
    { key: 'speed', title: 'Round 5: Rapid Fire', questions: round5, timeSeconds: 45 },
  ].filter((r) => r.questions.length > 0);
}

function InterviewRound({ round, onComplete }) {
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [remaining, setRemaining] = useState(round.timeSeconds);
  const onCompleteRef = useRef(onComplete);
  const answersRef = useRef(answers);
  useEffect(() => {
    onCompleteRef.current = onComplete;
    answersRef.current = answers;
  }, [onComplete, answers]);

  useEffect(() => {
    const id = setInterval(() => setRemaining((r) => Math.max(0, r - 1)), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (remaining === 0) onCompleteRef.current(answersRef.current);
  }, [remaining]);

  const question = round.questions[index];
  const isLast = index === round.questions.length - 1;

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-4 flex items-center justify-between">
        <p className="text-lg font-bold text-slate-900 dark:text-white">{round.title}</p>
        <span className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 font-mono text-sm font-semibold text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200" role="timer" aria-live="polite">
          ⏱ {formatTime(remaining)}
        </span>
      </div>

      <QuestionCard
        question={question}
        index={index}
        total={round.questions.length}
        selectedAnswer={answers[question.id]}
        onSelect={(option) => setAnswers((prev) => ({ ...prev, [question.id]: option }))}
      />

      <div className="mt-5 flex justify-end">
        <button
          type="button"
          onClick={() => (isLast ? onComplete(answers) : setIndex((i) => i + 1))}
          className="focus-ring rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-700"
        >
          {isLast ? 'Finish Round' : 'Next Question'}
        </button>
      </div>
    </div>
  );
}

export default function Interview() {
  const [role, setRole] = useState(null);
  const [level, setLevel] = useState(null);
  const [rounds, setRounds] = useState(null);
  const [roundIndex, setRoundIndex] = useState(0);
  const [roundResults, setRoundResults] = useState([]);
  const [summary, setSummary] = useState(null);

  const startInterview = () => {
    setRounds(buildRounds(role, level));
    setRoundIndex(0);
    setRoundResults([]);
  };

  const handleRoundComplete = (answers) => {
    const round = rounds[roundIndex];
    const result = calculateQuizResult(round.questions, answers);
    const newResults = [...roundResults, { key: round.key, title: round.title, ...result }];

    if (roundIndex + 1 < rounds.length) {
      setRoundResults(newResults);
      setRoundIndex((i) => i + 1);
    } else {
      finishInterview(newResults);
    }
  };

  const finishInterview = (results) => {
    const byKey = Object.fromEntries(results.map((r) => [r.key, r.score]));
    const technical = byKey.technical ?? null;
    const programming = byKey.programming ?? null;
    const dsa = byKey.dsa ?? null;
    const debugging = byKey.debugging ?? null;
    const speed = byKey.speed ?? null;

    const problemSolving = [programming, dsa].filter((v) => v !== null).length > 0
      ? Math.round([programming, dsa].filter((v) => v !== null).reduce((a, b) => a + b, 0) / [programming, dsa].filter((v) => v !== null).length)
      : null;

    const allScores = results.map((r) => r.score);
    const overallReadiness = Math.round(allScores.reduce((a, b) => a + b, 0) / allScores.length);

    const attempts = safeGet(STORAGE_KEYS.INTERVIEW_ATTEMPTS, []);
    attempts.push({ date: new Date().toISOString(), role, level, technical, programming, dsa, debugging, speed, problemSolving, overallReadiness });
    safeSet(STORAGE_KEYS.INTERVIEW_ATTEMPTS, attempts);

    const xpResult = awardXP(XP_RULES.interview);
    const streakInfo = recordActivityToday();
    const newBadges = checkAndUnlock();

    setSummary({
      technical, programming, dsa, debugging, speed, problemSolving, overallReadiness,
      xpGained: XP_RULES.interview, leveledUp: xpResult.leveledUp, newLevel: xpResult.newLevel,
      streakDay: streakInfo.currentStreak, newBadges,
    });
  };

  if (summary) {
    const rows = [
      ['Technical Knowledge', summary.technical],
      ['Programming', summary.programming],
      ['DSA', summary.dsa],
      ['Debugging', summary.debugging],
      ['Speed', summary.speed],
      ['Problem Solving', summary.problemSolving],
    ];

    return (
      <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <p className="text-sm font-semibold uppercase tracking-wide text-indigo-600 dark:text-indigo-400">Interview Score</p>
          <div className="mt-4 space-y-2 text-left">
            {rows.filter(([, v]) => v !== null).map(([label, value]) => (
              <div key={label} className="flex items-center justify-between text-sm">
                <span className="font-medium text-slate-700 dark:text-slate-300">{label}</span>
                <span className="font-semibold text-slate-900 dark:text-white">{value}%</span>
              </div>
            ))}
          </div>

          <p className="mt-6 text-sm font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">Overall Readiness</p>
          <p className="mt-1 text-5xl font-extrabold text-slate-900 dark:text-white">{summary.overallReadiness}%</p>
          <span className="mt-2 inline-block rounded-full bg-indigo-100 px-4 py-1.5 text-sm font-semibold text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-400">
            {readinessBand(summary.overallReadiness)}
          </span>

          <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-sm">
            <span className="rounded-full bg-indigo-100 px-3 py-1 font-semibold text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-400">+{summary.xpGained} XP</span>
            {summary.leveledUp && (
              <span className="rounded-full bg-amber-100 px-3 py-1 font-semibold text-amber-700 dark:bg-amber-500/10 dark:text-amber-400">Level Up! Now Level {summary.newLevel}</span>
            )}
            {summary.newBadges?.map((b) => (
              <span key={b.id} className="rounded-full bg-emerald-100 px-3 py-1 font-semibold text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400">🏆 {b.label}</span>
            ))}
          </div>

          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <button
              type="button"
              onClick={() => { setSummary(null); setRounds(null); setRole(null); setLevel(null); }}
              className="focus-ring rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-700"
            >
              New Interview
            </button>
            <Link
              to="/dashboard"
              className="focus-ring rounded-lg border border-slate-300 bg-white px-5 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              Back to Dashboard
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (rounds) {
    return (
      <div>
        <div className="mx-auto max-w-3xl px-4 pt-6 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-2">
            {rounds.map((r, i) => (
              <span
                key={r.key}
                className={`rounded-full px-3 py-1 text-xs font-semibold ${
                  i < roundIndex
                    ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400'
                    : i === roundIndex
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'
                }`}
              >
                {i + 1}
              </span>
            ))}
          </div>
        </div>
        <InterviewRound key={roundIndex} round={rounds[roundIndex]} onComplete={handleRoundComplete} />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl dark:text-white">Interview Mode</h1>
        <p className="mt-2 text-slate-500 dark:text-slate-400">
          A 5-round simulated interview built from the existing question and debugging banks.
        </p>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <p className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Choose Role</p>
        <div className="mb-6 grid grid-cols-2 gap-2 sm:grid-cols-3">
          {Object.keys(ROLE_CONFIG).map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRole(r)}
              className={`focus-ring rounded-lg border px-3 py-2 text-sm font-semibold transition ${
                role === r
                  ? 'border-indigo-600 bg-indigo-600 text-white'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              {r}
            </button>
          ))}
        </div>

        <p className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Choose Level</p>
        <div className="mb-6 grid grid-cols-3 gap-2">
          {Object.keys(LEVEL_DIFFICULTY).map((l) => (
            <button
              key={l}
              type="button"
              onClick={() => setLevel(l)}
              className={`focus-ring rounded-lg border px-3 py-2 text-sm font-semibold transition ${
                level === l
                  ? 'border-indigo-600 bg-indigo-600 text-white'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              {l}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={startInterview}
          disabled={!role || !level}
          className="focus-ring w-full rounded-lg bg-indigo-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
        >
          Start Interview
        </button>
      </div>
    </div>
  );
}
