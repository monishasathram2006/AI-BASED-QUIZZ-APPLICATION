import { Link } from 'react-router-dom';
import { getLevelInfo, getStreakInfo } from '../utils/gamification.js';
import { getTodayActivity, getWeakTopics, getSkillAccuracy } from '../utils/progressStorage.js';
import { getTodaysChallenge, getDailyChallengeState } from '../utils/dailyChallenge.js';
import { getXP, safeGet, STORAGE_KEYS } from '../utils/storage.js';
import { categories } from '../data/categories.js';
import ProgressBar from '../components/ProgressBar.jsx';

function todayKey() {
  return new Date().toDateString();
}

export default function Dashboard() {
  const xp = getXP();
  const levelInfo = getLevelInfo(xp);
  const streak = getStreakInfo();
  const activity = getTodayActivity();

  const interviewAttempts = safeGet(STORAGE_KEYS.INTERVIEW_ATTEMPTS, []);
  const interviewReadiness = interviewAttempts.length > 0
    ? Math.round(interviewAttempts.reduce((sum, a) => sum + a.overallReadiness, 0) / interviewAttempts.length)
    : null;

  const codingToday = safeGet(STORAGE_KEYS.CODING_ATTEMPTS, []).some(
    (a) => a.passed && new Date(a.timestamp).toDateString() === todayKey()
  );

  const goals = [
    { label: 'Complete 10 quiz questions', done: activity.questionsAnswered >= 10 },
    { label: 'Practice 3 mistakes', done: activity.mistakesPracticed >= 3 },
    { label: 'Complete 1 coding challenge', done: codingToday },
  ];

  const skills = categories.map((c) => ({ name: c.name, accuracy: getSkillAccuracy(c.name) }));
  const weakTopics = getWeakTopics(3, 2);
  const dailyQuestion = getTodaysChallenge();
  const dailyState = getDailyChallengeState();

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl dark:text-white">Welcome back!</h1>
        <div className="mt-3 flex flex-wrap gap-3 text-sm">
          <span className="rounded-full bg-orange-100 px-3 py-1.5 font-semibold text-orange-700 dark:bg-orange-500/10 dark:text-orange-400">
            🔥 {streak.current} Day Streak
          </span>
          <span className="rounded-full bg-indigo-100 px-3 py-1.5 font-semibold text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-400">
            ⭐ {xp} XP
          </span>
          <span className="rounded-full bg-amber-100 px-3 py-1.5 font-semibold text-amber-700 dark:bg-amber-500/10 dark:text-amber-400">
            🏆 Level {levelInfo.level}
          </span>
        </div>
        <div className="mt-3 max-w-sm">
          <ProgressBar
            label={`Level ${levelInfo.level} Progress`}
            value={levelInfo.progressPercent}
            color="indigo"
            showPercentage={false}
          />
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {levelInfo.xpIntoLevel} / {levelInfo.xpForNextLevel} XP to Level {levelInfo.level + 1}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">
              Interview Readiness
            </h2>
            {interviewReadiness === null ? (
              <p className="text-sm text-slate-500 dark:text-slate-400">No data yet — complete an Interview Mode session to see your readiness.</p>
            ) : (
              <ProgressBar value={interviewReadiness} color={interviewReadiness >= 75 ? 'emerald' : interviewReadiness >= 50 ? 'amber' : 'red'} />
            )}
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Today's Goal</h2>
            <div className="space-y-2">
              {goals.map((g) => (
                <label key={g.label} className="flex items-center gap-2 text-sm">
                  <span
                    className={`flex h-5 w-5 items-center justify-center rounded border-2 text-xs ${
                      g.done
                        ? 'border-emerald-500 bg-emerald-500 text-white'
                        : 'border-slate-300 dark:border-slate-600'
                    }`}
                    aria-hidden="true"
                  >
                    {g.done ? '✓' : ''}
                  </span>
                  <span className={g.done ? 'text-slate-500 line-through dark:text-slate-500' : 'text-slate-700 dark:text-slate-300'}>
                    {g.label}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Quick Actions</h2>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Link to="/categories" className="focus-ring rounded-lg bg-indigo-600 px-4 py-3 text-center text-sm font-semibold text-white transition hover:bg-indigo-700">Start Quiz</Link>
              <Link to="/interview" className="focus-ring rounded-lg border border-slate-300 bg-white px-4 py-3 text-center text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800">Interview Mode</Link>
              <Link to="/debugging" className="focus-ring rounded-lg border border-slate-300 bg-white px-4 py-3 text-center text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800">Debugging Arena</Link>
              <Link to="/coding" className="focus-ring rounded-lg border border-slate-300 bg-white px-4 py-3 text-center text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800">Coding Challenge</Link>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Your Skills</h2>
            <div className="space-y-3">
              {skills.map((s) => (
                s.accuracy === null ? (
                  <div key={s.name} className="flex items-center justify-between text-sm">
                    <span className="font-medium text-slate-700 dark:text-slate-300">{s.name}</span>
                    <span className="text-slate-400 dark:text-slate-500">Not started</span>
                  </div>
                ) : (
                  <ProgressBar key={s.name} label={s.name} value={s.accuracy} color={s.accuracy >= 75 ? 'emerald' : s.accuracy >= 50 ? 'amber' : 'red'} />
                )
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Today's Challenge</h2>
            <p className="text-sm font-semibold text-slate-900 dark:text-white">🔥 Question of the Day</p>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">{dailyQuestion.question}</p>
            <Link
              to="/practice/daily"
              className={`focus-ring mt-4 inline-block rounded-lg px-4 py-2 text-sm font-semibold text-white transition ${
                dailyState.completed ? 'cursor-not-allowed bg-slate-400 dark:bg-slate-700' : 'bg-indigo-600 hover:bg-indigo-700'
              }`}
              aria-disabled={dailyState.completed}
              onClick={(e) => dailyState.completed && e.preventDefault()}
            >
              {dailyState.completed ? 'Completed Today ✓' : 'Start Challenge'}
            </Link>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">My Weak Areas</h2>
            {weakTopics.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400">Not enough data yet.</p>
            ) : (
              <ul className="space-y-1.5 text-sm">
                {weakTopics.map((t) => (
                  <li key={`${t.category}-${t.topic}`} className="text-slate-700 dark:text-slate-300">
                    🔴 {t.topic} <span className="text-slate-400">({t.category})</span>
                  </li>
                ))}
              </ul>
            )}
            <Link
              to="/practice/weak"
              className="focus-ring mt-4 inline-block rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              Practice Weak Areas
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
