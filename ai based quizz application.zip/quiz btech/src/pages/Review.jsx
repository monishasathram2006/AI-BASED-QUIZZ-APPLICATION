import { Link } from 'react-router-dom';
import { getLastResult } from '../services/progressService.js';
import ReviewQuestion from '../components/ReviewQuestion.jsx';

export default function Review() {
  const result = getLastResult();

  if (!result) {
    return (
      <div className="mx-auto max-w-xl px-4 py-24 text-center">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Nothing to review yet</h1>
        <p className="mt-2 text-slate-500 dark:text-slate-400">Finish a quiz to review your answers here.</p>
        <Link to="/categories" className="focus-ring mt-6 inline-block rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700">
          Browse Categories
        </Link>
      </div>
    );
  }

  const weakTopics = [...new Set(
    result.details.filter((d) => !d.isCorrect).map((d) => d.question.topic)
  )];

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl dark:text-white">Answer Review</h1>
        <p className="mt-2 text-slate-500 dark:text-slate-400">
          {result.category} &middot; {result.difficulty} &middot; {result.correct}/{result.total} correct
        </p>
      </div>

      {weakTopics.length > 0 && (
        <div className="mb-6 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300">
          <p className="font-semibold">Weak areas to revisit:</p>
          <p className="mt-1">{weakTopics.join(', ')}</p>
        </div>
      )}

      <div className="space-y-4">
        {result.details.map((detail, idx) => (
          <ReviewQuestion key={detail.question.id} detail={detail} index={idx} />
        ))}
      </div>

      <div className="mt-8 flex justify-center">
        <Link to="/" className="focus-ring rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700">
          Back to Dashboard
        </Link>
      </div>
    </div>
  );
}
