import { useState } from 'react';
import { Link } from 'react-router-dom';
import { categories, DOMAINS } from '../data/categories.js';
import { getQuestionsByCategory, questionBank } from '../data/questionBank.js';
import CategoryCard from '../components/CategoryCard.jsx';

export default function Home() {
  const [activeDomain, setActiveDomain] = useState('All');

  const displayedCategories =
    activeDomain === 'All'
      ? categories
      : categories.filter((c) => c.domain === activeDomain);

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-indigo-50 via-white to-slate-50 dark:from-slate-900 dark:via-slate-950 dark:to-slate-950">
        <div className="pointer-events-none absolute -top-40 right-1/2 h-96 w-96 translate-x-1/2 rounded-full bg-indigo-500/10 blur-3xl" />
        <div className="mx-auto max-w-5xl px-4 py-16 text-center sm:px-6 sm:py-24 lg:px-8">
          <div className="inline-flex items-center gap-2 rounded-full border border-indigo-200 bg-indigo-50/80 px-3.5 py-1.5 text-xs font-bold text-indigo-700 backdrop-blur-sm dark:border-indigo-500/30 dark:bg-indigo-500/10 dark:text-indigo-300">
            <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            14 Tracks &bull; {questionBank.length}+ Curated Placement Questions
          </div>

          <h1 className="mt-6 text-3xl font-extrabold tracking-tight text-slate-900 sm:text-5xl lg:text-6xl dark:text-white">
            Prepare Smarter. Code Better.
            <br />
            <span className="bg-gradient-to-r from-indigo-600 to-teal-500 bg-clip-text text-transparent">
              Crack Your Technical Interview.
            </span>
          </h1>

          <p className="mx-auto mt-5 max-w-2xl text-base text-slate-600 sm:text-lg dark:text-slate-300">
            The all-in-one technical interview prep platform for B.Tech students & software engineers.
            Practice Core CS, Languages, Full Stack, System Design, and Emerging Tech.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Link
              to="/categories"
              className="focus-ring inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-6 py-3.5 text-sm font-bold text-white shadow-md transition hover:bg-indigo-700 hover:shadow-lg"
            >
              <span>Explore All Tracks</span>
              <span aria-hidden="true">&rarr;</span>
            </Link>
            <Link
              to="/interview"
              className="focus-ring rounded-xl border border-slate-300 bg-white px-6 py-3.5 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              Interview Mode
            </Link>
            <Link
              to="/topics"
              className="focus-ring rounded-xl border border-slate-300 bg-white px-6 py-3.5 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              Search Topics
            </Link>
          </div>

          {/* Value Stats */}
          <div className="mt-12 grid grid-cols-2 gap-4 border-t border-slate-200 pt-8 dark:border-slate-800 sm:grid-cols-4">
            <div>
              <p className="text-2xl font-black text-indigo-600 dark:text-indigo-400">14</p>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Specialized Tracks</p>
            </div>
            <div>
              <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400">{questionBank.length}+</p>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Questions with Explanations</p>
            </div>
            <div>
              <p className="text-2xl font-black text-amber-600 dark:text-amber-400">3 Tiers</p>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Easy, Medium &amp; Hard</p>
            </div>
            <div>
              <p className="text-2xl font-black text-purple-600 dark:text-purple-400">Adaptive</p>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Target Weak Topics</p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Showcase Section */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mb-8 flex flex-col items-center justify-between gap-4 text-center md:flex-row md:text-left">
          <div>
            <h2 className="text-2xl font-extrabold text-slate-900 sm:text-3xl dark:text-white">
              Choose Your Specialization
            </h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Select a domain track to practice targeted topics, build streaks, and boost placement readiness.
            </p>
          </div>

          <Link
            to="/categories"
            className="focus-ring inline-flex items-center gap-1.5 text-sm font-bold text-indigo-600 hover:text-indigo-700 dark:text-indigo-400"
          >
            <span>View All Tracks ({categories.length})</span>
            <span aria-hidden="true">&rarr;</span>
          </Link>
        </div>

        {/* Domain Filter Pills */}
        <div className="mb-8 flex flex-wrap justify-center gap-2 md:justify-start">
          {DOMAINS.map((domain) => (
            <button
              key={domain}
              type="button"
              onClick={() => setActiveDomain(domain)}
              className={`focus-ring rounded-full px-4 py-1.5 text-xs font-bold transition-all ${
                activeDomain === domain
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'border border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
              }`}
            >
              {domain}
            </button>
          ))}
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {displayedCategories.map((category) => (
            <CategoryCard
              key={category.slug}
              category={category}
              questionCount={getQuestionsByCategory(category.name).length}
            />
          ))}
        </div>
      </section>
    </div>
  );
}
