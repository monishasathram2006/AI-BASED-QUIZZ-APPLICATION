import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useQuiz } from '../hooks/useQuiz.js';
import { DEBUG_LANGUAGES, DEBUG_LANGUAGE_LABELS, getDebuggingQuestionsByLanguage } from '../data/debuggingQuestions.js';
import { recordDebugAttempt, getDebugStatsSummary } from '../utils/debugStats.js';
import QuizRunner from '../components/Quiz/QuizRunner.jsx';
import ScoreCard from '../components/ScoreCard.jsx';

const LANGUAGE_ICONS = { c: '🔧', cpp: '⚙️', java: '☕', python: '🐍', javascript: '🌐' };

export default function Debugging() {
  const quiz = useQuiz();
  const { state } = quiz;
  const [phase, setPhase] = useState('pick'); // pick | quiz | result
  const [language, setLanguage] = useState(null);
  const [resultSummary, setResultSummary] = useState(null);
  const startedRef = useRef(false);

  const startArena = (lang) => {
    const raw = getDebuggingQuestionsByLanguage(lang);
    const questions = raw.map((q) => ({ ...q, question: 'Find the bug in this code.' }));
    setLanguage(lang);
    startedRef.current = false;
    quiz.startQuiz({
      categorySlug: 'debugging',
      categoryName: `Debugging Arena: ${DEBUG_LANGUAGE_LABELS[lang]}`,
      difficultyParam: lang,
      difficultyLabel: 'Debugging',
      questions,
      totalSeconds: Math.max(300, questions.length * 60),
    });
    setPhase('quiz');
  };

  const handleSubmit = () => {
    if (state.status !== 'active') return;
    const summary = recordDebugAttempt({ language, questions: state.questions, answers: state.answers });
    setResultSummary(summary);
    quiz.reset();
    setPhase('result');
  };

  useEffect(() => {
    if (phase !== 'quiz') return undefined;
    if (state.status !== 'active') return undefined;
    const id = setInterval(() => quiz.tick(), 1000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, state.status]);

  useEffect(() => {
    if (phase === 'quiz' && state.status === 'active' && state.remainingSeconds <= 0) {
      handleSubmit();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, state.status, state.remainingSeconds]);

  if (phase === 'pick') {
    const stats = getDebugStatsSummary();
    return (
      <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl dark:text-white">Debugging Arena</h1>
          <p className="mt-2 text-slate-500 dark:text-slate-400">
            Find the bug in real code snippets across five languages.
          </p>
        </div>

        {stats.attempts > 0 && (
          <div className="mb-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <ScoreCard label="Debugging Score" value={`${stats.accuracy}%`} accent="text-indigo-600 dark:text-indigo-400" />
            <ScoreCard label="Questions Attempted" value={stats.attempts} />
            <ScoreCard label="XP Earned" value={stats.xpEarned} accent="text-amber-600 dark:text-amber-400" />
            <ScoreCard label="Sessions" value={stats.history.length} />
          </div>
        )}

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {DEBUG_LANGUAGES.map((lang) => (
            <button
              key={lang}
              type="button"
              onClick={() => startArena(lang)}
              className="focus-ring group flex flex-col items-center rounded-2xl border border-slate-200 bg-white p-6 text-center shadow-sm transition hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
            >
              <span className="text-4xl">{LANGUAGE_ICONS[lang]}</span>
              <span className="mt-3 text-lg font-bold text-slate-900 dark:text-white">{DEBUG_LANGUAGE_LABELS[lang]}</span>
              <span className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                {getDebuggingQuestionsByLanguage(lang).length} bugs to find
              </span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (phase === 'quiz') {
    return (
      <QuizRunner
        headerContent={
          <p className="text-lg font-bold text-slate-900 dark:text-white">
            Debugging Arena <span className="text-slate-300 dark:text-slate-600">|</span> {DEBUG_LANGUAGE_LABELS[language]}
          </p>
        }
        onSubmit={handleSubmit}
      />
    );
  }

  // phase === 'result'
  const { result, weakConcept, xpGained, leveledUp, newLevel, newBadges } = resultSummary;
  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <p className="text-sm font-semibold uppercase tracking-wide text-indigo-600 dark:text-indigo-400">Debugging Score</p>
        <p className="mt-2 text-5xl font-extrabold text-slate-900 dark:text-white">{result.score}%</p>

        <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-sm">
          <span className="rounded-full bg-indigo-100 px-3 py-1 font-semibold text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-400">+{xpGained} XP</span>
          {leveledUp && (
            <span className="rounded-full bg-amber-100 px-3 py-1 font-semibold text-amber-700 dark:bg-amber-500/10 dark:text-amber-400">Level Up! Now Level {newLevel}</span>
          )}
          {newBadges?.map((b) => (
            <span key={b.id} className="rounded-full bg-emerald-100 px-3 py-1 font-semibold text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400">🏆 {b.label}</span>
          ))}
        </div>

        <div className="mt-6 grid grid-cols-3 gap-3">
          <ScoreCard label="Correct" value={result.correctAnswers} accent="text-emerald-600 dark:text-emerald-400" />
          <ScoreCard label="Wrong" value={result.wrongAnswers} accent="text-red-600 dark:text-red-400" />
          <ScoreCard label="Total" value={result.totalQuestions} />
        </div>

        {weakConcept && (
          <div className="mt-6 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm dark:border-amber-500/30 dark:bg-amber-500/10">
            <p className="font-semibold text-amber-800 dark:text-amber-400">Weak concept: {weakConcept}</p>
          </div>
        )}

        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <button
            type="button"
            onClick={() => startArena(language)}
            className="focus-ring rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-700"
          >
            Practice Similar Bugs
          </button>
          <button
            type="button"
            onClick={() => setPhase('pick')}
            className="focus-ring rounded-lg border border-slate-300 bg-white px-5 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            Choose Another Language
          </button>
          <Link
            to="/dashboard"
            className="focus-ring rounded-lg border border-slate-300 bg-white px-5 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            Back to Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}
