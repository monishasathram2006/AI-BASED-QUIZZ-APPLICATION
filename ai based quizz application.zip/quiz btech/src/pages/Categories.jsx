import { useState, useMemo } from 'react';
import { categories, DOMAINS } from '../data/categories.js';
import { getQuestionsByCategory, questionBank } from '../data/questionBank.js';
import CategoryCard from '../components/CategoryCard.jsx';

export default function Categories() {
  const [selectedDomain, setSelectedDomain] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('default');

  const filteredCategories = useMemo(() => {
    let result = categories;

    // Filter by Domain
    if (selectedDomain !== 'All') {
      result = result.filter((c) => c.domain === selectedDomain);
    }

    // Filter by Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.shortName?.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q) ||
          c.domain?.toLowerCase().includes(q) ||
          c.topics?.some((t) => t.toLowerCase().includes(q))
      );
    }

    // Sort
    if (sortBy === 'name') {
      result = [...result].sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortBy === 'topics') {
      result = [...result].sort((a, b) => (b.topics?.length || 0) - (a.topics?.length || 0));
    }

    return result;
  }, [selectedDomain, searchQuery, sortBy]);

  const domainCounts = useMemo(() => {
    const counts = { All: categories.length };
    categories.forEach((c) => {
      if (c.domain) {
        counts[c.domain] = (counts[c.domain] || 0) + 1;
      }
    });
    return counts;
  }, []);

  return (
    <div className="min-h-screen bg-slate-50/50 py-10 dark:bg-slate-950">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="relative mb-10 overflow-hidden rounded-3xl border border-slate-200/80 bg-gradient-to-br from-indigo-900 via-slate-900 to-indigo-950 p-8 text-white shadow-xl dark:border-slate-800 sm:p-12">
          {/* Subtle background glow */}
          <div className="pointer-events-none absolute -right-20 -top-20 h-80 w-80 rounded-full bg-indigo-500/20 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-20 -left-20 h-80 w-80 rounded-full bg-teal-500/10 blur-3xl" />

          <div className="relative z-10 max-w-3xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-indigo-400/30 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300 backdrop-blur-sm">
              <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              14 Curated Tracks • {questionBank.length}+ Real Interview Questions
            </div>

            <h1 className="mt-4 text-3xl font-extrabold tracking-tight text-white sm:text-4xl lg:text-5xl">
              Quiz Tracks & Interview Specializations
            </h1>

            <p className="mt-3 text-base text-slate-300 sm:text-lg">
              Explore core computer science, software engineering languages, full-stack, system design,
              and emerging tech domains. Practice at your own pace with adaptive questions.
            </p>

            {/* Quick stats pills */}
            <div className="mt-6 flex flex-wrap gap-3 pt-2 text-xs font-medium text-slate-300">
              <span className="inline-flex items-center gap-1.5 rounded-lg bg-white/10 px-3 py-1.5 backdrop-blur-sm">
                📚 14 Tracks
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-lg bg-white/10 px-3 py-1.5 backdrop-blur-sm">
                🎯 {questionBank.length} Questions
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-lg bg-white/10 px-3 py-1.5 backdrop-blur-sm">
                ⚡ 3 Tiers (Easy, Med, Hard)
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-lg bg-white/10 px-3 py-1.5 backdrop-blur-sm">
                🧠 Adaptive Questioning
              </span>
            </div>
          </div>
        </div>

        {/* Search, Filter, and Sort Controls */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                🔍
              </div>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search tracks, topics (e.g. 'Trees', 'SQL', 'Docker')..."
                className="focus-ring w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-10 pr-4 text-sm text-slate-900 placeholder-slate-400 shadow-sm transition hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900 dark:text-white dark:placeholder-slate-500"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute inset-y-0 right-0 flex items-center pr-3 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Sort Selector */}
            <div className="flex items-center gap-2 self-end sm:self-auto">
              <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Sort by:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="focus-ring rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-sm dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200"
              >
                <option value="default">Featured Tracks</option>
                <option value="name">Track Name (A-Z)</option>
                <option value="topics">Most Topics</option>
              </select>
            </div>
          </div>

          {/* Domain Filter Pills */}
          <div className="flex flex-wrap items-center gap-2 overflow-x-auto pb-1">
            {DOMAINS.map((domain) => {
              const active = selectedDomain === domain;
              const count = domainCounts[domain] || 0;
              return (
                <button
                  key={domain}
                  type="button"
                  onClick={() => setSelectedDomain(domain)}
                  className={`focus-ring inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-semibold transition-all ${
                    active
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'border border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
                  }`}
                >
                  <span>{domain}</span>
                  <span
                    className={`rounded-full px-1.5 py-0.2 text-[10px] ${
                      active
                        ? 'bg-indigo-700/60 text-white'
                        : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Results Info */}
        <div className="mb-4 flex items-center justify-between text-xs font-medium text-slate-500 dark:text-slate-400">
          <span>
            Showing <strong className="text-slate-900 dark:text-white">{filteredCategories.length}</strong> of{' '}
            {categories.length} quiz tracks
          </span>
          {(searchQuery || selectedDomain !== 'All') && (
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSelectedDomain('All');
              }}
              className="font-semibold text-indigo-600 hover:underline dark:text-indigo-400"
            >
              Reset all filters
            </button>
          )}
        </div>

        {/* Category Cards Grid */}
        {filteredCategories.length > 0 ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredCategories.map((category) => (
              <CategoryCard
                key={category.slug}
                category={category}
                questionCount={getQuestionsByCategory(category.name).length}
              />
            ))}
          </div>
        ) : (
          /* Empty State */
          <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center dark:border-slate-800 dark:bg-slate-900">
            <span className="inline-block text-4xl" role="img" aria-label="Not found">
              🔎
            </span>
            <h3 className="mt-3 text-lg font-bold text-slate-900 dark:text-white">
              No matching quiz tracks found
            </h3>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              We couldn't find any tracks matching "{searchQuery}". Try a different keyword or category.
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSelectedDomain('All');
              }}
              className="focus-ring mt-5 inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-indigo-700"
            >
              Clear Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
