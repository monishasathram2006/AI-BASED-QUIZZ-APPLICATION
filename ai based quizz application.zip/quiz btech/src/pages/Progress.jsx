import { Link } from 'react-router-dom';
import { getOverallStats, getAllCategoryProgress, getAllAttempts } from '../services/progressService.js';
import { questionBank } from '../data/questionBank.js';
import { getLevelInfo, getStreakInfo } from '../utils/gamification.js';
import { getXP, safeGet, STORAGE_KEYS } from '../utils/storage.js';
import { getDebugStatsSummary } from '../utils/debugStats.js';
import { getBucketAccuracy } from '../utils/progressStorage.js';
import ScoreCard from '../components/ScoreCard.jsx';
import PerformanceChart from '../components/PerformanceChart.jsx';
import ProgressBar from '../components/ProgressBar.jsx';

function readinessColor(v) {
  if (v >= 75) return 'emerald';
  if (v >= 50) return 'amber';
  return 'red';
}

export default function Progress() {
  const stats = getOverallStats();
  const categoryProgress = getAllCategoryProgress();
  const attempts = getAllAttempts();
  const recentAttempts = [...attempts].reverse().slice(0, 8);

  const xp = getXP();
  const levelInfo = getLevelInfo(xp);
  const streak = getStreakInfo();
  const interviewAttempts = safeGet(STORAGE_KEYS.INTERVIEW_ATTEMPTS, []);
  const debugStats = getDebugStatsSummary();

  const avgInterviewMetric = (key) => {
    const values = interviewAttempts.map((a) => a[key]).filter((v) => v !== null && v !== undefined);
    return values.length > 0 ? Math.round(values.reduce((a, b) => a + b, 0) / values.length) : null;
  };

  const readinessRows = [
    ['Technical Knowledge', avgInterviewMetric('technical')],
    ['DSA', getBucketAccuracy('DSA')],
    ['Coding', avgInterviewMetric('programming')],
    ['Debugging', debugStats.accuracy],
    ['Problem Solving', avgInterviewMetric('problemSolving')],
  ];
  const knownReadiness = readinessRows.map(([, v]) => v).filter((v) => v !== null);
  const overallReadiness = knownReadiness.length > 0 ? Math.round(knownReadiness.reduce((a, b) => a + b, 0) / knownReadiness.length) : null;
  const weakestMetric = readinessRows.filter(([, v]) => v !== null).sort((a, b) => a[1] - b[1])[0];

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl dark:text-white">Your Progress</h1>
        <p className="mt-2 text-slate-500 dark:text-slate-400">
          Stats are calculated live from your quiz history, stored locally on this device.
        </p>
      </div>

      <div className="mb-8 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <h2 className="mb-4 text-lg font-bold text-slate-900 dark:text-white">CodePrep Profile</h2>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">Current Streak</p>
            <p className="mt-1 text-2xl font-bold text-orange-600 dark:text-orange-400">🔥 {streak.current} days</p>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">XP</p>
            <p className="mt-1 text-2xl font-bold text-indigo-600 dark:text-indigo-400">⭐ {xp.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">Level</p>
            <p className="mt-1 text-2xl font-bold text-amber-600 dark:text-amber-400">🏆 {levelInfo.level}</p>
          </div>
        </div>
        <div className="mt-4">
          <ProgressBar value={levelInfo.progressPercent} color="indigo" showPercentage={false} />
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {levelInfo.xpIntoLevel} / {levelInfo.xpForNextLevel} XP to Level {levelInfo.level + 1}
          </p>
        </div>
        <div className="mt-5 flex flex-wrap gap-1.5">
          {streak.last7Days.map((d) => (
            <span
              key={d.date}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold ${
                d.done
                  ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400'
                  : 'bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-500'
              }`}
            >
              {d.day} {d.done ? '✓' : ''}
            </span>
          ))}
        </div>
      </div>

      <div className="mb-8 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <h2 className="mb-4 text-lg font-bold text-slate-900 dark:text-white">Interview Readiness</h2>
        {overallReadiness === null ? (
          <p className="text-sm text-slate-500 dark:text-slate-400">No data yet — complete an Interview Mode session or Debugging Arena challenge to see your readiness.</p>
        ) : (
          <>
            <ProgressBar value={overallReadiness} color={readinessColor(overallReadiness)} />
            <div className="mt-4 space-y-3">
              {readinessRows.map(([label, value]) => (
                value === null ? (
                  <div key={label} className="flex items-center justify-between text-sm">
                    <span className="font-medium text-slate-700 dark:text-slate-300">{label}</span>
                    <span className="text-slate-400 dark:text-slate-500">Not started</span>
                  </div>
                ) : (
                  <ProgressBar key={label} label={label} value={value} color={readinessColor(value)} />
                )
              ))}
            </div>
            {weakestMetric && (
              <div className="mt-5 rounded-xl border border-amber-200 bg-amber-50 p-4 dark:border-amber-500/30 dark:bg-amber-500/10">
                <p className="text-xs font-bold uppercase tracking-wide text-amber-700 dark:text-amber-400">Your Next Goal</p>
                <p className="mt-1 text-sm font-semibold text-amber-800 dark:text-amber-300">
                  Improve {weakestMetric[0]}: {weakestMetric[1]}% → {Math.min(100, weakestMetric[1] + 12)}%
                </p>
                <Link
                  to="/practice/weak"
                  className="focus-ring mt-3 inline-block rounded-lg bg-amber-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-amber-700"
                >
                  Start Practice
                </Link>
              </div>
            )}
          </>
        )}
      </div>

      <div className="mb-10 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <ScoreCard label="Total Questions" value={questionBank.length} />
        <ScoreCard label="Total Quizzes" value={stats.totalQuizzes} />
        <ScoreCard label="Questions Attempted" value={stats.questionsAttempted} />
        <ScoreCard label="Correct Answers" value={stats.correctAnswers} accent="text-emerald-600 dark:text-emerald-400" />
        <ScoreCard label="Accuracy" value={`${stats.accuracy}%`} accent="text-indigo-600 dark:text-indigo-400" />
        <ScoreCard label="Average Score" value={`${stats.averageScore}%`} />
        <ScoreCard label="Best Score" value={`${stats.bestScore}%`} accent="text-emerald-600 dark:text-emerald-400" />
        <ScoreCard label="Current Streak" value={`${stats.currentStreak} day${stats.currentStreak === 1 ? '' : 's'}`} accent="text-amber-600 dark:text-amber-400" />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <PerformanceChart categoryProgress={categoryProgress} />

        <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h3 className="mb-4 text-lg font-semibold text-slate-900 dark:text-white">Recent Attempts</h3>
          {recentAttempts.length === 0 ? (
            <p className="text-sm text-slate-500 dark:text-slate-400">
              No quizzes taken yet.{' '}
              <Link to="/categories" className="font-semibold text-indigo-600 hover:underline dark:text-indigo-400">
                Start your first quiz
              </Link>
              .
            </p>
          ) : (
            <ul className="divide-y divide-slate-100 dark:divide-slate-800">
              {recentAttempts.map((a) => (
                <li key={a.id} className="flex items-center justify-between py-2.5 text-sm">
                  <span className="text-slate-700 dark:text-slate-300">
                    {a.category} <span className="text-slate-400">&middot;</span> {a.difficulty}
                  </span>
                  <span className="font-semibold text-slate-900 dark:text-white">{a.percentage}%</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
