import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { roadmaps } from '../data/roadmaps.js';
import { getTopicStats } from '../utils/progressStorage.js';
import { getCategoryByName } from '../data/categories.js';

function stepStatus(step, topicStatsByCategory) {
  if (step.comingSoon) {
    return {
      icon: '○',
      label: 'Content coming soon',
      style: 'text-slate-400 dark:text-slate-600',
      badge: 'bg-slate-100 text-slate-500 dark:bg-slate-800',
      clickable: false,
    };
  }

  const categoryStats = topicStatsByCategory[step.category] ?? {};
  let correct = 0;
  let total = 0;
  step.matchTopics.forEach((topic) => {
    const t = categoryStats[topic];
    if (t) {
      correct += t.correct;
      total += t.total;
    }
  });

  if (total === 0) {
    return {
      icon: '○',
      label: 'Not started',
      style: 'text-slate-400 dark:text-slate-500',
      badge: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400',
      clickable: true,
    };
  }

  const accuracy = Math.round((correct / total) * 100);
  if (accuracy >= 80) {
    return {
      icon: '✓',
      label: `${accuracy}% mastered`,
      style: 'text-emerald-600 dark:text-emerald-400',
      badge: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400',
      clickable: true,
    };
  }
  if (accuracy >= 40) {
    return {
      icon: '🟡',
      label: `${accuracy}% — in progress`,
      style: 'text-amber-600 dark:text-amber-400',
      badge: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400',
      clickable: true,
    };
  }
  return {
    icon: '🔴',
    label: `${accuracy}% — needs review`,
    style: 'text-rose-600 dark:text-rose-400',
    badge: 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-400',
    clickable: true,
  };
}

export default function Roadmap() {
  const navigate = useNavigate();
  const [activeSlug, setActiveSlug] = useState(roadmaps[0].slug);
  const active = roadmaps.find((r) => r.slug === activeSlug) || roadmaps[0];
  const topicStatsByCategory = getTopicStats();

  const handleStepClick = (step) => {
    if (step.comingSoon) return;
    const category = getCategoryByName(step.category);
    if (!category) return;
    navigate(`/category/${category.slug}`);
  };

  return (
    <div className="min-h-screen bg-slate-50/50 py-10 dark:bg-slate-950 sm:py-12">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8 text-center sm:text-left">
          <div className="inline-flex items-center gap-2 rounded-full border border-indigo-200 bg-indigo-50 px-3 py-1 text-xs font-bold text-indigo-700 dark:border-indigo-500/30 dark:bg-indigo-500/10 dark:text-indigo-300">
            <span>🗺️</span> Technical Milestones &amp; Learning Paths
          </div>
          <h1 className="mt-3 text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl dark:text-white">
            Learning Roadmaps
          </h1>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
            Step-by-step technical roadmaps computed from your live quiz attempts. Click any milestone to practice.
          </p>
        </div>

        {/* Roadmap Selector Tabs */}
        <div className="mb-8 flex flex-wrap gap-2 overflow-x-auto pb-2">
          {roadmaps.map((r) => {
            const isActive = activeSlug === r.slug;
            return (
              <button
                key={r.slug}
                type="button"
                onClick={() => setActiveSlug(r.slug)}
                className={`focus-ring inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'border border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
                }`}
              >
                <span>{r.title.replace(' Roadmap', '')}</span>
              </button>
            );
          })}
        </div>

        {/* Active Roadmap Timeline Card */}
        <div className="rounded-3xl border border-slate-200/90 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 sm:p-10">
          <div className="mb-8 flex flex-col gap-2 border-b border-slate-100 pb-6 text-center sm:flex-row sm:items-center sm:justify-between sm:text-left dark:border-slate-800">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                Current Curriculum
              </span>
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white sm:text-2xl">
                {active.title}
              </h2>
            </div>
            <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300">
              {active.steps.length} Milestones
            </span>
          </div>

          {/* Timeline Steps */}
          <div className="space-y-4">
            {active.steps.map((step, idx) => {
              const status = stepStatus(step, topicStatsByCategory);
              const firstTopic = step.matchTopics?.[0];

              return (
                <div key={step.label} className="relative">
                  <div
                    className={`flex flex-col gap-3 rounded-2xl border p-4.5 transition-all sm:flex-row sm:items-center sm:justify-between ${
                      status.clickable
                        ? 'border-slate-200 bg-white hover:border-indigo-300 hover:shadow-md dark:border-slate-800 dark:bg-slate-900/80 dark:hover:border-indigo-500/40'
                        : 'border-dashed border-slate-200 bg-slate-50/60 opacity-60 dark:border-slate-800 dark:bg-slate-900/40'
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      {/* Step Number Circle */}
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-indigo-50 font-mono text-sm font-bold text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300">
                        {idx + 1}
                      </span>

                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="font-bold text-slate-900 dark:text-white">
                            {step.label}
                          </h3>
                          <span
                            className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${status.badge}`}
                          >
                            {status.label}
                          </span>
                        </div>

                        {step.matchTopics && (
                          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                            Topics: {step.matchTopics.slice(0, 3).join(', ')}
                            {step.matchTopics.length > 3 && ` +${step.matchTopics.length - 3} more`}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    {status.clickable && (
                      <div className="flex items-center gap-2 self-end sm:self-auto">
                        {firstTopic && (
                          <Link
                            to={`/practice/weak?category=${encodeURIComponent(
                              step.category
                            )}&topic=${encodeURIComponent(firstTopic)}`}
                            className="focus-ring inline-flex items-center gap-1 rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm transition hover:bg-indigo-700"
                          >
                            <span>⚡ Practice Step</span>
                          </Link>
                        )}
                        <button
                          type="button"
                          onClick={() => handleStepClick(step)}
                          className="focus-ring inline-flex items-center gap-1 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-700 transition hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                        >
                          <span>Track Hub</span> &rarr;
                        </button>
                      </div>
                    )}
                  </div>

                  {idx < active.steps.length - 1 && (
                    <div className="ml-7 h-4 w-0.5 bg-slate-200 dark:bg-slate-800" aria-hidden="true" />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
