import { Link } from 'react-router-dom';
import ScoreCard from './ScoreCard.jsx';
import ProgressBar from './ProgressBar.jsx';
import { formatTime, getTopicBreakdown } from '../utils/quizUtils.js';

const PERF_STYLES = {
  emerald: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400',
  blue: 'bg-blue-100 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400',
  amber: 'bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400',
  orange: 'bg-orange-100 text-orange-700 dark:bg-orange-500/10 dark:text-orange-400',
  red: 'bg-red-100 text-red-700 dark:bg-red-500/10 dark:text-red-400',
};

function topicBarColor(accuracy) {
  if (accuracy >= 80) return 'emerald';
  if (accuracy >= 60) return 'amber';
  return 'red';
}

export default function ResultCard({ result }) {
  const {
    total, correct, wrong, unanswered, percentage, pointsEarned, timeTakenSeconds, performance,
    performanceMessage, details, xpGained, leveledUp, newLevel, streakDay, newBadges,
  } = result;

  const topicBreakdown = details ? getTopicBreakdown(details) : [];
  const weakAreas = topicBreakdown.filter((t) => t.accuracy < 60);

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center shadow-sm sm:p-8 dark:border-slate-800 dark:bg-slate-900">
      <p className="text-sm font-semibold uppercase tracking-wide text-indigo-600 dark:text-indigo-400">
        Quiz Completed!
      </p>
      <p className="mt-2 text-5xl font-extrabold text-slate-900 dark:text-white">{percentage}%</p>
      <span className={`mt-3 inline-block rounded-full px-4 py-1.5 text-sm font-semibold ${PERF_STYLES[performance.color]}`}>
        {performance.label}
      </span>
      {performanceMessage && (
        <p className="mt-3 text-sm text-slate-600 dark:text-slate-400">{performanceMessage}</p>
      )}

      {typeof xpGained === 'number' && (
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-sm">
          <span className="rounded-full bg-indigo-100 px-3 py-1 font-semibold text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-400">
            +{xpGained} XP
          </span>
          {leveledUp && (
            <span className="rounded-full bg-amber-100 px-3 py-1 font-semibold text-amber-700 dark:bg-amber-500/10 dark:text-amber-400">
              Level Up! Now Level {newLevel}
            </span>
          )}
          {typeof streakDay === 'number' && streakDay > 0 && (
            <span className="rounded-full bg-orange-100 px-3 py-1 font-semibold text-orange-700 dark:bg-orange-500/10 dark:text-orange-400">
              🔥 {streakDay} Day Streak
            </span>
          )}
          {newBadges?.map((b) => (
            <span key={b.id} className="rounded-full bg-emerald-100 px-3 py-1 font-semibold text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400">
              🏆 {b.label}
            </span>
          ))}
        </div>
      )}

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
        <ScoreCard label="Correct Answers" value={correct} accent="text-emerald-600 dark:text-emerald-400" />
        <ScoreCard label="Wrong Answers" value={wrong} accent="text-red-600 dark:text-red-400" />
        <ScoreCard label="Unanswered" value={unanswered} accent="text-slate-500 dark:text-slate-400" />
        <ScoreCard label="Total Questions" value={total} />
        <ScoreCard label="Time Taken" value={formatTime(timeTakenSeconds)} />
        <ScoreCard label="Points Earned" value={pointsEarned} accent="text-indigo-600 dark:text-indigo-400" />
      </div>

      {topicBreakdown.length > 0 && (
        <div className="mt-8 text-left">
          <h3 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">
            Your Performance
          </h3>
          <div className="space-y-3 rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/40">
            {topicBreakdown.map((t) => (
              <ProgressBar key={t.topic} label={t.topic} value={t.accuracy} color={topicBarColor(t.accuracy)} />
            ))}
          </div>
        </div>
      )}

      {weakAreas.length > 0 && (
        <div className="mt-6 text-left">
          <h3 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">
            Weak Areas
          </h3>
          <div className="flex flex-wrap gap-2">
            {weakAreas.map((t) => (
              <span key={t.topic} className="rounded-full bg-red-100 px-3 py-1.5 text-sm font-medium text-red-700 dark:bg-red-500/10 dark:text-red-400">
                🔴 {t.topic}
              </span>
            ))}
          </div>
          <h3 className="mb-3 mt-4 text-sm font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">
            Recommended Practice
          </h3>
          <div className="flex flex-wrap gap-2">
            {weakAreas.map((t) => (
              <Link
                key={t.topic}
                to={`/practice/weak?category=${encodeURIComponent(result.category)}&topic=${encodeURIComponent(t.topic)}`}
                className="focus-ring rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                Practice {t.topic}
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
