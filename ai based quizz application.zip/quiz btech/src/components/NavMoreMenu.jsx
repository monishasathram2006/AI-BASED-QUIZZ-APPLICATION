import { useState, useRef, useEffect } from 'react';
import { NavLink } from 'react-router-dom';

const MORE_LINKS = [
  { to: '/topics', label: 'Topics', desc: 'Browse 350+ topics & questions', icon: '🏷️' },
  { to: '/roadmap', label: 'Roadmap', desc: 'Step-by-step career tracks', icon: '🗺️' },
  { to: '/interview', label: 'Interview', desc: '5-round placement simulation', icon: '💼' },
  { to: '/coding', label: 'Coding', desc: 'Hands-on code challenges', icon: '💻' },
  { to: '/debugging', label: 'Debugging', desc: 'Bug-fixing arena (5 languages)', icon: '🐞' },
  { to: '/companies', label: 'Companies', desc: 'FAANG & tier-1 prep readiness', icon: '🏢' },
  { to: '/mistakes', label: 'My Mistakes', desc: 'Target previously missed questions', icon: '❌' },
  { to: '/coach', label: 'Coach', desc: 'Adaptive 7-day personal plan', icon: '🎓' },
];

export default function NavMoreMenu() {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const onClickOutside = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, [open]);

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="true"
        aria-expanded={open}
        className={`focus-ring flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-semibold transition ${
          open
            ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-400'
            : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white'
        }`}
      >
        <span>More</span>
        <span
          className={`text-xs transition-transform duration-200 ${open ? 'rotate-180' : ''}`}
          aria-hidden="true"
        >
          ▾
        </span>
      </button>

      {open && (
        <div
          className="absolute right-0 top-full z-50 mt-2 w-80 rounded-2xl border border-slate-200/90 bg-white/95 p-2 shadow-2xl backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/95"
          role="menu"
        >
          <div className="px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            Practice &amp; Preparation Tools
          </div>
          <div className="grid grid-cols-1 gap-1">
            {MORE_LINKS.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                onClick={() => setOpen(false)}
                role="menuitem"
                className={({ isActive }) =>
                  `focus-ring flex items-start gap-3 rounded-xl px-3 py-2.5 transition ${
                    isActive
                      ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-400'
                      : 'text-slate-700 hover:bg-slate-100/80 dark:text-slate-200 dark:hover:bg-slate-800/80'
                  }`
                }
              >
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-base dark:bg-slate-800">
                  {link.icon}
                </span>
                <div className="flex-1">
                  <div className="text-sm font-bold text-slate-900 dark:text-white">
                    {link.label}
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    {link.desc}
                  </div>
                </div>
              </NavLink>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
