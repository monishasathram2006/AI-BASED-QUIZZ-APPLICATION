import { NavLink } from 'react-router-dom';

const LINKS = [
  { to: '/', label: 'Home', icon: '🏠' },
  { to: '/dashboard', label: 'Dashboard', icon: '📊' },
  { to: '/categories', label: 'Categories', icon: '📚' },
  { to: '/topics', label: 'Topics', icon: '🏷️' },
  { to: '/roadmap', label: 'Roadmap', icon: '🗺️' },
  { to: '/interview', label: 'Interview', icon: '💼' },
  { to: '/coding', label: 'Coding', icon: '💻' },
  { to: '/debugging', label: 'Debugging', icon: '🐞' },
  { to: '/companies', label: 'Companies', icon: '🏢' },
  { to: '/mistakes', label: 'My Mistakes', icon: '❌' },
  { to: '/coach', label: 'Coach', icon: '🎓' },
  { to: '/progress', label: 'My Progress', icon: '📈' },
];

export default function Sidebar({ open, onClose }) {
  return (
    <>
      <div
        className={`fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-sm transition-opacity md:hidden ${
          open ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
        onClick={onClose}
        aria-hidden="true"
      />
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-72 transform overflow-y-auto bg-white p-5 shadow-2xl transition-transform duration-300 md:hidden dark:bg-slate-900 ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
        aria-label="Mobile navigation"
        aria-hidden={!open}
      >
        <div className="mb-6 flex items-center justify-between border-b border-slate-100 pb-4 dark:border-slate-800">
          <span className="text-xl font-black text-slate-900 dark:text-white">
            Code<span className="text-indigo-600 dark:text-indigo-400">Prep</span>
          </span>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close menu"
            className="focus-ring rounded-lg p-2 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          >
            ✕
          </button>
        </div>
        <nav className="flex flex-col gap-1">
          {LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              onClick={onClose}
              className={({ isActive }) =>
                `focus-ring flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-semibold transition ${
                  isActive
                    ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-400'
                    : 'text-slate-700 hover:bg-slate-50 dark:text-slate-300 dark:hover:bg-slate-800'
                }`
              }
            >
              <span className="text-lg">{link.icon}</span>
              <span>{link.label}</span>
            </NavLink>
          ))}
        </nav>
      </aside>
    </>
  );
}
