export default function QuizCard({ title, subtitle, icon, onClick, className = '' }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`focus-ring flex w-full items-center gap-4 rounded-xl border border-slate-200 bg-white p-4 text-left transition hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-slate-900 ${className}`}
    >
      {icon && <span className="text-2xl" aria-hidden="true">{icon}</span>}
      <span>
        <span className="block font-semibold text-slate-900 dark:text-white">{title}</span>
        {subtitle && <span className="block text-sm text-slate-500 dark:text-slate-400">{subtitle}</span>}
      </span>
    </button>
  );
}
