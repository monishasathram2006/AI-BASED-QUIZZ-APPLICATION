import CodeBlock from './CodeBlock.jsx';

export default function ReviewQuestion({ detail, index }) {
  const { question, selected, isAnswered, isCorrect } = detail;

  const statusStyles = isCorrect
    ? 'border-emerald-300 dark:border-emerald-500/40'
    : isAnswered
      ? 'border-red-300 dark:border-red-500/40'
      : 'border-slate-200 dark:border-slate-800';

  const badge = isCorrect
    ? { text: 'Correct', cls: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400' }
    : isAnswered
      ? { text: 'Incorrect', cls: 'bg-red-100 text-red-700 dark:bg-red-500/10 dark:text-red-400' }
      : { text: 'Unanswered', cls: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400' };

  return (
    <div className={`rounded-2xl border-2 bg-white p-5 shadow-sm dark:bg-slate-900 ${statusStyles}`}>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <span className="text-sm font-semibold text-slate-500 dark:text-slate-400">Question {index + 1}</span>
        <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${badge.cls}`}>{badge.text}</span>
      </div>

      <p className="font-medium text-slate-900 dark:text-white">{question.question}</p>

      {question.code && (
        <div className="mt-3">
          <CodeBlock code={question.code} language={question.language} />
        </div>
      )}

      <div className="mt-4 space-y-1.5 text-sm">
        <p>
          <span className="font-medium text-slate-600 dark:text-slate-400">Your Answer: </span>
          <span className={isAnswered ? (isCorrect ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-700 dark:text-red-400') : 'italic text-slate-400'}>
            {selected ?? 'Not answered'}
          </span>
        </p>
        {!isCorrect && (
          <p>
            <span className="font-medium text-slate-600 dark:text-slate-400">Correct Answer: </span>
            <span className="text-emerald-700 dark:text-emerald-400">{question.correctAnswer}</span>
          </p>
        )}
      </div>

      <p className="mt-3 rounded-lg bg-slate-50 p-3 text-sm text-slate-600 dark:bg-slate-800/60 dark:text-slate-400">
        {question.explanation}
      </p>
    </div>
  );
}
