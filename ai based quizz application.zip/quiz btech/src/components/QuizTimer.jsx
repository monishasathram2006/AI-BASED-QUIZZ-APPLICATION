import { formatTime } from '../utils/quizUtils.js';

export default function QuizTimer({ remainingSeconds, totalSeconds }) {
  const pct = totalSeconds > 0 ? (remainingSeconds / totalSeconds) * 100 : 0;
  const isLow = pct <= 15;
  const isMedium = pct > 15 && pct <= 35;

  const colorClass = isLow
    ? 'text-red-600 dark:text-red-400'
    : isMedium
      ? 'text-amber-600 dark:text-amber-400'
      : 'text-slate-900 dark:text-white';

  return (
    <div
      className={`flex items-center gap-2 rounded-lg border px-3 py-1.5 font-mono text-sm font-semibold ${colorClass} ${isLow ? 'border-red-300 bg-red-50 dark:border-red-500/40 dark:bg-red-500/10' : 'border-slate-200 bg-slate-50 dark:border-slate-700 dark:bg-slate-800'}`}
      role="timer"
      aria-live="polite"
      aria-label={`Time remaining ${formatTime(remainingSeconds)}`}
    >
      <span aria-hidden="true">⏱</span>
      <span>Time Remaining: {formatTime(remainingSeconds)}</span>
    </div>
  );
}
