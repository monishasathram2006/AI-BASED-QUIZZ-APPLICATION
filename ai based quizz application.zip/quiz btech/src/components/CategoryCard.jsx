import { Link } from 'react-router-dom';
import { getCategoryProgress } from '../services/progressService.js';

const COLOR_STYLES = {
  emerald: {
    accentBar: 'from-emerald-500 to-teal-400',
    iconBg: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400',
    badge: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-300 dark:border-emerald-500/20',
    hoverBorder: 'hover:border-emerald-300 dark:hover:border-emerald-500/40',
    glow: 'group-hover:shadow-emerald-500/10',
    btn: 'bg-emerald-600 hover:bg-emerald-700 focus-visible:ring-emerald-500',
  },
  cyan: {
    accentBar: 'from-cyan-500 to-blue-400',
    iconBg: 'bg-cyan-50 text-cyan-600 dark:bg-cyan-500/10 dark:text-cyan-400',
    badge: 'bg-cyan-50 text-cyan-700 border-cyan-200 dark:bg-cyan-500/10 dark:text-cyan-300 dark:border-cyan-500/20',
    hoverBorder: 'hover:border-cyan-300 dark:hover:border-cyan-500/40',
    glow: 'group-hover:shadow-cyan-500/10',
    btn: 'bg-cyan-600 hover:bg-cyan-700 focus-visible:ring-cyan-500',
  },
  rose: {
    accentBar: 'from-rose-500 to-pink-400',
    iconBg: 'bg-rose-50 text-rose-600 dark:bg-rose-500/10 dark:text-rose-400',
    badge: 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-500/10 dark:text-rose-300 dark:border-rose-500/20',
    hoverBorder: 'hover:border-rose-300 dark:hover:border-rose-500/40',
    glow: 'group-hover:shadow-rose-500/10',
    btn: 'bg-rose-600 hover:bg-rose-700 focus-visible:ring-rose-500',
  },
  sky: {
    accentBar: 'from-sky-500 to-indigo-400',
    iconBg: 'bg-sky-50 text-sky-600 dark:bg-sky-500/10 dark:text-sky-400',
    badge: 'bg-sky-50 text-sky-700 border-sky-200 dark:bg-sky-500/10 dark:text-sky-300 dark:border-sky-500/20',
    hoverBorder: 'hover:border-sky-300 dark:hover:border-sky-500/40',
    glow: 'group-hover:shadow-sky-500/10',
    btn: 'bg-sky-600 hover:bg-sky-700 focus-visible:ring-sky-500',
  },
  violet: {
    accentBar: 'from-violet-500 to-purple-400',
    iconBg: 'bg-violet-50 text-violet-600 dark:bg-violet-500/10 dark:text-violet-400',
    badge: 'bg-violet-50 text-violet-700 border-violet-200 dark:bg-violet-500/10 dark:text-violet-300 dark:border-violet-500/20',
    hoverBorder: 'hover:border-violet-300 dark:hover:border-violet-500/40',
    glow: 'group-hover:shadow-violet-500/10',
    btn: 'bg-violet-600 hover:bg-violet-700 focus-visible:ring-violet-500',
  },
  blue: {
    accentBar: 'from-blue-500 to-cyan-400',
    iconBg: 'bg-blue-50 text-blue-600 dark:bg-blue-500/10 dark:text-blue-400',
    badge: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-500/10 dark:text-blue-300 dark:border-blue-500/20',
    hoverBorder: 'hover:border-blue-300 dark:hover:border-blue-500/40',
    glow: 'group-hover:shadow-blue-500/10',
    btn: 'bg-blue-600 hover:bg-blue-700 focus-visible:ring-blue-500',
  },
  fuchsia: {
    accentBar: 'from-fuchsia-500 to-pink-400',
    iconBg: 'bg-fuchsia-50 text-fuchsia-600 dark:bg-fuchsia-500/10 dark:text-fuchsia-400',
    badge: 'bg-fuchsia-50 text-fuchsia-700 border-fuchsia-200 dark:bg-fuchsia-500/10 dark:text-fuchsia-300 dark:border-fuchsia-500/20',
    hoverBorder: 'hover:border-fuchsia-300 dark:hover:border-fuchsia-500/40',
    glow: 'group-hover:shadow-fuchsia-500/10',
    btn: 'bg-fuchsia-600 hover:bg-fuchsia-700 focus-visible:ring-fuchsia-500',
  },
  amber: {
    accentBar: 'from-amber-500 to-orange-400',
    iconBg: 'bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-400',
    badge: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-500/10 dark:text-amber-300 dark:border-amber-500/20',
    hoverBorder: 'hover:border-amber-300 dark:hover:border-amber-500/40',
    glow: 'group-hover:shadow-amber-500/10',
    btn: 'bg-amber-600 hover:bg-amber-700 focus-visible:ring-amber-500',
  },
  indigo: {
    accentBar: 'from-indigo-500 to-violet-400',
    iconBg: 'bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400',
    badge: 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-500/10 dark:text-indigo-300 dark:border-indigo-500/20',
    hoverBorder: 'hover:border-indigo-300 dark:hover:border-indigo-500/40',
    glow: 'group-hover:shadow-indigo-500/10',
    btn: 'bg-indigo-600 hover:bg-indigo-700 focus-visible:ring-indigo-500',
  },
  purple: {
    accentBar: 'from-purple-500 to-indigo-400',
    iconBg: 'bg-purple-50 text-purple-600 dark:bg-purple-500/10 dark:text-purple-400',
    badge: 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-500/10 dark:text-purple-300 dark:border-purple-500/20',
    hoverBorder: 'hover:border-purple-300 dark:hover:border-purple-500/40',
    glow: 'group-hover:shadow-purple-500/10',
    btn: 'bg-purple-600 hover:bg-purple-700 focus-visible:ring-purple-500',
  },
  teal: {
    accentBar: 'from-teal-500 to-emerald-400',
    iconBg: 'bg-teal-50 text-teal-600 dark:bg-teal-500/10 dark:text-teal-400',
    badge: 'bg-teal-50 text-teal-700 border-teal-200 dark:bg-teal-500/10 dark:text-teal-300 dark:border-teal-500/20',
    hoverBorder: 'hover:border-teal-300 dark:hover:border-teal-500/40',
    glow: 'group-hover:shadow-teal-500/10',
    btn: 'bg-teal-600 hover:bg-teal-700 focus-visible:ring-teal-500',
  },
  slate: {
    accentBar: 'from-slate-500 to-slate-400',
    iconBg: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
    badge: 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700',
    hoverBorder: 'hover:border-slate-400 dark:hover:border-slate-600',
    glow: 'group-hover:shadow-slate-500/10',
    btn: 'bg-slate-700 hover:bg-slate-800 focus-visible:ring-slate-500',
  },
};

export default function CategoryCard({ category, questionCount = 25 }) {
  const styles = COLOR_STYLES[category.color] || COLOR_STYLES.indigo;
  const userProgress = getCategoryProgress(category.name);
  const topTopics = category.topics ? category.topics.slice(0, 3) : [];
  const remainingCount = category.topics ? Math.max(0, category.topics.length - 3) : 0;

  return (
    <div
      className={`group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-slate-200/90 bg-white p-6 shadow-sm transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl dark:border-slate-800/80 dark:bg-slate-900 ${styles.hoverBorder} ${styles.glow}`}
    >
      {/* Top accent gradient line */}
      <div
        className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-r ${styles.accentBar} opacity-90 transition-opacity group-hover:h-1.5 group-hover:opacity-100`}
      />

      <div>
        {/* Header row: Icon & Badges */}
        <div className="mb-4 flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <span
              className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-2xl shadow-inner transition-transform duration-300 group-hover:scale-110 ${styles.iconBg}`}
              aria-hidden="true"
            >
              {category.icon}
            </span>
            <div>
              {category.domain && (
                <span className="block text-xs font-semibold tracking-wider uppercase text-slate-600 dark:text-slate-400">
                  {category.domain}
                </span>
              )}
              <h3 className="text-lg font-bold text-slate-900 transition-colors group-hover:text-indigo-600 dark:text-white dark:group-hover:text-indigo-400">
                {category.name}
              </h3>
            </div>
          </div>

          {category.badge && (
            <span
              className={`shrink-0 rounded-full border px-2.5 py-0.5 text-xs font-bold ${styles.badge}`}
            >
              {category.badge}
            </span>
          )}
        </div>

        {/* Description */}
        <p className="line-clamp-2 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
          {category.description}
        </p>

        {/* Topics preview */}
        {topTopics.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-1.5">
            {topTopics.map((topic) => (
              <span
                key={topic}
                className="rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-600 transition dark:bg-slate-800/80 dark:text-slate-300"
              >
                {topic}
              </span>
            ))}
            {remainingCount > 0 && (
              <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-600 dark:bg-slate-800/60 dark:text-slate-400">
                +{remainingCount} more
              </span>
            )}
          </div>
        )}
      </div>

      <div className="mt-5 border-t border-slate-100 pt-4 dark:border-slate-800/80">
        {/* Metrics Row: Questions & User Progress */}
        <div className="mb-4 flex items-center justify-between text-xs font-medium">
          <span className="inline-flex items-center gap-1.5 text-slate-600 dark:text-slate-400">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            {questionCount} Questions
          </span>

          {userProgress.attempted > 0 ? (
            <span className="inline-flex items-center gap-1 font-semibold text-emerald-600 dark:text-emerald-400">
              <span>★</span> {userProgress.progress}% Mastered
            </span>
          ) : (
            <div className="flex items-center gap-1">
              <span className="rounded bg-emerald-50 px-1.5 py-0.5 text-[10px] font-bold text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400">
                Easy
              </span>
              <span className="rounded bg-amber-50 px-1.5 py-0.5 text-[10px] font-bold text-amber-600 dark:bg-amber-500/10 dark:text-amber-400">
                Med
              </span>
              <span className="rounded bg-rose-50 px-1.5 py-0.5 text-[10px] font-bold text-rose-600 dark:bg-rose-500/10 dark:text-rose-400">
                Hard
              </span>
            </div>
          )}
        </div>

        {/* User Progress Bar if attempted */}
        {userProgress.attempted > 0 && (
          <div className="mb-4 h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
            <div
              className="h-full rounded-full bg-emerald-500 transition-all duration-500"
              style={{ width: `${userProgress.progress}%` }}
            />
          </div>
        )}

        {/* Action Button */}
        <Link
          to={`/category/${category.slug}`}
          className={`focus-ring flex w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:shadow-md ${styles.btn}`}
        >
          <span>Start Track</span>
          <span className="transition-transform duration-200 group-hover:translate-x-1" aria-hidden="true">
            →
          </span>
        </Link>
      </div>
    </div>
  );
}
