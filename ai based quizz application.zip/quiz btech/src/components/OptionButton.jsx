const LETTERS = ['A', 'B', 'C', 'D'];

export default function OptionButton({ index, text, selected, correct, revealed, onClick, disabled }) {
  let styles =
    'border-slate-200/90 bg-white hover:border-indigo-400 hover:bg-indigo-50/40 hover:shadow-sm dark:border-slate-800 dark:bg-slate-900 dark:hover:border-indigo-500/50 dark:hover:bg-indigo-500/10';
  let letterStyles =
    'border-slate-300 bg-slate-50 text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300';

  if (revealed) {
    if (correct) {
      styles =
        'border-emerald-500 bg-emerald-50/80 shadow-sm dark:border-emerald-500/70 dark:bg-emerald-500/15';
      letterStyles = 'border-emerald-600 bg-emerald-600 text-white shadow-sm';
    } else if (selected && !correct) {
      styles =
        'border-rose-500 bg-rose-50/80 shadow-sm dark:border-rose-500/70 dark:bg-rose-500/15';
      letterStyles = 'border-rose-600 bg-rose-600 text-white shadow-sm';
    }
  } else if (selected) {
    styles =
      'border-indigo-600 bg-indigo-50/70 shadow-sm dark:border-indigo-500 dark:bg-indigo-500/15';
    letterStyles = 'border-indigo-600 bg-indigo-600 text-white shadow-sm';
  }

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-pressed={selected}
      className={`focus-ring group relative flex w-full items-center gap-3.5 rounded-xl border-2 px-4 py-3.5 text-left text-sm font-medium text-slate-800 transition-all duration-200 disabled:cursor-not-allowed dark:text-slate-100 ${styles}`}
    >
      <span
        className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border text-xs font-bold transition-transform duration-150 group-hover:scale-105 ${letterStyles}`}
      >
        {LETTERS[index] ?? index + 1}
      </span>
      <span className="flex-1 leading-relaxed">{text}</span>
      {revealed && correct && (
        <span
          className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500 text-xs font-bold text-white shadow-sm"
          aria-hidden="true"
        >
          ✓
        </span>
      )}
      {revealed && selected && !correct && (
        <span
          className="flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-xs font-bold text-white shadow-sm"
          aria-hidden="true"
        >
          ✕
        </span>
      )}
    </button>
  );
}
