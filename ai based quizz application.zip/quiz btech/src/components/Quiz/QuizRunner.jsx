import { useEffect } from 'react';
import { useQuiz } from '../../hooks/useQuiz.js';
import QuestionCard from '../QuestionCard.jsx';
import QuestionNavigation from '../QuestionNavigation.jsx';
import QuizTimer from '../QuizTimer.jsx';

export default function QuizRunner({ headerContent, onSubmit }) {
  const quiz = useQuiz();
  const { state } = quiz;

  const currentQuestion = state.questions[state.currentIndex];
  const isLast = state.currentIndex === state.questions.length - 1;
  const answeredCount = Object.keys(state.answers).length;
  const progressPercent = Math.round(((state.currentIndex + 1) / state.questions.length) * 100);

  // Keyboard shortcut listener for efficient answering
  useEffect(() => {
    function handleKeyDown(e) {
      // Ignore if user is focusing an input or textarea
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;

      if (!currentQuestion) return;

      const key = e.key.toUpperCase();

      // Options mapping (1/A, 2/B, 3/C, 4/D)
      const optionMap = {
        '1': 0, 'A': 0,
        '2': 1, 'B': 1,
        '3': 2, 'C': 2,
        '4': 3, 'D': 3,
      };

      if (key in optionMap) {
        const optionIndex = optionMap[key];
        if (currentQuestion.options && currentQuestion.options[optionIndex]) {
          quiz.selectAnswer(currentQuestion.id, currentQuestion.options[optionIndex]);
        }
      } else if (e.key === 'ArrowRight' && !isLast) {
        quiz.next();
      } else if (e.key === 'ArrowLeft' && state.currentIndex > 0) {
        quiz.prev();
      }
    }

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentQuestion, isLast, state.currentIndex, quiz]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      {/* Quiz Header Bar */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-slate-200/90 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div>{headerContent}</div>
        <div className="flex items-center gap-3">
          <QuizTimer remainingSeconds={state.remainingSeconds} totalSeconds={state.totalSeconds} />
        </div>
      </div>

      {/* Progress Bar & Counter */}
      <div className="mb-6 space-y-2">
        <div className="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
          <span>
            Progress: <strong className="text-slate-900 dark:text-white">{progressPercent}%</strong> ({state.currentIndex + 1} of {state.questions.length})
          </span>
          <span className="inline-flex items-center gap-2">
            <span className="inline-block h-2 w-2 rounded-full bg-emerald-500" />
            Answered: {answeredCount} &bull; Unanswered: {state.questions.length - answeredCount}
          </span>
        </div>

        <div
          className="h-2.5 w-full overflow-hidden rounded-full bg-slate-200/80 dark:bg-slate-800"
          role="progressbar"
          aria-valuenow={state.currentIndex + 1}
          aria-valuemin={1}
          aria-valuemax={state.questions.length}
          aria-label="Quiz progress"
        >
          <div
            className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-teal-400 transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Main Runner Layout */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_280px]">
        <div>
          <QuestionCard
            question={currentQuestion}
            index={state.currentIndex}
            total={state.questions.length}
            selectedAnswer={state.answers[currentQuestion.id]}
            onSelect={(option) => quiz.selectAnswer(currentQuestion.id, option)}
            checked={state.checked[currentQuestion.id]}
            onCheckAnswer={() => quiz.checkAnswer(currentQuestion.id)}
          />

          {/* Navigation Controls */}
          <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={quiz.prev}
              disabled={state.currentIndex === 0}
              className="focus-ring inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-5 py-2.5 text-sm font-bold text-slate-700 shadow-sm transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <span>&larr;</span> Previous
            </button>

            <div className="flex items-center gap-3">
              {!isLast ? (
                <button
                  type="button"
                  onClick={quiz.next}
                  className="focus-ring inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-5 py-2.5 text-sm font-bold text-slate-700 shadow-sm transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  Next <span>&rarr;</span>
                </button>
              ) : null}

              <button
                type="button"
                onClick={onSubmit}
                className="focus-ring inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-6 py-2.5 text-sm font-bold text-white shadow-md transition hover:bg-indigo-700 hover:shadow-lg"
              >
                <span>Submit Quiz</span> &check;
              </button>
            </div>
          </div>

          {/* Keyboard Shortcut Helper Note */}
          <p className="mt-4 text-center text-[11px] text-slate-400 dark:text-slate-500">
            Keyboard Shortcuts: Press <kbd className="rounded border bg-slate-100 px-1 py-0.5 font-mono text-[10px] dark:border-slate-700 dark:bg-slate-800">A</kbd>-<kbd className="rounded border bg-slate-100 px-1 py-0.5 font-mono text-[10px] dark:border-slate-700 dark:bg-slate-800">D</kbd> or <kbd className="rounded border bg-slate-100 px-1 py-0.5 font-mono text-[10px] dark:border-slate-700 dark:bg-slate-800">1</kbd>-<kbd className="rounded border bg-slate-100 px-1 py-0.5 font-mono text-[10px] dark:border-slate-700 dark:bg-slate-800">4</kbd> to select an option &bull; Use <kbd className="rounded border bg-slate-100 px-1 py-0.5 font-mono text-[10px] dark:border-slate-700 dark:bg-slate-800">&larr;</kbd> / <kbd className="rounded border bg-slate-100 px-1 py-0.5 font-mono text-[10px] dark:border-slate-700 dark:bg-slate-800">&rarr;</kbd> to navigate
          </p>
        </div>

        {/* Sidebar Question Navigation Grid */}
        <div>
          <QuestionNavigation
            questions={state.questions}
            answers={state.answers}
            currentIndex={state.currentIndex}
            onNavigate={quiz.goTo}
          />
        </div>
      </div>
    </div>
  );
}
