export default function QuestionNavigation({ questions, answers, currentIndex, onNavigate }) {
  return (
    <nav aria-label="Question navigation" className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
      <h3 className="mb-3 text-sm font-semibold text-slate-700 dark:text-slate-300">Questions</h3>
      <div className="grid grid-cols-5 gap-2">
        {questions.map((q, idx) => {
          const isAnswered = answers[q.id] !== undefined;
          const isCurrent = idx === currentIndex;
          let cls = 'border-slate-200 bg-slate-50 text-slate-500 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400';
          if (isAnswered) cls = 'border-emerald-300 bg-emerald-50 text-emerald-700 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-400';
          if (isCurrent) cls = 'border-indigo-600 bg-indigo-600 text-white';

          return (
            <button
              key={q.id}
              type="button"
              onClick={() => onNavigate(idx)}
              aria-label={`Go to question ${idx + 1}${isAnswered ? ', answered' : ', unanswered'}${isCurrent ? ', current' : ''}`}
              aria-current={isCurrent ? 'true' : undefined}
              className={`focus-ring flex h-9 w-9 items-center justify-center rounded-lg border-2 text-xs font-semibold transition ${cls}`}
            >
              {idx + 1}
            </button>
          );
        })}
      </div>
      <div className="mt-4 flex flex-col gap-1.5 text-xs text-slate-500 dark:text-slate-400">
        <LegendItem swatch="border-2 border-indigo-600 bg-indigo-600" label="Current" />
        <LegendItem swatch="border-2 border-emerald-300 bg-emerald-50 dark:border-emerald-500/40 dark:bg-emerald-500/10" label="Answered" />
        <LegendItem swatch="border-2 border-slate-200 bg-slate-50 dark:border-slate-700 dark:bg-slate-800" label="Unanswered" />
      </div>
    </nav>
  );
}

function LegendItem({ swatch, label }) {
  return (
    <div className="flex items-center gap-2">
      <span className={`h-3.5 w-3.5 rounded ${swatch}`} aria-hidden="true" />
      <span>{label}</span>
    </div>
  );
}
