import CodeBlock from './CodeBlock.jsx';
import OptionButton from './OptionButton.jsx';

export default function QuestionCard({
  question,
  index,
  total,
  selectedAnswer,
  onSelect,
  checked,
  onCheckAnswer,
  disabled,
}) {
  const revealed = Boolean(checked);

  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200/90 bg-white p-5 shadow-sm transition-all sm:p-7 dark:border-slate-800 dark:bg-slate-900">
      {/* Question metadata header */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3.5 dark:border-slate-800/80">
        <div className="flex items-center gap-2">
          <span className="rounded-lg bg-indigo-50 px-2.5 py-1 text-xs font-bold text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-400">
            Question {index + 1} of {total}
          </span>
          {question.difficulty && (
            <span
              className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                question.difficulty === 'Easy'
                  ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400'
                  : question.difficulty === 'Medium'
                  ? 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400'
                  : 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-400'
              }`}
            >
              {question.difficulty}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {question.points && (
            <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
              +{question.points} XP
            </span>
          )}
          <span className="rounded-md bg-slate-100 px-2.5 py-0.5 text-xs font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-300">
            {question.topic}
          </span>
        </div>
      </div>

      {/* Question text */}
      <h2 className="text-base font-bold leading-relaxed text-slate-900 sm:text-lg dark:text-white">
        {question.question}
      </h2>

      {/* Code Snippet */}
      {question.code && (
        <div className="mt-4 overflow-hidden rounded-xl">
          <CodeBlock code={question.code} language={question.language} />
        </div>
      )}

      {/* Answer options */}
      <div className="mt-6 space-y-3" role="radiogroup" aria-label="Answer options">
        {question.options.map((option, i) => (
          <OptionButton
            key={option}
            index={i}
            text={option}
            selected={selectedAnswer === option}
            correct={revealed && option === question.correctAnswer}
            revealed={revealed}
            disabled={disabled}
            onClick={() => onSelect(option)}
          />
        ))}
      </div>

      {/* Instant check / explanation feedback */}
      {onCheckAnswer && (
        <div className="mt-5 border-t border-slate-100 pt-4 dark:border-slate-800">
          {!revealed ? (
            <button
              type="button"
              onClick={onCheckAnswer}
              disabled={!selectedAnswer}
              className="focus-ring inline-flex items-center gap-1.5 rounded-xl border border-indigo-200 bg-indigo-50 px-4 py-2 text-sm font-bold text-indigo-700 transition hover:bg-indigo-100 disabled:cursor-not-allowed disabled:opacity-50 dark:border-indigo-500/30 dark:bg-indigo-500/10 dark:text-indigo-300 dark:hover:bg-indigo-500/20"
            >
              <span>Verify Answer</span>
              <span aria-hidden="true">&rarr;</span>
            </button>
          ) : (
            <div
              className={`rounded-xl border p-4.5 text-sm transition-all ${
                selectedAnswer === question.correctAnswer
                  ? 'border-emerald-300 bg-emerald-50/70 text-emerald-900 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-300'
                  : 'border-rose-300 bg-rose-50/70 text-rose-900 dark:border-rose-500/40 dark:bg-rose-500/10 dark:text-rose-300'
              }`}
              role="status"
            >
              <div className="flex items-center gap-2 font-bold">
                <span className="text-base">
                  {selectedAnswer === question.correctAnswer ? '✓' : '✕'}
                </span>
                <span>
                  {selectedAnswer === question.correctAnswer
                    ? 'Excellent! Correct Answer.'
                    : 'Not quite right.'}
                </span>
              </div>
              <p className="mt-2 text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span className="text-slate-500 dark:text-slate-400">Correct Answer:</span>{' '}
                {question.correctAnswer}
              </p>
              <p className="mt-1.5 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                {question.explanation}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
