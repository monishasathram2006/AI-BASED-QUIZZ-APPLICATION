const CONFIG = {
  Easy: {
    desc: 'Foundational concepts & syntax',
    color: 'from-emerald-500 to-teal-500',
    borderColor: 'border-emerald-200 dark:border-emerald-500/20 hover:border-emerald-400',
    badge: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400 border-emerald-200 dark:border-emerald-500/20',
    btn: 'bg-emerald-600 hover:bg-emerald-700 text-white',
    time: '10 mins',
    xp: '+10 XP / Q',
  },
  Medium: {
    desc: 'Core interview scenarios & reasoning',
    color: 'from-amber-500 to-orange-500',
    borderColor: 'border-amber-200 dark:border-amber-500/20 hover:border-amber-400',
    badge: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400 border-amber-200 dark:border-amber-500/20',
    btn: 'bg-amber-600 hover:bg-amber-700 text-white',
    time: '15 mins',
    xp: '+20 XP / Q',
  },
  Hard: {
    desc: 'Complex architectures & deep internals',
    color: 'from-rose-500 to-red-600',
    borderColor: 'border-rose-200 dark:border-rose-500/20 hover:border-rose-400',
    badge: 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-400 border-rose-200 dark:border-rose-500/20',
    btn: 'bg-rose-600 hover:bg-rose-700 text-white',
    time: '10 mins',
    xp: '+30 XP / Q',
  },
  Mixed: {
    desc: 'Full mock assessment across all tiers',
    color: 'from-indigo-500 to-purple-600',
    borderColor: 'border-indigo-200 dark:border-indigo-500/20 hover:border-indigo-400',
    badge: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-400 border-indigo-200 dark:border-indigo-500/20',
    btn: 'bg-indigo-600 hover:bg-indigo-700 text-white',
    time: '30 mins',
    xp: 'Full Score XP',
  },
};

export default function DifficultyCard({ difficulty, questionCount, onStart }) {
  const cfg = CONFIG[difficulty] ?? CONFIG.Easy;

  return (
    <div
      className={`group relative flex flex-col justify-between overflow-hidden rounded-2xl border bg-white p-6 text-center shadow-sm transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lg dark:bg-slate-900 ${cfg.borderColor}`}
    >
      {/* Top accent gradient bar */}
      <div className={`absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r ${cfg.color}`} />

      <div>
        <div className="mb-2 flex items-center justify-between text-[11px] font-semibold text-slate-500 dark:text-slate-400">
          <span className="inline-flex items-center gap-1">⏱️ {cfg.time}</span>
          <span className="rounded-md bg-slate-100 px-1.5 py-0.5 font-bold dark:bg-slate-800">
            {cfg.xp}
          </span>
        </div>

        <h3 className="mt-2 text-xl font-extrabold text-slate-900 dark:text-white">
          {difficulty}
        </h3>
        <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-400">{cfg.desc}</p>

        <div className="mt-4">
          <span
            className={`inline-block rounded-full border px-3 py-1 text-xs font-bold ${cfg.badge}`}
          >
            {questionCount} Questions
          </span>
        </div>
      </div>

      <button
        type="button"
        onClick={onStart}
        className={`focus-ring mt-6 inline-flex w-full items-center justify-center gap-1.5 rounded-xl px-4 py-2.5 text-sm font-bold shadow-sm transition hover:shadow-md ${cfg.btn}`}
      >
        <span>Launch {difficulty}</span>
        <span className="transition-transform duration-200 group-hover:translate-x-1" aria-hidden="true">
          →
        </span>
      </button>
    </div>
  );
}
