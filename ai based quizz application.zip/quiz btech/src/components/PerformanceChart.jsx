import ProgressBar from './ProgressBar.jsx';
import { Link } from 'react-router-dom';

export default function PerformanceChart({ categoryProgress }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
      <h3 className="mb-5 text-lg font-semibold text-slate-900 dark:text-white">Category Progress</h3>
      <div className="space-y-5">
        {categoryProgress.map(({ category, progress }) => (
          <Link key={category.slug} to={`/category/${category.slug}`} className="focus-ring block rounded-lg">
            <ProgressBar label={`${category.icon} ${category.name}`} value={progress} color={category.color} />
          </Link>
        ))}
      </div>
    </div>
  );
}
