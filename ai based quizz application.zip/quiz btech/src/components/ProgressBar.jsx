const COLOR_MAP = {
  indigo: 'bg-indigo-500',
  emerald: 'bg-emerald-500',
  blue: 'bg-blue-500',
  amber: 'bg-amber-500',
  orange: 'bg-orange-500',
  red: 'bg-red-500',
  slate: 'bg-slate-500',
  purple: 'bg-purple-500',
  teal: 'bg-teal-500',
};

export default function ProgressBar({ value = 0, color = 'indigo', label, showPercentage = true, className = '' }) {
  const clamped = Math.max(0, Math.min(100, value));
  const barColor = COLOR_MAP[color] ?? COLOR_MAP.indigo;

  return (
    <div className={className}>
      {(label || showPercentage) && (
        <div className="mb-1.5 flex items-center justify-between text-sm">
          {label && <span className="font-medium text-slate-700 dark:text-slate-300">{label}</span>}
          {showPercentage && <span className="text-slate-500 dark:text-slate-400">{clamped}%</span>}
        </div>
      )}
      <div
        className="h-2.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800"
        role="progressbar"
        aria-valuenow={clamped}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={label}
      >
        <div
          className={`h-full rounded-full ${barColor} transition-all duration-500`}
          style={{ width: `${clamped}%` }}
        />
      </div>
    </div>
  );
}
