export default function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-950">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
          <div>
            <p className="text-lg font-bold text-slate-900 dark:text-white">
              Code<span className="text-indigo-600 dark:text-indigo-400">Prep</span>
            </p>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              B.Tech Programming & Technical Interview Preparation
            </p>
          </div>
          <p className="text-xs text-slate-400 dark:text-slate-500">
            &copy; {new Date().getFullYear()} CodePrep. Built for students, by practice.
          </p>
        </div>
      </div>
    </footer>
  );
}
