import { readLocalStorage, writeLocalStorage } from '../hooks/useLocalStorage.js';
import { categories } from '../data/categories.js';

const ATTEMPTS_KEY = 'codeprep_quiz_attempts';
const LAST_RESULT_KEY = 'codeprep_last_result';

// ---- Raw attempt storage -------------------------------------------------

// Attempt shape:
// { id, category, difficulty, total, correct, wrong, unanswered,
//   percentage, pointsEarned, timeTakenSeconds, date }
export function getAllAttempts() {
  return readLocalStorage(ATTEMPTS_KEY, []);
}

export function saveAttempt(attempt) {
  const attempts = getAllAttempts();
  attempts.push({ ...attempt, id: attempt.id ?? `attempt-${Date.now()}`, date: attempt.date ?? new Date().toISOString() });
  writeLocalStorage(ATTEMPTS_KEY, attempts);
  return attempts;
}

export function clearAllProgress() {
  writeLocalStorage(ATTEMPTS_KEY, []);
  writeLocalStorage(LAST_RESULT_KEY, null);
}

// ---- Last finished quiz (for Result / Review pages) ----------------------

export function saveLastResult(result) {
  writeLocalStorage(LAST_RESULT_KEY, result);
}

export function getLastResult() {
  return readLocalStorage(LAST_RESULT_KEY, null);
}

// ---- Aggregate stats (all dynamically derived, nothing hardcoded) --------

export function getOverallStats() {
  const attempts = getAllAttempts();
  const totalQuizzes = attempts.length;
  const questionsAttempted = attempts.reduce((sum, a) => sum + a.correct + a.wrong, 0);
  const correctAnswers = attempts.reduce((sum, a) => sum + a.correct, 0);
  const accuracy = questionsAttempted > 0 ? Math.round((correctAnswers / questionsAttempted) * 100) : 0;
  const averageScore = totalQuizzes > 0
    ? Math.round(attempts.reduce((sum, a) => sum + a.percentage, 0) / totalQuizzes)
    : 0;
  const bestScore = totalQuizzes > 0 ? Math.max(...attempts.map((a) => a.percentage)) : 0;
  const currentStreak = computeStreak(attempts);
  const lastQuizDate = totalQuizzes > 0 ? attempts[attempts.length - 1].date : null;

  return {
    totalQuizzes,
    questionsAttempted,
    correctAnswers,
    accuracy,
    averageScore,
    bestScore,
    currentStreak,
    lastQuizDate,
  };
}

// Consecutive-day streak: counts back from today (or yesterday, so a day
// that hasn't happened yet doesn't reset an active streak) through attempt
// dates, one calendar day per attempted day.
function computeStreak(attempts) {
  if (attempts.length === 0) return 0;
  const days = new Set(attempts.map((a) => new Date(a.date).toDateString()));
  let streak = 0;
  const cursor = new Date();
  if (!days.has(cursor.toDateString())) {
    cursor.setDate(cursor.getDate() - 1);
    if (!days.has(cursor.toDateString())) return 0;
  }
  while (days.has(cursor.toDateString())) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

// Per-category progress: average of the best percentage achieved for each
// of Easy/Medium/Hard (0 if that difficulty has never been attempted).
// This gives a dynamic 0-100 mastery estimate per category.
export function getCategoryProgress(categoryName) {
  const attempts = getAllAttempts().filter((a) => a.category === categoryName);
  const tiers = ['Easy', 'Medium', 'Hard'];
  const bestByTier = tiers.map((tier) => {
    const tierAttempts = attempts.filter((a) => a.difficulty === tier);
    if (tierAttempts.length === 0) return 0;
    return Math.max(...tierAttempts.map((a) => a.percentage));
  });
  const progress = Math.round(bestByTier.reduce((a, b) => a + b, 0) / tiers.length);
  return { progress, attempted: attempts.length };
}

export function getAllCategoryProgress() {
  return categories.map((c) => ({ category: c, ...getCategoryProgress(c.name) }));
}

export function getCompletedCategories() {
  return getAllCategoryProgress().filter((c) => c.progress >= 60).map((c) => c.category.name);
}
