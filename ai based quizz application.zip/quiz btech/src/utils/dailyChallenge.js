import { questionBank } from '../data/questionBank.js';
import { safeGet, safeSet, STORAGE_KEYS } from './storage.js';

function hashString(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i += 1) {
    hash = (hash * 31 + str.charCodeAt(i)) >>> 0;
  }
  return hash;
}

function todayKey() {
  return new Date().toDateString();
}

// Deterministic per-day question: stable for the whole day, changes daily,
// no manual repeat-avoidance needed since the hash naturally varies by date.
export function getTodaysChallenge() {
  const key = todayKey();
  const index = hashString(key) % questionBank.length;
  return questionBank[index];
}

export function getDailyChallengeState() {
  const all = safeGet(STORAGE_KEYS.DAILY_CHALLENGE, {});
  return all[todayKey()] ?? { date: todayKey(), completed: false, correct: null, xpAwarded: 0 };
}

export function recordDailyChallengeCompletion({ correct, xpAwarded }) {
  const all = safeGet(STORAGE_KEYS.DAILY_CHALLENGE, {});
  all[todayKey()] = { date: todayKey(), completed: true, correct, xpAwarded };
  safeSet(STORAGE_KEYS.DAILY_CHALLENGE, all);
  return all[todayKey()];
}
