import { safeGet, safeSet, STORAGE_KEYS } from './storage.js';
import { calculateQuizResult } from './quizScoring.js';
import { awardXP, xpForCorrectAnswer, XP_RULES, recordActivityToday } from './gamification.js';
import { checkAndUnlock } from './achievements.js';

// Debugging Arena has its own taxonomy (language + bug-concept topic)
// distinct from the main category/topic question bank, so it's tracked in
// its own bucket rather than being forced through the general mistake/
// topic-stats pipeline (which expects category+topic in the quiz-bank shape).
function getDebugStats() {
  return safeGet(STORAGE_KEYS.DEBUG_STATS, { attempts: 0, correct: 0, wrong: 0, xpEarned: 0, history: [] });
}

export function getDebugStatsSummary() {
  const stats = getDebugStats();
  const accuracy = stats.attempts > 0 ? Math.round((stats.correct / stats.attempts) * 100) : null;
  return { ...stats, accuracy };
}

function weakestConcept(questions, answers) {
  const wrongTopicCounts = {};
  questions.forEach((q) => {
    const selected = answers[q.id];
    if (selected && selected !== q.correctAnswer) {
      wrongTopicCounts[q.topic] = (wrongTopicCounts[q.topic] ?? 0) + 1;
    }
  });
  const entries = Object.entries(wrongTopicCounts);
  if (entries.length === 0) return null;
  return entries.sort((a, b) => b[1] - a[1])[0][0];
}

export function recordDebugAttempt({ language, questions, answers }) {
  const result = calculateQuizResult(questions, answers);
  const weakConcept = weakestConcept(questions, answers);

  const stats = getDebugStats();
  stats.attempts += result.totalQuestions;
  stats.correct += result.correctAnswers;
  stats.wrong += result.wrongAnswers;
  stats.history = [
    { date: new Date().toISOString(), language, correct: result.correctAnswers, total: result.totalQuestions, weakConcept },
    ...stats.history,
  ].slice(0, 50);

  let xpGained = XP_RULES.completeQuiz;
  questions.forEach((q) => {
    if (answers[q.id] === q.correctAnswer) xpGained += xpForCorrectAnswer(q.difficulty);
  });
  stats.xpEarned += xpGained;
  safeSet(STORAGE_KEYS.DEBUG_STATS, stats);

  const xpResult = awardXP(xpGained);
  const streakInfo = recordActivityToday();
  const newBadges = checkAndUnlock();

  return { result, weakConcept, xpGained, leveledUp: xpResult.leveledUp, newLevel: xpResult.newLevel, streakDay: streakInfo.currentStreak, newBadges };
}
