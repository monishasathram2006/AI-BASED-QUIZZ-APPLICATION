// Validates a single question object's shape. Returns an array of
// human-readable problems (empty array = valid).
export function validateQuestion(q) {
  const problems = [];
  if (!q || typeof q !== 'object') return ['Question is not an object'];

  const requiredStringFields = ['id', 'category', 'difficulty', 'topic', 'question', 'correctAnswer', 'explanation'];
  for (const field of requiredStringFields) {
    if (typeof q[field] !== 'string' || q[field].trim() === '') {
      problems.push(`Missing or invalid "${field}"`);
    }
  }

  if (!['Easy', 'Medium', 'Hard'].includes(q.difficulty)) {
    problems.push(`Invalid difficulty "${q.difficulty}"`);
  }

  if (!Array.isArray(q.options) || q.options.length !== 4) {
    problems.push('Question must have exactly 4 options');
  } else {
    const unique = new Set(q.options);
    if (unique.size !== 4) problems.push('Options must be unique');
    if (!q.options.includes(q.correctAnswer)) {
      problems.push('correctAnswer does not match any option');
    }
  }

  if (typeof q.points !== 'number' || q.points <= 0) {
    problems.push('Missing or invalid "points"');
  }

  return problems;
}

// Validates an entire question bank: schema + duplicate ID detection.
// Returns { valid: boolean, errors: string[] }.
export function validateQuestionBank(questions) {
  const errors = [];
  if (!Array.isArray(questions) || questions.length === 0) {
    return { valid: false, errors: ['Question bank is empty'] };
  }

  const seenIds = new Set();
  for (const q of questions) {
    const problems = validateQuestion(q);
    if (problems.length) {
      errors.push(`[${q?.id ?? 'unknown id'}] ${problems.join(', ')}`);
    }
    if (q?.id) {
      if (seenIds.has(q.id)) errors.push(`Duplicate question id: ${q.id}`);
      seenIds.add(q.id);
    }
  }

  return { valid: errors.length === 0, errors };
}
