import { getBadges, saveBadge, STORAGE_KEYS, safeGet } from './storage.js';
import { getAllAttempts, getOverallStats } from '../services/progressService.js';
import { getSkillAccuracy } from './progressStorage.js';
import { getStreakInfo } from './gamification.js';

function gatherRealStats() {
  const attempts = getAllAttempts();
  const overall = getOverallStats();
  const streak = getStreakInfo();
  const debugStats = safeGet(STORAGE_KEYS.DEBUG_STATS, null);
  const codingAttempts = safeGet(STORAGE_KEYS.CODING_ATTEMPTS, []);
  const interviewAttempts = safeGet(STORAGE_KEYS.INTERVIEW_ATTEMPTS, []);

  return {
    totalQuizzes: attempts.length,
    questionsAttempted: overall.questionsAttempted,
    currentStreak: streak.current,
    longestStreak: streak.longest,
    pythonAttempted: attempts.some((a) => a.category === 'Python'),
    pythonAccuracy: getSkillAccuracy('Python'),
    pythonAttemptCount: attempts.filter((a) => a.category === 'Python').length,
    debugAccuracy: debugStats && debugStats.attempts > 0 ? Math.round((debugStats.correct / debugStats.attempts) * 100) : null,
    debugAttempts: debugStats?.attempts ?? 0,
    codingChallengesPassed: codingAttempts.filter((a) => a.passed).length,
    bestInterviewReadiness: interviewAttempts.length > 0 ? Math.max(...interviewAttempts.map((a) => a.overallReadiness)) : null,
  };
}

export const ACHIEVEMENTS = [
  { id: 'first-quiz', label: 'First Quiz', description: 'Complete your first quiz.', check: (s) => s.totalQuizzes >= 1 },
  { id: 'ten-quizzes', label: '10 Quizzes', description: 'Complete 10 quizzes.', check: (s) => s.totalQuizzes >= 10 },
  { id: 'hundred-questions', label: '100 Questions', description: 'Answer 100 questions across all quizzes.', check: (s) => s.questionsAttempted >= 100 },
  { id: 'five-hundred-questions', label: '500 Questions', description: 'Answer 500 questions across all quizzes.', check: (s) => s.questionsAttempted >= 500 },
  { id: 'seven-day-streak', label: '7 Day Streak', description: 'Stay active 7 days in a row.', check: (s) => s.longestStreak >= 7 },
  { id: 'thirty-day-streak', label: '30 Day Streak', description: 'Stay active 30 days in a row.', check: (s) => s.longestStreak >= 30 },
  { id: 'python-beginner', label: 'Python Beginner', description: 'Complete your first Python quiz.', check: (s) => s.pythonAttempted },
  { id: 'python-master', label: 'Python Master', description: 'Reach 90%+ accuracy in Python across 3+ quizzes.', check: (s) => s.pythonAttemptCount >= 3 && s.pythonAccuracy !== null && s.pythonAccuracy >= 90 },
  { id: 'dsa-explorer', label: 'DSA Explorer', description: 'Requires DSA content (coming soon).', check: () => false },
  { id: 'debugging-expert', label: 'Debugging Expert', description: 'Reach 85%+ accuracy in the Debugging Arena across 10+ questions.', check: (s) => s.debugAttempts >= 10 && s.debugAccuracy !== null && s.debugAccuracy >= 85 },
  { id: 'coding-champion', label: 'Coding Champion', description: 'Pass 3 coding challenges.', check: (s) => s.codingChallengesPassed >= 3 },
  { id: 'interview-ready', label: 'Interview Ready', description: 'Score 75%+ overall readiness in Interview Mode.', check: (s) => s.bestInterviewReadiness !== null && s.bestInterviewReadiness >= 75 },
];

export function getAchievementsStatus() {
  const stats = gatherRealStats();
  const unlocked = new Set(getBadges().map((b) => b.id));
  return ACHIEVEMENTS.map((a) => ({
    ...a,
    unlocked: unlocked.has(a.id) || a.check(stats),
  }));
}

export function checkAndUnlock() {
  const stats = gatherRealStats();
  const existing = getBadges();
  const unlockedIds = new Set(existing.map((b) => b.id));
  const newBadges = [];

  ACHIEVEMENTS.forEach((a) => {
    if (!unlockedIds.has(a.id) && a.check(stats)) {
      const badge = { id: a.id, label: a.label, unlockedAt: new Date().toISOString() };
      existing.push(badge);
      newBadges.push(badge);
    }
  });

  if (newBadges.length > 0) saveBadge(existing);
  return newBadges;
}
