// Canonical scoring formula, used by quizUtils.computeQuizResult and every
// new quiz-taking surface (practice, daily challenge, debugging arena).
// answers: { [questionId]: selectedOptionString }
export function calculateQuizResult(questions, answers) {
  const totalQuestions = questions.length;

  const correctAnswers = questions.filter((q) => answers[q.id] === q.correctAnswer).length;
  const wrongAnswers = questions.filter((q) => answers[q.id] && answers[q.id] !== q.correctAnswer).length;
  const unanswered = questions.filter((q) => !answers[q.id]).length;

  if (correctAnswers + wrongAnswers + unanswered !== totalQuestions) {
    throw new Error('Quiz scoring calculation is inconsistent');
  }

  const score = totalQuestions > 0 ? Math.round((correctAnswers / totalQuestions) * 100) : 0;
  const pointsEarned = correctAnswers;

  return { totalQuestions, correctAnswers, wrongAnswers, unanswered, score, pointsEarned };
}
