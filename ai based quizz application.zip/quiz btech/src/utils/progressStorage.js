import { getMistakes, saveMistake, safeGet, safeSet, STORAGE_KEYS } from './storage.js';
import { saveAttempt } from '../services/progressService.js';
import { questionBank } from '../data/questionBank.js';
import { awardXP, xpForCorrectAnswer, XP_RULES, recordActivityToday } from './gamification.js';
import { checkAndUnlock } from './achievements.js';

function todayKey() {
  return new Date().toDateString();
}

// Real per-day activity tally backing the Dashboard's "Today's Goal"
// checklist (questions answered today, previously-wrong questions
// re-practiced today). Coding-challenge completion is read directly from
// codeprep_coding_attempts by date instead of duplicated here.
export function getTodayActivity() {
  const all = safeGet(STORAGE_KEYS.DAILY_ACTIVITY, {});
  return all[todayKey()] ?? { questionsAnswered: 0, mistakesPracticed: 0 };
}

function bumpTodayActivity({ questionsAnswered = 0, mistakesPracticed = 0 }) {
  const all = safeGet(STORAGE_KEYS.DAILY_ACTIVITY, {});
  const current = all[todayKey()] ?? { questionsAnswered: 0, mistakesPracticed: 0 };
  all[todayKey()] = {
    questionsAnswered: current.questionsAnswered + questionsAnswered,
    mistakesPracticed: current.mistakesPracticed + mistakesPracticed,
  };
  safeSet(STORAGE_KEYS.DAILY_ACTIVITY, all);
}

// Upserts a per-question stats record for every question in the attempt
// (correct AND wrong, despite the "mistake" naming used by the spec) —
// this is the ground truth topic-accuracy data behind Skill Analytics,
// Weak Areas, the Adaptive Engine, the Roadmap, and Company Prep.
export function recordQuestionStats(questions, answers) {
  const records = getMistakes();
  const now = new Date().toISOString();
  let answeredCount = 0;
  let mistakesPracticedCount = 0;

  questions.forEach((q) => {
    const selected = answers[q.id];
    if (selected === undefined || selected === null) return; // unanswered: no stat to record

    answeredCount += 1;
    const isCorrect = selected === q.correctAnswer;
    const existing = records[q.id] ?? {
      questionId: q.id,
      category: q.category,
      topic: q.topic,
      difficulty: q.difficulty,
      attempts: 0,
      wrongCount: 0,
      correctCount: 0,
      lastAttempted: null,
    };

    if (existing.wrongCount > 0) mistakesPracticedCount += 1;

    records[q.id] = {
      ...existing,
      attempts: existing.attempts + 1,
      correctCount: existing.correctCount + (isCorrect ? 1 : 0),
      wrongCount: existing.wrongCount + (isCorrect ? 0 : 1),
      lastAttempted: now,
    };
  });

  bumpTodayActivity({ questionsAnswered: answeredCount, mistakesPracticed: mistakesPracticedCount });
  saveMistake(records);
  return records;
}

export function getQuestionStats() {
  return getMistakes();
}

// { [category]: { [topic]: { correct, wrong, total, accuracy } } }
export function getTopicStats(categoryName) {
  const records = Object.values(getMistakes());
  const byCategory = {};

  records.forEach((r) => {
    if (categoryName && r.category !== categoryName) return;
    byCategory[r.category] = byCategory[r.category] ?? {};
    const bucket = byCategory[r.category][r.topic] ?? { correct: 0, wrong: 0, total: 0, accuracy: 0 };
    bucket.correct += r.correctCount;
    bucket.wrong += r.wrongCount;
    bucket.total = bucket.correct + bucket.wrong;
    bucket.accuracy = bucket.total > 0 ? Math.round((bucket.correct / bucket.total) * 100) : 0;
    byCategory[r.category][r.topic] = bucket;
  });

  return byCategory;
}

// Flat list of { category, topic, accuracy, total } sorted weakest-first.
// minAttempts guards against a single lucky/unlucky question skewing results.
export function getWeakTopics(limit = 5, minAttempts = 1) {
  const byCategory = getTopicStats();
  const flat = [];
  Object.entries(byCategory).forEach(([category, topics]) => {
    Object.entries(topics).forEach(([topic, stats]) => {
      if (stats.total >= minAttempts) {
        flat.push({ category, topic, ...stats });
      }
    });
  });
  return flat.sort((a, b) => a.accuracy - b.accuracy).slice(0, limit);
}

// Cross-category "OOP" aggregate: several categories share literal topic
// strings (Inheritance, Encapsulation, Classes and objects, Exception
// handling, Constructors) that are all genuinely OOP concepts. Aggregating
// them gives an honest cross-cutting skill score without inventing content.
const OOP_TOPICS = new Set([
  'OOP', 'Inheritance', 'Encapsulation', 'Classes and objects',
  'Constructors', 'Destructors', 'Polymorphism', 'Abstraction', 'Interfaces',
]);

export function getSkillAccuracy(skillName) {
  const records = Object.values(getMistakes());
  let matched;

  if (skillName === 'OOP') {
    matched = records.filter((r) => OOP_TOPICS.has(r.topic));
  } else {
    matched = records.filter((r) => r.category === skillName);
  }

  if (matched.length === 0) return null; // "Not started"

  const correct = matched.reduce((sum, r) => sum + r.correctCount, 0);
  const wrong = matched.reduce((sum, r) => sum + r.wrongCount, 0);
  const total = correct + wrong;
  return total > 0 ? Math.round((correct / total) * 100) : null;
}

const PROGRAMMING_CATEGORIES = ['Python', 'C', 'C++', 'Java Development'];
const BUCKET_CATEGORY_MAP = {
  DSA: 'Data Structures & Algorithms',
  Algorithms: 'Data Structures & Algorithms',
  DBMS: 'DBMS & SQL',
  SQL: 'DBMS & SQL',
  'Operating Systems': 'Operating Systems',
  'Computer Networks': 'Computer Networks',
  'System Design': 'System Design',
  'Cloud': 'Cloud & DevOps',
  'AI & ML': 'AI & Machine Learning',
  'Cybersecurity': 'Cybersecurity',
};

// Named "buckets" used by Company Prep / Career Readiness — each maps to a
// real, honestly-computable metric from user attempts.
export function getBucketAccuracy(bucketName) {
  if (bucketName === 'Programming') {
    const scores = PROGRAMMING_CATEGORIES.map((c) => getSkillAccuracy(c)).filter((v) => v !== null);
    if (scores.length === 0) return null;
    return Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
  }

  const mappedCategory = BUCKET_CATEGORY_MAP[bucketName] || bucketName;
  return getSkillAccuracy(mappedCategory);
}

// Resolves stored "mistake" records with wrongCount > 0 back to real
// question objects, grouped category -> topic, for the My Mistakes page.
export function getMistakeQuestions() {
  const records = Object.values(getMistakes()).filter((r) => r.wrongCount > 0);
  const grouped = {};

  records.forEach((r) => {
    const question = questionBank.find((q) => q.id === r.questionId);
    if (!question) return; // question removed/renamed since — skip safely
    grouped[r.category] = grouped[r.category] ?? {};
    grouped[r.category][r.topic] = grouped[r.category][r.topic] ?? [];
    grouped[r.category][r.topic].push({ ...r, question });
  });

  return grouped;
}

export function getMistakeQuestionList() {
  const records = Object.values(getMistakes()).filter((r) => r.wrongCount > 0);
  return records
    .map((r) => questionBank.find((q) => q.id === r.questionId))
    .filter(Boolean);
}

export function clearMistakes() {
  saveMistake({});
}

// Single integration point called by every quiz-taking surface on submit.
// Wires together attempt history, per-question stats, XP, streak, and
// achievement unlocks so none of that logic is duplicated across pages.
export function recordQuizCompletion({ questions, answers, result, category, difficulty, mode = 'quiz' }) {
  if (category && difficulty) {
    saveAttempt({
      category,
      difficulty,
      total: result.total,
      correct: result.correct,
      wrong: result.wrong,
      unanswered: result.unanswered,
      percentage: result.percentage,
      pointsEarned: result.pointsEarned,
      timeTakenSeconds: result.timeTakenSeconds,
    });
  }

  recordQuestionStats(questions, answers);

  let xpGained = 0;
  questions.forEach((q) => {
    if (answers[q.id] === q.correctAnswer) xpGained += xpForCorrectAnswer(q.difficulty);
  });

  if (mode === 'daily') xpGained += XP_RULES.dailyChallenge;
  else if (mode === 'interview') xpGained += XP_RULES.interview;
  else if (mode === 'coding') xpGained += XP_RULES.codingChallenge;
  else xpGained += XP_RULES.completeQuiz;

  const xpResult = awardXP(xpGained);
  const streakInfo = recordActivityToday();

  const stats = {
    totalQuizzes: undefined, // achievements.js pulls its own fresh stats via progressService/storage
  };
  const newBadges = checkAndUnlock(stats);

  return {
    xpGained,
    totalXP: xpResult.totalXP,
    leveledUp: xpResult.leveledUp,
    newLevel: xpResult.newLevel,
    streakDay: streakInfo.currentStreak,
    newBadges,
  };
}
