import { calculateQuizResult } from './quizScoring.js';

export const DIFFICULTY_COUNTS = { Easy: 10, Medium: 10, Hard: 5, Mixed: 25 };

export const TIMER_MINUTES = { Easy: 10, Medium: 15, Hard: 10, Mixed: 30 };

export function difficultyParamToLabel(param) {
  if (!param) return null;
  const map = { easy: 'Easy', medium: 'Medium', hard: 'Hard', mixed: 'Mixed' };
  return map[param.toLowerCase()] ?? null;
}

export function difficultyLabelToParam(label) {
  return label.toLowerCase();
}

// Fisher-Yates shuffle, returns a new array (does not mutate input).
export function shuffleArray(arr) {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

// Selects and randomizes questions for a category + difficulty.
// "Mixed" pulls all 25 questions for the category, shuffled.
// Guarantees: no duplicates, correct count, correct category/difficulty.
export function selectQuizQuestions(allQuestions, categoryName, difficultyLabel) {
  const inCategory = allQuestions.filter((q) => q.category === categoryName);

  if (difficultyLabel === 'Mixed') {
    return shuffleArray(inCategory).slice(0, DIFFICULTY_COUNTS.Mixed);
  }

  const inDifficulty = inCategory.filter((q) => q.difficulty === difficultyLabel);
  const count = DIFFICULTY_COUNTS[difficultyLabel] ?? inDifficulty.length;
  return shuffleArray(inDifficulty).slice(0, count);
}

export function formatTime(totalSeconds) {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const m = Math.floor(safe / 60).toString().padStart(2, '0');
  const s = (safe % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

export function getPerformanceLabel(percentage) {
  if (percentage >= 90) return { label: 'Excellent', color: 'emerald' };
  if (percentage >= 75) return { label: 'Very Good', color: 'blue' };
  if (percentage >= 60) return { label: 'Good', color: 'amber' };
  if (percentage >= 40) return { label: 'Needs Improvement', color: 'orange' };
  return { label: 'Keep Practicing', color: 'red' };
}

// Score-tier coaching message shown alongside the percentage on the result page.
export function getPerformanceMessage(percentage) {
  if (percentage >= 90) return 'Excellent! You are interview ready.';
  if (percentage >= 75) return 'Great job! Keep strengthening your weak areas.';
  if (percentage >= 50) return 'Good progress. Focus on your weak topics.';
  return 'Keep practicing. Your improvement starts here.';
}

// Computes the full result summary for a finished quiz attempt.
// answers: { [questionId]: selectedOptionString }
export function computeQuizResult(questions, answers, timeTakenSeconds) {
  const { totalQuestions, correctAnswers, wrongAnswers, unanswered, score, pointsEarned } =
    calculateQuizResult(questions, answers);

  const details = questions.map((q) => {
    const selected = answers[q.id];
    const isAnswered = selected !== undefined && selected !== null;
    const isCorrect = isAnswered && selected === q.correctAnswer;
    return { question: q, selected: selected ?? null, isAnswered, isCorrect };
  });

  const performance = getPerformanceLabel(score);

  return {
    total: totalQuestions,
    correct: correctAnswers,
    wrong: wrongAnswers,
    unanswered,
    percentage: score,
    pointsEarned,
    timeTakenSeconds,
    performance,
    performanceMessage: getPerformanceMessage(score),
    details,
  };
}

// Per-topic accuracy for a single finished attempt, from computeQuizResult's
// `details` array (question.topic + isCorrect, already available — no new
// data needed). Sorted weakest-first.
export function getTopicBreakdown(details) {
  const byTopic = {};
  details.forEach(({ question, isCorrect, isAnswered }) => {
    if (!isAnswered) return;
    const bucket = byTopic[question.topic] ?? { topic: question.topic, correct: 0, total: 0 };
    bucket.total += 1;
    bucket.correct += isCorrect ? 1 : 0;
    byTopic[question.topic] = bucket;
  });

  return Object.values(byTopic)
    .map((b) => ({ ...b, accuracy: Math.round((b.correct / b.total) * 100) }))
    .sort((a, b) => a.accuracy - b.accuracy);
}
