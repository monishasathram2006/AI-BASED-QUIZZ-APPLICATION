import { getXP, saveXP, getStreak, saveStreak } from './storage.js';

export const XP_RULES = {
  correctEasy: 10,
  correctMedium: 20,
  correctHard: 30,
  completeQuiz: 25,
  dailyChallenge: 50,
  codingChallenge: 50,
  interview: 100,
};

export function xpForCorrectAnswer(difficulty) {
  if (difficulty === 'Hard') return XP_RULES.correctHard;
  if (difficulty === 'Medium') return XP_RULES.correctMedium;
  return XP_RULES.correctEasy;
}

// Level thresholds fit 0, 100, 250, 450, 700 (levels 1-5) exactly, and
// extend the same curve indefinitely: xpForLevel(n) = 25*n*(n+1) - 50.
export function xpForLevel(level) {
  if (level <= 1) return 0;
  return 25 * level * (level + 1) - 50;
}

export function getLevelInfo(xp) {
  let level = 1;
  while (xpForLevel(level + 1) <= xp) level += 1;
  const currentLevelXP = xpForLevel(level);
  const nextLevelXP = xpForLevel(level + 1);
  return {
    level,
    xp,
    currentLevelXP,
    nextLevelXP,
    xpIntoLevel: xp - currentLevelXP,
    xpForNextLevel: nextLevelXP - currentLevelXP,
    progressPercent: Math.round(((xp - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100),
  };
}

export function awardXP(amount) {
  const before = getXP();
  const beforeLevel = getLevelInfo(before).level;
  const after = before + amount;
  saveXP(after);
  const afterLevel = getLevelInfo(after).level;
  return { xpGained: amount, totalXP: after, leveledUp: afterLevel > beforeLevel, newLevel: afterLevel };
}

function todayKey(date = new Date()) {
  return date.toISOString().slice(0, 10);
}

function daysBetween(a, b) {
  const msPerDay = 24 * 60 * 60 * 1000;
  return Math.round((new Date(b) - new Date(a)) / msPerDay);
}

const DAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

// Consecutive-day activity streak. Any recorded activity (quiz, practice,
// daily challenge, interview, debugging) counts as "active today".
export function recordActivityToday() {
  const today = todayKey();
  const streak = getStreak() ?? { currentStreak: 0, longestStreak: 0, lastActiveDate: null, history: {} };

  if (streak.lastActiveDate === today) {
    return streak; // already recorded today
  }

  let currentStreak = 1;
  if (streak.lastActiveDate && daysBetween(streak.lastActiveDate, today) === 1) {
    currentStreak = streak.currentStreak + 1;
  }

  const updated = {
    currentStreak,
    longestStreak: Math.max(streak.longestStreak ?? 0, currentStreak),
    lastActiveDate: today,
    history: { ...streak.history, [today]: true },
  };
  saveStreak(updated);
  return updated;
}

export function getStreakInfo() {
  const streak = getStreak() ?? { currentStreak: 0, longestStreak: 0, lastActiveDate: null, history: {} };
  const today = new Date();

  // If the last active day isn't today or yesterday, the streak is stale (broken).
  let currentStreak = streak.currentStreak ?? 0;
  if (streak.lastActiveDate) {
    const gap = daysBetween(streak.lastActiveDate, todayKey(today));
    if (gap > 1) currentStreak = 0;
  } else {
    currentStreak = 0;
  }

  const last7Days = [];
  for (let i = 6; i >= 0; i -= 1) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = todayKey(d);
    last7Days.push({ day: DAY_LABELS[d.getDay()], date: key, done: Boolean(streak.history?.[key]) });
  }

  return { current: currentStreak, longest: streak.longestStreak ?? 0, last7Days };
}
