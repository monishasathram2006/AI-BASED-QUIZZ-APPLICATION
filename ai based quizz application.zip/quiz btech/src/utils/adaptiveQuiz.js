import { DIFFICULTY_COUNTS, selectQuizQuestions } from './quizUtils.js';
import { safeGet, safeSet, STORAGE_KEYS } from './storage.js';

function priorityWeight(accuracy) {
  if (accuracy === undefined || accuracy === null) return 1; // never attempted: neutral
  if (accuracy < 50) return 3; // HIGH
  if (accuracy < 70) return 2; // MEDIUM
  if (accuracy < 85) return 1; // NORMAL
  return 0.5; // LOW
}

// Efraimidis-Spirakis weighted sampling without replacement: assign each
// item a key = U^(1/weight) for U ~ Uniform(0,1), then sort by that key
// descending. Higher weight -> key pushed closer to 1 -> sorts earlier —
// used both to pick a subset (take the first `count`) AND, since every
// item still gets a randomized key, to produce a weighted ORDERING of a
// full set (weak topics tend to surface earlier while every question still
// appears — see note below on why ordering matters here).
function weightedOrder(pool, weightFn) {
  const keyed = pool.map((item) => ({ item, key: Math.pow(Math.random(), 1 / weightFn(item)) }));
  keyed.sort((a, b) => b.key - a.key);
  return keyed.map((k) => k.item);
}

function recentKey(categoryName, difficultyLabel) {
  return `${categoryName}::${difficultyLabel}`;
}

function getRecentlySeen(categoryName, difficultyLabel) {
  const all = safeGet(STORAGE_KEYS.RECENT_QUESTIONS, {});
  return all[recentKey(categoryName, difficultyLabel)] ?? [];
}

function setRecentlySeen(categoryName, difficultyLabel, ids) {
  const all = safeGet(STORAGE_KEYS.RECENT_QUESTIONS, {});
  all[recentKey(categoryName, difficultyLabel)] = ids;
  safeSet(STORAGE_KEYS.RECENT_QUESTIONS, all);
}

// Adaptive question selection: prioritizes weak topics using real per-topic
// accuracy data. Falls back byte-identical to the plain shuffle when
// there's no history yet or the quiz is Mixed (spans all difficulties,
// out of scope here).
//
// Note on scope: every category's Easy/Medium/Hard question pool is
// exactly sized to the quiz length (10/10/5 — verified against the real
// data), so there is never a larger pool to pick a *subset* from for the
// standard category+difficulty quiz. "Prioritizing" weak topics therefore
// means weighting the ORDER questions appear in (weak-topic questions
// surface earlier), rather than excluding any question — every question
// still appears exactly once, so the count/no-duplicates guarantees are
// unaffected. If a category's pool ever exceeds the quiz length, the same
// weighting also drives real subset selection via the "recently seen"
// exclusion below.
export function selectAdaptiveQuestions(questionBank, categoryName, difficultyLabel, topicStatsForCategory) {
  if (difficultyLabel === 'Mixed' || !topicStatsForCategory || Object.keys(topicStatsForCategory).length === 0) {
    return selectQuizQuestions(questionBank, categoryName, difficultyLabel);
  }

  const inCategory = questionBank.filter((q) => q.category === categoryName);
  const inDifficulty = inCategory.filter((q) => q.difficulty === difficultyLabel);
  const count = DIFFICULTY_COUNTS[difficultyLabel] ?? inDifficulty.length;
  const weightFn = (q) => priorityWeight(topicStatsForCategory[q.topic]?.accuracy);

  if (inDifficulty.length <= count) {
    return weightedOrder(inDifficulty, weightFn);
  }

  const recentlySeen = new Set(getRecentlySeen(categoryName, difficultyLabel));
  const unseen = inDifficulty.filter((q) => !recentlySeen.has(q.id));
  const pool = unseen.length >= count ? unseen : inDifficulty;

  const ordered = weightedOrder(pool, weightFn).slice(0, count);
  const final = weightedOrder(ordered, weightFn);

  setRecentlySeen(categoryName, difficultyLabel, final.map((q) => q.id));
  return final;
}
