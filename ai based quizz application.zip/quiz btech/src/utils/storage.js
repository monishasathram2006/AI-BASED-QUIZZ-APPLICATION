import { readLocalStorage, writeLocalStorage, removeLocalStorage } from '../hooks/useLocalStorage.js';

// Single low-level persistence layer for every new CodePrep system
// (gamification, mistakes, daily challenge, interview, debugging, coding).
// The original quiz engine's own keys (codeprep_quiz_attempts,
// codeprep_last_result, codeprep_quiz_session, codeprep_dark_mode) are
// intentionally left owned by progressService.js / useDarkMode.js — they
// already work and already follow this same safe-read/write discipline.
export const STORAGE_KEYS = {
  USER: 'codeprep_user',
  MISTAKES: 'codeprep_mistakes',
  STREAK: 'codeprep_streak',
  XP: 'codeprep_xp',
  BADGES: 'codeprep_badges',
  DAILY_CHALLENGE: 'codeprep_daily_challenge',
  PREFERENCES: 'codeprep_preferences',
  STUDY_PLAN: 'codeprep_study_plan',
  INTERVIEW_ATTEMPTS: 'codeprep_interview_attempts',
  DEBUG_STATS: 'codeprep_debug_stats',
  CODING_ATTEMPTS: 'codeprep_coding_attempts',
  DAILY_ACTIVITY: 'codeprep_daily_activity',
  RECENT_QUESTIONS: 'codeprep_recent_questions',
};

export function safeGet(key, fallback) {
  return readLocalStorage(key, fallback);
}

export function safeSet(key, value) {
  return writeLocalStorage(key, value);
}

export function safeRemove(key) {
  removeLocalStorage(key);
}

export function saveUser(user) {
  safeSet(STORAGE_KEYS.USER, user);
}

export function getUser() {
  return safeGet(STORAGE_KEYS.USER, null);
}

export function saveStreak(streak) {
  safeSet(STORAGE_KEYS.STREAK, streak);
}

export function getStreak() {
  return safeGet(STORAGE_KEYS.STREAK, null);
}

export function saveXP(xp) {
  safeSet(STORAGE_KEYS.XP, xp);
}

export function getXP() {
  return safeGet(STORAGE_KEYS.XP, 0);
}

export function saveBadge(badges) {
  safeSet(STORAGE_KEYS.BADGES, badges);
}

export function getBadges() {
  return safeGet(STORAGE_KEYS.BADGES, []);
}

// Mistake/question-stat records: { [questionId]: { questionId, category,
// topic, difficulty, attempts, wrongCount, correctCount, lastAttempted } }
export function saveMistake(records) {
  safeSet(STORAGE_KEYS.MISTAKES, records);
}

export function getMistakes() {
  return safeGet(STORAGE_KEYS.MISTAKES, {});
}

export function clearAllProgress() {
  Object.values(STORAGE_KEYS).forEach((key) => safeRemove(key));
}
