// Static company metadata only — readiness percentages are computed live
// from real quiz/topic stats in src/pages/Companies.jsx /
// CompanyDetail.jsx, never stored here.
//
// Each "focusArea" references a bucket that src/utils/progressStorage.js
// can honestly answer:
//   Programming        -> average accuracy across Python/C/C++/Java Development
//   OOP                -> cross-category OOP-topic aggregate
//   Web Development     -> Web Development category accuracy
//   Full Stack          -> Full Stack category accuracy
//   DSA / DBMS / Operating Systems / Computer Networks
//                        -> always "Not started" today (no question content yet)
export const companies = [
  { slug: 'tcs', name: 'TCS', icon: '🏢', focusAreas: ['Programming', 'OOP', 'DBMS', 'Web Development'] },
  { slug: 'infosys', name: 'Infosys', icon: '🏢', focusAreas: ['Programming', 'OOP', 'DBMS', 'Full Stack'] },
  { slug: 'wipro', name: 'Wipro', icon: '🏢', focusAreas: ['Programming', 'DBMS', 'Web Development', 'Operating Systems'] },
  { slug: 'accenture', name: 'Accenture', icon: '🏢', focusAreas: ['Programming', 'Full Stack', 'DBMS', 'OOP'] },
  { slug: 'cognizant', name: 'Cognizant', icon: '🏢', focusAreas: ['Programming', 'OOP', 'Web Development', 'DBMS'] },
  { slug: 'amazon', name: 'Amazon', icon: '📦', focusAreas: ['DSA', 'Programming', 'OOP', 'Full Stack'] },
  { slug: 'microsoft', name: 'Microsoft', icon: '🪟', focusAreas: ['Programming', 'OOP', 'DSA', 'Operating Systems'] },
  { slug: 'google', name: 'Google', icon: '🔍', focusAreas: ['DSA', 'Programming', 'Operating Systems', 'Computer Networks'] },
];

export const getCompanyBySlug = (slug) => companies.find((c) => c.slug === slug);
