// Real "find the bug" questions, hand-authored per language. Every snippet
// is syntactically valid — the bug is a logic/runtime issue, never a typo,
// per the requirement to use genuine programming examples.
export const debuggingQuestions = [
  // ---- C ----
  {
    id: 'debug-c-001',
    language: 'c',
    difficulty: 'Easy',
    topic: 'Array Bounds',
    code: `int arr[5] = {1, 2, 3, 4, 5};
for (int i = 0; i <= 5; i++) {
    printf("%d ", arr[i]);
}`,
    options: ['Wrong loop condition', 'Wrong variable name', 'Wrong data type', 'No bug'],
    correctAnswer: 'Wrong loop condition',
    explanation: 'arr has indices 0-4. The condition i <= 5 lets i reach 5, reading one element past the end of the array (undefined behavior).',
  },
  {
    id: 'debug-c-002',
    language: 'c',
    difficulty: 'Easy',
    topic: 'Uninitialized Pointer',
    code: `int *p;
*p = 10;
printf("%d", *p);`,
    options: ['Missing semicolon', 'Uninitialized pointer', 'Wrong printf format', 'No bug'],
    correctAnswer: 'Uninitialized pointer',
    explanation: "p is declared but never pointed at valid memory. Dereferencing it to assign *p = 10 writes to an unknown address — undefined behavior, often a crash.",
  },
  {
    id: 'debug-c-003',
    language: 'c',
    difficulty: 'Medium',
    topic: 'Integer Division',
    code: `int a = 5, b = 2;
float result = a / b;
printf("%f", result);`,
    options: ['Integer division happens before the float assignment', 'Wrong printf format specifier', 'b should be a float literal', 'No bug'],
    correctAnswer: 'Integer division happens before the float assignment',
    explanation: 'a / b is computed as integer division (5 / 2 = 2) before the result is converted to float, so result is 2.0 instead of the expected 2.5.',
  },
  {
    id: 'debug-c-004',
    language: 'c',
    difficulty: 'Medium',
    topic: 'Switch Fallthrough',
    code: `int day = 1;
switch (day) {
    case 1:
        printf("Monday ");
    case 2:
        printf("Tuesday ");
    case 3:
        printf("Wednesday ");
        break;
}`,
    options: ['Missing break statements', 'Wrong case values', 'Missing default case', 'No bug'],
    correctAnswer: 'Missing break statements',
    explanation: 'Without a break after case 1, execution falls through into case 2 and case 3, printing "Monday Tuesday Wednesday " instead of just "Monday ".',
  },
  {
    id: 'debug-c-005',
    language: 'c',
    difficulty: 'Hard',
    topic: 'Unsigned Integer Underflow',
    code: `unsigned int i;
for (i = 5; i >= 0; i--) {
    printf("%d ", i);
}`,
    options: ['Infinite loop from unsigned underflow', 'Wrong printf format specifier', 'Wrong starting value', 'No bug'],
    correctAnswer: 'Infinite loop from unsigned underflow',
    explanation: 'i is unsigned, so it can never be negative — the condition i >= 0 is always true. When i reaches 0 and decrements, it wraps around to a huge positive number instead of stopping, causing an infinite loop.',
  },

  // ---- C++ ----
  {
    id: 'debug-cpp-001',
    language: 'cpp',
    difficulty: 'Easy',
    topic: 'Array Bounds',
    code: `vector<int> v = {1, 2, 3, 4, 5};
for (int i = 0; i <= v.size(); i++) {
    cout << v[i] << " ";
}`,
    options: ['Wrong loop condition', 'Wrong container type', 'Wrong variable type', 'No bug'],
    correctAnswer: 'Wrong loop condition',
    explanation: 'v.size() is 5, so valid indices are 0-4. i <= v.size() allows i to reach 5, which is out of bounds.',
  },
  {
    id: 'debug-cpp-002',
    language: 'cpp',
    difficulty: 'Medium',
    topic: 'Dangling Pointer',
    code: `int* getValue() {
    int x = 42;
    return &x;
}`,
    options: ['Returns address of a local variable', 'Missing return type', 'x should be static', 'No bug'],
    correctAnswer: 'Returns address of a local variable',
    explanation: 'x is a local variable that is destroyed when the function returns. The returned pointer is dangling — it points to memory that is no longer valid.',
  },
  {
    id: 'debug-cpp-003',
    language: 'cpp',
    difficulty: 'Medium',
    topic: 'Memory Leak',
    code: `void createArray() {
    int* arr = new int[10];
    arr[0] = 1;
}`,
    options: ['Memory allocated with new is never freed', 'Wrong array size', 'Wrong index used', 'No bug'],
    correctAnswer: 'Memory allocated with new is never freed',
    explanation: 'arr is allocated with new[] but never released with delete[]. Every call to createArray() leaks 10 ints of memory.',
  },
  {
    id: 'debug-cpp-004',
    language: 'cpp',
    difficulty: 'Medium',
    topic: 'Floating Point Precision',
    code: `double a = 0.1 + 0.2;
if (a == 0.3) {
    cout << "Equal";
} else {
    cout << "Not Equal";
}`,
    options: ['Floating-point numbers compared with exact equality', 'Wrong data type used', 'Missing cout include', 'No bug'],
    correctAnswer: 'Floating-point numbers compared with exact equality',
    explanation: '0.1 + 0.2 does not exactly equal 0.3 in binary floating-point representation, so this prints "Not Equal" even though mathematically they are equal.',
  },
  {
    id: 'debug-cpp-005',
    language: 'cpp',
    difficulty: 'Hard',
    topic: 'Uninitialized Variable',
    code: `int x;
if (x == 0) {
    cout << "Zero";
} else {
    cout << "Not Zero";
}`,
    options: ['x is used without being initialized', 'Wrong comparison operator', 'Missing else if', 'No bug'],
    correctAnswer: 'x is used without being initialized',
    explanation: 'x has no defined value before the comparison — its contents are whatever garbage was already in that memory, so the output is unpredictable.',
  },

  // ---- Java ----
  {
    id: 'debug-java-001',
    language: 'java',
    difficulty: 'Easy',
    topic: 'Array Bounds',
    code: `int[] arr = {1, 2, 3};
for (int i = 0; i <= arr.length; i++) {
    System.out.println(arr[i]);
}`,
    options: ['Wrong loop condition', 'Wrong array declaration', 'Wrong print method', 'No bug'],
    correctAnswer: 'Wrong loop condition',
    explanation: 'arr.length is 3, so valid indices are 0-2. i <= arr.length lets i reach 3, throwing ArrayIndexOutOfBoundsException.',
  },
  {
    id: 'debug-java-002',
    language: 'java',
    difficulty: 'Easy',
    topic: 'Null Pointer',
    code: `String s = null;
if (s.equals("hello")) {
    System.out.println("Match");
}`,
    options: ['Calling a method on a null reference', 'Wrong comparison operator', 'Missing import', 'No bug'],
    correctAnswer: 'Calling a method on a null reference',
    explanation: 's is null, so calling s.equals(...) throws a NullPointerException. Using "hello".equals(s) would avoid the crash.',
  },
  {
    id: 'debug-java-003',
    language: 'java',
    difficulty: 'Medium',
    topic: 'Integer Division',
    code: `int a = 7, b = 2;
double result = a / b;
System.out.println(result);`,
    options: ['Integer division happens before the double assignment', 'Wrong variable types declared', 'println formats the number wrong', 'No bug'],
    correctAnswer: 'Integer division happens before the double assignment',
    explanation: 'a / b performs integer division (7 / 2 = 3) before the result is widened to double, printing 3.0 instead of the expected 3.5.',
  },
  {
    id: 'debug-java-004',
    language: 'java',
    difficulty: 'Medium',
    topic: 'Reference vs Value Equality',
    code: `String a = new String("hello");
String b = new String("hello");
if (a == b) {
    System.out.println("Same");
} else {
    System.out.println("Different");
}`,
    options: ['== compares object references, not content', 'Strings cannot be compared', 'Missing toString() call', 'No bug'],
    correctAnswer: '== compares object references, not content',
    explanation: 'a and b are two different String objects with equal content. == compares references (memory addresses), so it prints "Different" — a.equals(b) should be used instead.',
  },
  {
    id: 'debug-java-005',
    language: 'java',
    difficulty: 'Hard',
    topic: 'Infinite Loop',
    code: `for (int i = 10; i > 0; i++) {
    System.out.println(i);
}`,
    options: ['Loop variable increments instead of decrements', 'Wrong starting value', 'Wrong comparison operator', 'No bug'],
    correctAnswer: 'Loop variable increments instead of decrements',
    explanation: 'i++ increases i every iteration while the condition checks i > 0, which stays true forever — this is an infinite loop. It should be i--.',
  },

  // ---- Python ----
  {
    id: 'debug-python-001',
    language: 'python',
    difficulty: 'Easy',
    topic: 'Array Bounds',
    code: `arr = [1, 2, 3, 4, 5]
for i in range(len(arr) + 1):
    print(arr[i])`,
    options: ['Wrong range bound', 'Wrong list definition', 'Wrong print syntax', 'No bug'],
    correctAnswer: 'Wrong range bound',
    explanation: 'len(arr) is 5, so valid indices are 0-4. range(len(arr) + 1) produces 0..5, and arr[5] raises an IndexError.',
  },
  {
    id: 'debug-python-002',
    language: 'python',
    difficulty: 'Medium',
    topic: 'Mutable Default Argument',
    code: `def add_item(item, items=[]):
    items.append(item)
    return items

print(add_item(1))
print(add_item(2))`,
    options: ['Mutable default argument persists across calls', 'append() is used incorrectly', 'Missing return statement', 'No bug'],
    correctAnswer: 'Mutable default argument persists across calls',
    explanation: 'The default list is created once when the function is defined, not on every call, so it keeps growing. The second call prints [1, 2] instead of the expected [2].',
  },
  {
    id: 'debug-python-003',
    language: 'python',
    difficulty: 'Medium',
    topic: 'Operator Precedence',
    code: `def average(a, b):
    return a + b / 2

print(average(4, 6))`,
    options: ['Division happens before addition', 'Wrong function arguments', 'Wrong return type', 'No bug'],
    correctAnswer: 'Division happens before addition',
    explanation: 'b / 2 is evaluated first due to operator precedence, giving 4 + 3 = 7 instead of the intended (4 + 6) / 2 = 5.',
  },
  {
    id: 'debug-python-004',
    language: 'python',
    difficulty: 'Medium',
    topic: 'Exception Handling',
    code: `try:
    result = 10 / 0
except:
    pass
print(result)`,
    options: ['Bare except silently hides the error and result is never set', 'Division by zero is valid in Python', 'print() is used incorrectly', 'No bug'],
    correctAnswer: 'Bare except silently hides the error and result is never set',
    explanation: 'The ZeroDivisionError is caught and silently ignored, so result is never assigned. Referencing result afterward raises a NameError instead of surfacing the real problem.',
  },
  {
    id: 'debug-python-005',
    language: 'python',
    difficulty: 'Hard',
    topic: 'Floating Point Precision',
    code: `a = 0.1 + 0.2
if a == 0.3:
    print("Equal")
else:
    print("Not Equal")`,
    options: ['Floating-point numbers compared with exact equality', 'Wrong variable name used', 'Missing parentheses', 'No bug'],
    correctAnswer: 'Floating-point numbers compared with exact equality',
    explanation: '0.1 + 0.2 evaluates to 0.30000000000000004 due to binary floating-point representation, so it does not exactly equal 0.3.',
  },

  // ---- JavaScript ----
  {
    id: 'debug-js-001',
    language: 'javascript',
    difficulty: 'Easy',
    topic: 'Array Bounds',
    code: `const arr = [1, 2, 3, 4, 5];
for (let i = 0; i <= arr.length; i++) {
    console.log(arr[i]);
}`,
    options: ['Wrong loop condition', 'Wrong array declaration', 'const cannot be looped over', 'No bug'],
    correctAnswer: 'Wrong loop condition',
    explanation: 'arr.length is 5, so valid indices are 0-4. i <= arr.length reads arr[5], which is undefined.',
  },
  {
    id: 'debug-js-002',
    language: 'javascript',
    difficulty: 'Medium',
    topic: 'Closure/Scope',
    code: `for (var i = 0; i < 3; i++) {
    setTimeout(function () {
        console.log(i);
    }, 100);
}`,
    options: ['var is function-scoped, so all callbacks share the same i', 'setTimeout is called incorrectly', 'The loop condition is wrong', 'No bug'],
    correctAnswer: 'var is function-scoped, so all callbacks share the same i',
    explanation: 'Because var is not block-scoped, all three callbacks close over the same i, which is 3 by the time they run — it prints 3, 3, 3 instead of 0, 1, 2. Using let fixes it.',
  },
  {
    id: 'debug-js-003',
    language: 'javascript',
    difficulty: 'Medium',
    topic: 'NaN Comparison',
    code: `let result = "5" - "abc";
if (result === NaN) {
    console.log("Not a number");
} else {
    console.log("Valid");
}`,
    options: ['NaN is never equal to NaN', 'Subtraction cannot be used on strings', 'Wrong variable declaration', 'No bug'],
    correctAnswer: 'NaN is never equal to NaN',
    explanation: 'result is indeed NaN, but NaN === NaN is always false by the IEEE 754 spec. The code should use Number.isNaN(result) instead, so it incorrectly logs "Valid".',
  },
  {
    id: 'debug-js-004',
    language: 'javascript',
    difficulty: 'Medium',
    topic: 'Type Coercion',
    code: `function sum(a, b) {
    return a + b;
}
console.log(sum("5", 3));`,
    options: ['String concatenation instead of numeric addition', 'Wrong function name', 'Missing return statement', 'No bug'],
    correctAnswer: 'String concatenation instead of numeric addition',
    explanation: '"5" is a string, so + concatenates instead of adding: sum("5", 3) returns "53" instead of the expected 8.',
  },
  {
    id: 'debug-js-005',
    language: 'javascript',
    difficulty: 'Hard',
    topic: 'Async/Await',
    code: `async function getData() {
    return 42;
}

function useData() {
    const value = getData();
    console.log(value + 1);
}
useData();`,
    options: ['Missing await — value is a Promise, not 42', 'getData() should not be async', 'console.log used incorrectly', 'No bug'],
    correctAnswer: 'Missing await — value is a Promise, not 42',
    explanation: 'An async function always returns a Promise. Without await, value holds a pending Promise object, so value + 1 produces a string like "[object Promise]1" instead of 43.',
  },
];

export function getDebuggingQuestionsByLanguage(language) {
  return debuggingQuestions.filter((q) => q.language === language);
}

export const DEBUG_LANGUAGES = ['c', 'cpp', 'java', 'python', 'javascript'];
export const DEBUG_LANGUAGE_LABELS = { c: 'C', cpp: 'C++', java: 'Java', python: 'Python', javascript: 'JavaScript' };
