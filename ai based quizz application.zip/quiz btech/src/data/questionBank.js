import { pythonQuestions } from './questions/pythonQuestions.js';
import { cQuestions } from './questions/cQuestions.js';
import { cppQuestions } from './questions/cppQuestions.js';
import { fullStackQuestions } from './questions/fullStackQuestions.js';
import { webDevelopmentQuestions } from './questions/webDevelopmentQuestions.js';
import { javaQuestions } from './questions/javaQuestions.js';
import { dsaQuestions } from './questions/dsaQuestions.js';
import { dbmsQuestions } from './questions/dbmsQuestions.js';
import { osQuestions } from './questions/osQuestions.js';
import { networksQuestions } from './questions/networksQuestions.js';
import { systemDesignQuestions } from './questions/systemDesignQuestions.js';
import { cloudDevOpsQuestions } from './questions/cloudDevOpsQuestions.js';
import { aimlQuestions } from './questions/aimlQuestions.js';
import { cybersecurityQuestions } from './questions/cybersecurityQuestions.js';

export const questionBank = [
  ...pythonQuestions,
  ...cQuestions,
  ...cppQuestions,
  ...fullStackQuestions,
  ...webDevelopmentQuestions,
  ...javaQuestions,
  ...dsaQuestions,
  ...dbmsQuestions,
  ...osQuestions,
  ...networksQuestions,
  ...systemDesignQuestions,
  ...cloudDevOpsQuestions,
  ...aimlQuestions,
  ...cybersecurityQuestions,
];

export function getQuestionsByCategory(categoryName) {
  return questionBank.filter((q) => q.category === categoryName);
}

export function getQuestionsByCategoryAndDifficulty(categoryName, difficulty) {
  return questionBank.filter((q) => q.category === categoryName && q.difficulty === difficulty);
}

export function searchQuestions(term, { category, difficulty, topic } = {}) {
  const lower = term?.trim().toLowerCase() ?? '';
  return questionBank.filter((q) => {
    if (category && q.category !== category) return false;
    if (difficulty && q.difficulty !== difficulty) return false;
    if (topic && q.topic !== topic) return false;
    if (!lower) return true;
    return (
      q.question.toLowerCase().includes(lower) ||
      q.topic.toLowerCase().includes(lower) ||
      q.category.toLowerCase().includes(lower) ||
      q.explanation.toLowerCase().includes(lower)
    );
  });
}
