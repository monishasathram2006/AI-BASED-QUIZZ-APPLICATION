export const dbmsQuestions = [
  {
    id: "dbms-easy-001",
    category: "DBMS & SQL",
    difficulty: "Easy",
    topic: "DBMS Fundamentals",
    question: "Which of the following uniquely identifies each record in a database table and cannot contain NULL values?",
    options: ["Primary Key", "Foreign Key", "Super Key", "Alternate Key"],
    correctAnswer: "Primary Key",
    explanation: "A Primary Key enforces entity integrity by uniquely identifying every row in a table. It strictly disallows NULL values.",
    points: 10
  },
  {
    id: "dbms-easy-002",
    category: "DBMS & SQL",
    difficulty: "Easy",
    topic: "SQL Basics",
    question: "Which SQL clause is used to eliminate duplicate rows from a query result?",
    options: ["DISTINCT", "UNIQUE", "GROUP BY", "FILTER"],
    correctAnswer: "DISTINCT",
    explanation: "The SELECT DISTINCT syntax returns only unique records from the targeted column set, discarding duplicate rows.",
    points: 10
  },
  {
    id: "dbms-easy-003",
    category: "DBMS & SQL",
    difficulty: "Easy",
    topic: "SQL Queries",
    question: "What is the primary difference between WHERE and HAVING clauses in SQL?",
    options: [
      "WHERE filters individual rows before grouping; HAVING filters aggregated groups after GROUP BY",
      "WHERE is used only with subqueries; HAVING is used with primary queries",
      "HAVING filters individual rows before grouping; WHERE filters aggregated groups",
      "WHERE can only be used with numbers; HAVING only with strings"
    ],
    correctAnswer: "WHERE filters individual rows before grouping; HAVING filters aggregated groups after GROUP BY",
    explanation: "The WHERE clause filters rows prior to any aggregation. The HAVING clause applies filters specifically to summarized groups produced by GROUP BY.",
    points: 10
  },
  {
    id: "dbms-easy-004",
    category: "DBMS & SQL",
    difficulty: "Easy",
    topic: "ACID Properties",
    question: "What does the 'A' in the ACID properties of a database transaction represent?",
    options: ["Atomicity", "Availability", "Authentication", "Asynchronous"],
    correctAnswer: "Atomicity",
    explanation: "Atomicity ensures that all operations within a transaction are completed successfully (all-or-nothing). If any part fails, the entire transaction is rolled back.",
    points: 10
  },
  {
    id: "dbms-easy-005",
    category: "DBMS & SQL",
    difficulty: "Easy",
    topic: "SQL Joins",
    question: "Which join returns only the records that have matching values in both tables?",
    options: ["INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "FULL OUTER JOIN"],
    correctAnswer: "INNER JOIN",
    explanation: "An INNER JOIN selects records with matching values in both tables, omitting rows where the join predicate evaluates to false or NULL.",
    points: 10
  },
  {
    id: "dbms-easy-006",
    category: "DBMS & SQL",
    difficulty: "Easy",
    topic: "DBMS Keys",
    question: "What is the purpose of a Foreign Key in a relational database?",
    options: [
      "To enforce referential integrity between two related tables",
      "To speed up search queries across disjoint schemas",
      "To compress row data storage on physical disks",
      "To create a temporary copy of a table for indexing"
    ],
    correctAnswer: "To enforce referential integrity between two related tables",
    explanation: "A Foreign Key is a field (or collection of fields) in one table that refers to the Primary Key in another table, guaranteeing referential integrity between them.",
    points: 10
  },
  {
    id: "dbms-easy-007",
    category: "DBMS & SQL",
    difficulty: "Easy",
    topic: "SQL Commands",
    question: "Which of the following commands is classified under DDL (Data Definition Language)?",
    options: ["ALTER", "UPDATE", "INSERT", "DELETE"],
    correctAnswer: "ALTER",
    explanation: "DDL commands define and modify the schema and structure of database objects (CREATE, ALTER, DROP, TRUNCATE). Commands like INSERT, UPDATE, and DELETE are DML.",
    points: 10
  },
  {
    id: "dbms-easy-008",
    category: "DBMS & SQL",
    difficulty: "Easy",
    topic: "Aggregate Functions",
    question: "How does COUNT(*) differ from COUNT(column_name) in standard SQL?",
    options: [
      "COUNT(*) counts all rows including NULLs; COUNT(column_name) counts only rows where column_name is NOT NULL",
      "COUNT(*) is slower and only counts unique values",
      "COUNT(column_name) includes NULL values whereas COUNT(*) ignores NULLs",
      "There is no difference in result or execution"
    ],
    correctAnswer: "COUNT(*) counts all rows including NULLs; COUNT(column_name) counts only rows where column_name is NOT NULL",
    explanation: "COUNT(*) tallies every row returned by the query regardless of contents, whereas COUNT(column_name) specifically counts non-null occurrences of that column.",
    points: 10
  },
  {
    id: "dbms-easy-009",
    category: "DBMS & SQL",
    difficulty: "Easy",
    topic: "Relational Model",
    question: "In relational database terminology, what is a 'tuple'?",
    options: ["A single row or record in a table", "A table column or attribute", "The total count of attributes", "A relationship between two tables"],
    correctAnswer: "A single row or record in a table",
    explanation: "In relational model theory formal terminology: a Relation is a table, an Attribute is a column, and a Tuple represents a single row (record).",
    points: 10
  },
  {
    id: "dbms-easy-010",
    category: "DBMS & SQL",
    difficulty: "Easy",
    topic: "SQL Constraints",
    question: "How does a UNIQUE constraint differ from a PRIMARY KEY constraint?",
    options: [
      "A table can have multiple UNIQUE columns and they allow NULL values, while only one PRIMARY KEY is allowed and cannot be NULL",
      "UNIQUE constraints cannot be indexed",
      "PRIMARY KEY allows multiple NULL values whereas UNIQUE does not",
      "UNIQUE constraints only apply to numeric columns"
    ],
    correctAnswer: "A table can have multiple UNIQUE columns and they allow NULL values, while only one PRIMARY KEY is allowed and cannot be NULL",
    explanation: "Tables are restricted to exactly one PRIMARY KEY (no NULLs permitted), whereas multiple UNIQUE constraints can exist and generally permit a NULL value.",
    points: 10
  },
  {
    id: "dbms-easy-011",
    category: "DBMS & SQL",
    difficulty: "Medium",
    topic: "Normalization",
    question: "A relation is in Third Normal Form (3NF) if it is in 2NF and has no:",
    options: [
      "Transitive functional dependencies",
      "Partial functional dependencies",
      "Multivalued dependencies",
      "Join dependencies"
    ],
    correctAnswer: "Transitive functional dependencies",
    explanation: "3NF requires a relation to be in 2NF and contain no non-prime attribute transitively dependent on any candidate key (X -> Y and Y -> Z where Z is non-prime).",
    points: 20
  },
  {
    id: "dbms-medium-002",
    category: "DBMS & SQL",
    difficulty: "Medium",
    topic: "SQL Joins",
    question: "In a LEFT OUTER JOIN between Table A and Table B, what appears in Table B's columns when a row in Table A has no match in Table B?",
    options: ["NULL values", "Default zero or empty string", "An error occurs", "The row from Table A is excluded"],
    correctAnswer: "NULL values",
    explanation: "A LEFT OUTER JOIN preserves every row from the left table; whenever there is no corresponding row in the right table, NULL is filled for the right table columns.",
    points: 20
  },
  {
    id: "dbms-medium-003",
    category: "DBMS & SQL",
    difficulty: "Medium",
    topic: "Indexing & Storage",
    question: "Why are B+ Trees predominantly preferred over standard Binary Search Trees for database index storage on disk?",
    options: [
      "B+ Trees have high fan-out leading to very shallow depth, minimizing expensive disk I/O operations",
      "B+ Trees use less RAM for in-memory recursion",
      "Binary Search Trees cannot support range queries",
      "B+ Trees guarantee O(1) worst-case search complexity"
    ],
    correctAnswer: "B+ Trees have high fan-out leading to very shallow depth, minimizing expensive disk I/O operations",
    explanation: "Disk block access is slow. B+ Trees have broad node capacity (fan-out of hundreds), allowing millions of records to be indexed with only 3 to 4 disk page reads.",
    points: 20
  },
  {
    id: "dbms-medium-004",
    category: "DBMS & SQL",
    difficulty: "Medium",
    topic: "Concurrency Control",
    question: "Which concurrency anomaly occurs when Transaction A reads uncommitted data written by Transaction B, and Transaction B subsequently rolls back?",
    options: ["Dirty Read", "Non-repeatable Read", "Phantom Read", "Lost Update"],
    correctAnswer: "Dirty Read",
    explanation: "A Dirty Read occurs when a transaction reads modifications made by another uncommitted transaction that later aborts, leaving the reader with corrupted invalid state.",
    points: 20
  },
  {
    id: "dbms-medium-005",
    category: "DBMS & SQL",
    difficulty: "Medium",
    topic: "Normalization",
    question: "What is the defining condition for a relation R to be in Boyce-Codd Normal Form (BCNF)?",
    options: [
      "For every non-trivial functional dependency X -> Y, X must be a super key",
      "Every non-prime attribute is fully functionally dependent on every candidate key",
      "There are no multi-valued dependencies present",
      "Every determinant must be a composite key"
    ],
    correctAnswer: "For every non-trivial functional dependency X -> Y, X must be a super key",
    explanation: "BCNF is a stricter version of 3NF. In BCNF, for every functional dependency X -> Y, the determinant X must strictly be a super key of the relation.",
    points: 20
  },
  {
    id: "dbms-medium-006",
    category: "DBMS & SQL",
    difficulty: "Medium",
    topic: "SQL Queries",
    question: "How does a Correlated Subquery differ from a standard independent Subquery?",
    options: [
      "A Correlated Subquery references columns from the outer query and is evaluated once per outer row",
      "A Correlated Subquery executes only once before the outer query runs",
      "A Correlated Subquery cannot contain aggregate functions",
      "A Correlated Subquery produces an indexed temporary table automatically"
    ],
    correctAnswer: "A Correlated Subquery references columns from the outer query and is evaluated once per outer row",
    explanation: "Because a correlated subquery depends on values from the current candidate row of the outer query, it must be evaluated iteratively for each row considered by the outer query.",
    points: 20
  },
  {
    id: "dbms-medium-007",
    category: "DBMS & SQL",
    difficulty: "Medium",
    topic: "Concurrency Control",
    question: "What characterizes the Two-Phase Locking (2PL) protocol in transaction management?",
    options: [
      "A growing phase where locks are only acquired, followed by a shrinking phase where locks are only released",
      "Locking shared resources twice before each read and write operation",
      "A phase for validating disk caches and a second phase for writing logs",
      "Acquiring exclusive locks on even seconds and shared locks on odd seconds"
    ],
    correctAnswer: "A growing phase where locks are only acquired, followed by a shrinking phase where locks are only released",
    explanation: "Basic 2PL ensures conflict serializability by separating lock management into two phases: during the growing phase, locks can only be obtained; once any lock is released, no new locks can be acquired.",
    points: 20
  },
  {
    id: "dbms-medium-008",
    category: "DBMS & SQL",
    difficulty: "Medium",
    topic: "Views & Performance",
    question: "What is the key advantage of a Materialized View compared to a standard SQL View?",
    options: [
      "It physically persists the query result set on disk, allowing fast reads without recalculating complex joins",
      "It allows immediate writing to foreign database servers",
      "It bypasses all permission checks for administrative users",
      "It automatically partitions tables across cluster nodes"
    ],
    correctAnswer: "It physically persists the query result set on disk, allowing fast reads without recalculating complex joins",
    explanation: "Standard views are virtual queries re-executed on every read. Materialized views store the precomputed results physically, providing high read performance at the cost of refresh overhead.",
    points: 20
  },
  {
    id: "dbms-medium-009",
    category: "DBMS & SQL",
    difficulty: "Medium",
    topic: "Database Triggers",
    question: "When does an AFTER UPDATE trigger execute in an SQL database?",
    options: [
      "Immediately after the update operation modifies table records and constraint checks succeed",
      "Before validating foreign key constraints",
      "Only when an unhandled database error occurs during an update",
      "After the database engine restarts"
    ],
    correctAnswer: "Immediately after the update operation modifies table records and constraint checks succeed",
    explanation: "An AFTER UPDATE trigger fires after the specified update statement has modified the target rows and all integrity constraints have passed.",
    points: 20
  },
  {
    id: "dbms-medium-010",
    category: "DBMS & SQL",
    difficulty: "Medium",
    topic: "SQL Window Functions",
    question: "In SQL window functions, what is the key difference between RANK() and DENSE_RANK() when ties occur?",
    options: [
      "RANK() leaves gaps in rank values following ties (e.g. 1, 2, 2, 4), while DENSE_RANK() leaves no gaps (e.g. 1, 2, 2, 3)",
      "DENSE_RANK() assigns ranks randomly whereas RANK() is deterministic",
      "RANK() can only be used with numbers, while DENSE_RANK() can rank strings",
      "DENSE_RANK() resets ranking after every 10 rows"
    ],
    correctAnswer: "RANK() leaves gaps in rank values following ties (e.g. 1, 2, 2, 4), while DENSE_RANK() leaves no gaps (e.g. 1, 2, 2, 3)",
    explanation: "Both rank items in an ordered partition, but RANK() skips subsequent ranks based on tie count (1, 1, 3), whereas DENSE_RANK() increments sequentially without missing numbers (1, 1, 2).",
    points: 20
  },
  {
    id: "dbms-hard-001",
    category: "DBMS & SQL",
    difficulty: "Hard",
    topic: "Concurrency & Serializability",
    question: "How is Conflict Serializability of a concurrent schedule mathematically verified?",
    options: [
      "By constructing a Precedence (Serialization) Graph and verifying that it is acyclic",
      "By checking if all transactions execute under strict timestamp ordering",
      "By confirming that no two transactions share read locks simultaneously",
      "By calculating the checksum of all committed transaction logs"
    ],
    correctAnswer: "By constructing a Precedence (Serialization) Graph and verifying that it is acyclic",
    explanation: "In a precedence graph, an edge Ti -> Tj is drawn if Ti has a conflicting operation before Tj. The schedule is conflict serializable if and only if the precedence graph contains no directed cycles.",
    points: 30
  },
  {
    id: "dbms-hard-002",
    category: "DBMS & SQL",
    difficulty: "Hard",
    topic: "Deadlock Prevention",
    question: "In transaction timestamp-based deadlock prevention, what is the strategy of the 'Wait-Die' scheme when transaction Ti requests a data item locked by Tj?",
    options: [
      "If Ti is older (timestamp Ti < Tj), Ti is allowed to wait; if Ti is younger (Ti > Tj), Ti dies (rolls back and restarts)",
      "If Ti is younger, Ti pre-empts Tj and kills it; otherwise Ti waits",
      "Both Ti and Tj are rolled back immediately",
      "Ti acquires the lock immediately and forces Tj into read-only mode"
    ],
    correctAnswer: "If Ti is older (timestamp Ti < Tj), Ti is allowed to wait; if Ti is younger (Ti > Tj), Ti dies (rolls back and restarts)",
    explanation: "In Wait-Die (non-preemptive): older transactions are allowed to wait for younger ones, while younger transactions die and abort if they attempt to request a lock held by an older transaction.",
    points: 30
  },
  {
    id: "dbms-hard-003",
    category: "DBMS & SQL",
    difficulty: "Hard",
    topic: "Indexing & Physical Storage",
    question: "What fundamentally distinguishes a Clustered Index from a Non-Clustered Index?",
    options: [
      "A Clustered Index determines the actual physical order of table data rows on disk, so a table can have only one",
      "A Clustered Index does not use B+ trees whereas a Non-Clustered Index does",
      "A Non-Clustered Index changes physical storage while Clustered Indexes are in-memory only",
      "Clustered indexes are created exclusively for foreign key columns"
    ],
    correctAnswer: "A Clustered Index determines the actual physical order of table data rows on disk, so a table can have only one",
    explanation: "Because physical data records can only be stored in one sorted sequence on disk, a table can only have one clustered index. Non-clustered indexes store pointers/rowids to the actual data.",
    points: 30
  },
  {
    id: "dbms-hard-004",
    category: "DBMS & SQL",
    difficulty: "Hard",
    topic: "Recovery & Logging",
    question: "What rule does the Write-Ahead Logging (WAL) protocol mandate to ensure durability (D in ACID)?",
    options: [
      "Log records describing changes must be flushed to non-volatile disk before the corresponding dirty data pages are written to disk",
      "Data pages must be written to disk before transactions can request write locks",
      "Logs are written to memory buffers only when the database engine stops",
      "Every query must be logged to a separate secondary replica synchronously"
    ],
    correctAnswer: "Log records describing changes must be flushed to non-volatile disk before the corresponding dirty data pages are written to disk",
    explanation: "WAL guarantees that in the event of an abrupt system crash or power outage, the DBMS recovery manager can REDO committed updates and UNDO uncommitted changes from stable log records.",
    points: 30
  },
  {
    id: "dbms-hard-005",
    category: "DBMS & SQL",
    difficulty: "Hard",
    topic: "Query Optimization",
    question: "In database query execution engines, why does high column cardinality improve the selectivity and efficiency of a B-Tree index scan?",
    options: [
      "High cardinality means many distinct values, allowing the index to quickly filter down candidate rows to a tiny fraction of the table",
      "High cardinality guarantees that all values are stored in consecutive disk sectors",
      "High cardinality disables the query optimizer's cost-based analysis",
      "It allows the database to skip index lookup and perform a sequential table scan"
    ],
    correctAnswer: "High cardinality means many distinct values, allowing the index to quickly filter down candidate rows to a tiny fraction of the table",
    explanation: "Cardinality refers to the uniqueness of data values in a column. Columns with high cardinality (e.g. primary keys, emails) have high selectivity, making index traversals far faster than full table scans.",
    points: 30
  }
];
