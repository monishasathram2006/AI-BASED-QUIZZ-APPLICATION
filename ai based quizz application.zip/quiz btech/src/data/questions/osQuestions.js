export const osQuestions = [
  {
    id: "os-easy-001",
    category: "Operating Systems",
    difficulty: "Easy",
    topic: "OS Architecture",
    question: "What is the primary role of the Kernel in an Operating System?",
    options: [
      "The core software component that directly manages hardware resources, memory, and system calls",
      "A graphical user interface for launching desktop applications",
      "A compiler that translates C code to machine instructions",
      "A network browser for downloading system patches"
    ],
    correctAnswer: "The core software component that directly manages hardware resources, memory, and system calls",
    explanation: "The kernel is the central, foundational module of an OS, responsible for managing memory, CPU time, peripheral devices, and system calls.",
    points: 10
  },
  {
    id: "os-easy-002",
    category: "Operating Systems",
    difficulty: "Easy",
    topic: "Processes & Threads",
    question: "What is the key difference in memory space between a Process and a Thread?",
    options: [
      "A process has its own isolated address space; threads of the same process share the same address space",
      "Threads have separate virtual memory spaces while processes share RAM",
      "Processes run in kernel space while threads only run in hardware firmware",
      "Threads cannot share global variables or open files"
    ],
    correctAnswer: "A process has its own isolated address space; threads of the same process share the same address space",
    explanation: "Processes have isolated memory protection boundaries. Threads belong to a process and share code, data, and heap, but maintain separate stacks and registers.",
    points: 10
  },
  {
    id: "os-easy-003",
    category: "Operating Systems",
    difficulty: "Easy",
    topic: "CPU Scheduling",
    question: "In First-Come, First-Served (FCFS) CPU scheduling, what is the 'Convoy Effect'?",
    options: [
      "Short processes getting stuck waiting behind a CPU-bound process with a huge burst time",
      "Processes being preempted every few milliseconds unnecessarily",
      "Two processes running simultaneously on the same hardware core",
      "Memory thrashing caused by excessive swapping"
    ],
    correctAnswer: "Short processes getting stuck waiting behind a CPU-bound process with a huge burst time",
    explanation: "Under FCFS, when a long CPU-intensive process occupies the CPU first, all subsequent short I/O-bound jobs suffer high average waiting times, known as the convoy effect.",
    points: 10
  },
  {
    id: "os-easy-004",
    category: "Operating Systems",
    difficulty: "Easy",
    topic: "Deadlocks",
    question: "Which of the following is NOT one of Coffman's four necessary conditions for a Deadlock to occur?",
    options: [
      "Asymmetric Multi-threading",
      "Mutual Exclusion",
      "Hold and Wait",
      "Circular Wait"
    ],
    correctAnswer: "Asymmetric Multi-threading",
    explanation: "Coffman's four necessary deadlock conditions are: Mutual Exclusion, Hold and Wait, No Preemption, and Circular Wait.",
    points: 10
  },
  {
    id: "os-easy-005",
    category: "Operating Systems",
    difficulty: "Easy",
    topic: "Memory Management",
    question: "What is Paging in operating systems memory management?",
    options: [
      "Dividing physical memory into fixed-size frames and virtual memory into matching pages",
      "Storing swap files exclusively on solid-state drives",
      "Compressing executable binaries into zip archives",
      "Allowing processes to write directly to GPU buffers"
    ],
    correctAnswer: "Dividing physical memory into fixed-size frames and virtual memory into matching pages",
    explanation: "Paging is a memory management scheme that eliminates the need for contiguous physical memory allocation by partitioning virtual memory into pages and physical memory into frames.",
    points: 10
  },
  {
    id: "os-easy-006",
    category: "Operating Systems",
    difficulty: "Easy",
    topic: "System Calls",
    question: "What mechanism allows a user-mode program to request a service from the privileged kernel mode?",
    options: ["System Call", "Interrupt Vector Table reset", "DMA Request", "Instruction Cache Miss"],
    correctAnswer: "System Call",
    explanation: "System calls (such as open(), read(), fork()) provide the controlled programming interface through which user-space applications request privileged operating system kernel services.",
    points: 10
  },
  {
    id: "os-easy-007",
    category: "Operating Systems",
    difficulty: "Easy",
    topic: "Process Lifecycle",
    question: "In standard 5-state process lifecycle models, to which state does a Running process move when it initiates an I/O operation?",
    options: ["Waiting / Blocked", "Ready", "Terminated", "Suspended Ready"],
    correctAnswer: "Waiting / Blocked",
    explanation: "When a running process initiates an I/O operation or waits for an event, the scheduler moves it to the Waiting/Blocked state until the requested I/O completion interrupt fires.",
    points: 10
  },
  {
    id: "os-easy-008",
    category: "Operating Systems",
    difficulty: "Easy",
    topic: "Synchronization",
    question: "What is a Race Condition in concurrent programming?",
    options: [
      "A situation where system output depends on the non-deterministic execution order of concurrent threads accessing shared mutable state",
      "When a CPU clock rate exceeds thermal threshold limits",
      "A benchmark test measuring memory bandwidth between cores",
      "When two processes compete for the same network port"
    ],
    correctAnswer: "A situation where system output depends on the non-deterministic execution order of concurrent threads accessing shared mutable state",
    explanation: "A race condition arises when multiple threads read and write shared data concurrently without synchronization, resulting in unpredictable and buggy behavior depending on timing.",
    points: 10
  },
  {
    id: "os-easy-009",
    category: "Operating Systems",
    difficulty: "Easy",
    topic: "Virtual Memory",
    question: "What causes a Page Fault interrupt in virtual memory systems?",
    options: [
      "When a process accesses a virtual memory page that is not currently mapped into physical RAM",
      "When a page in memory is corrupted by cosmic rays",
      "When the CPU runs an invalid assembly opcode",
      "When two programs have the same process identifier"
    ],
    correctAnswer: "When a process accesses a virtual memory page that is not currently mapped into physical RAM",
    explanation: "A page fault is a hardware interrupt raised when a program accesses a valid address in virtual address space that is marked non-resident (must be loaded from swap/disk into RAM).",
    points: 10
  },
  {
    id: "os-easy-010",
    category: "Operating Systems",
    difficulty: "Easy",
    topic: "Virtual Memory",
    question: "What is 'Thrashing' in an operating system?",
    options: [
      "A state where the system spends significantly more time swapping pages in and out of disk than executing instructions",
      "An algorithm to clean up dangling pointer allocations",
      "Fast cycling of CPU clock speeds to save battery power",
      "Rapidly creating and deleting temporary files"
    ],
    correctAnswer: "A state where the system spends significantly more time swapping pages in and out of disk than executing instructions",
    explanation: "Thrashing occurs when active working sets of processes exceed available physical memory. Page faults occur continually, causing high disk I/O and near-zero CPU throughput.",
    points: 10
  },
  {
    id: "os-medium-001",
    category: "Operating Systems",
    difficulty: "Medium",
    topic: "CPU Scheduling",
    question: "In Round Robin CPU scheduling, what happens if the time quantum is chosen to be extremely large?",
    options: [
      "It degenerates into First-Come, First-Served (FCFS) scheduling",
      "It causes starvation for all short processes",
      "Context switching overhead increases exponentially",
      "The CPU enters an infinite deadlock loop"
    ],
    correctAnswer: "It degenerates into First-Come, First-Served (FCFS) scheduling",
    explanation: "If the time quantum exceeds the burst time of every ready process, each job finishes its entire CPU burst without being preempted, behaving identically to FCFS.",
    points: 20
  },
  {
    id: "os-medium-002",
    category: "Operating Systems",
    difficulty: "Medium",
    topic: "Process Synchronization",
    question: "How does a Counting Semaphore differ from a Binary Semaphore (Mutex)?",
    options: [
      "A counting semaphore maintains an integer count and can control access to a finite pool of multiple resource instances",
      "A counting semaphore can only be used by one thread at a time",
      "Counting semaphores cannot be decremented",
      "Binary semaphores are implemented in hardware while counting semaphores are pure software"
    ],
    correctAnswer: "A counting semaphore maintains an integer count and can control access to a finite pool of multiple resource instances",
    explanation: "A counting semaphore's integer value can range over an unrestricted domain, representing the number of available resource units. A binary semaphore takes values 0 or 1.",
    points: 20
  },
  {
    id: "os-medium-003",
    category: "Operating Systems",
    difficulty: "Medium",
    topic: "Deadlock Avoidance",
    question: "What is the primary purpose of the Banker's Algorithm in operating systems?",
    options: [
      "To avoid deadlocks by testing for safe states before allocating requested resources to processes",
      "To terminate processes when physical memory is depleted",
      "To detect cycles in resource allocation graphs after deadlocks occur",
      "To balance financial transactions in distributed banking clusters"
    ],
    correctAnswer: "To avoid deadlocks by testing for safe states before allocating requested resources to processes",
    explanation: "The Banker's Algorithm simulates resource allocation for maximum possible claims to ensure that the system never enters an unsafe state that could eventually lead to deadlock.",
    points: 20
  },
  {
    id: "os-medium-004",
    category: "Operating Systems",
    difficulty: "Medium",
    topic: "Memory Management",
    question: "What type of memory fragmentation is inherent in Paging systems, and why?",
    options: [
      "Internal fragmentation, because the last allocated page frame of a process is rarely filled completely",
      "External fragmentation, because memory holes are scattered unpredictably",
      "Segmentation fragmentation, because segment descriptors overlap",
      "No fragmentation can ever exist in paging"
    ],
    correctAnswer: "Internal fragmentation, because the last allocated page frame of a process is rarely filled completely",
    explanation: "Paging avoids external fragmentation because any free frame can be allocated to any page. However, since frames are fixed size (e.g. 4KB), unused space at the end of the last page causes internal fragmentation.",
    points: 20
  },
  {
    id: "os-medium-005",
    category: "Operating Systems",
    difficulty: "Medium",
    topic: "Virtual Memory",
    question: "What is Belady's Anomaly in page replacement algorithms?",
    options: [
      "An anomaly in FIFO page replacement where increasing the number of page frames results in an increase in page faults",
      "LRU taking more memory than optimal page replacement",
      "Page faults occurring even when all memory is empty",
      "The CPU skipping page table entries during address translation"
    ],
    correctAnswer: "An anomaly in FIFO page replacement where increasing the number of page frames results in an increase in page faults",
    explanation: "Belady's anomaly shows that for certain replacement policies (notably FIFO), giving a process more memory frames can paradoxically increase the total number of page faults.",
    points: 20
  },
  {
    id: "os-medium-006",
    category: "Operating Systems",
    difficulty: "Medium",
    topic: "Inter-Process Communication",
    question: "Which Inter-Process Communication (IPC) mechanism offers the highest data transfer throughput and lowest latency?",
    options: ["Shared Memory", "Pipes", "Message Queues", "UNIX Domain Sockets"],
    correctAnswer: "Shared Memory",
    explanation: "Shared Memory maps the same physical memory segment into the address spaces of multiple processes. Once established, data transfer avoids expensive kernel context switches and copying.",
    points: 20
  },
  {
    id: "os-medium-007",
    category: "Operating Systems",
    difficulty: "Medium",
    topic: "Disk Scheduling",
    question: "How does the SCAN (Elevator) disk scheduling algorithm service disk requests?",
    options: [
      "The disk arm moves in one direction servicing all requests until reaching the end of the disk, then reverses direction",
      "It always services the cylinder closest to the current head position",
      "It services requests strictly in the order they arrive in the I/O queue",
      "It spins the disk platter faster when more requests are queued"
    ],
    correctAnswer: "The disk arm moves in one direction servicing all requests until reaching the end of the disk, then reverses direction",
    explanation: "Like a building elevator, SCAN travels continuously in one direction servicing requests along its path, turns around at the outer edge, and services requests going back.",
    points: 20
  },
  {
    id: "os-medium-008",
    category: "Operating Systems",
    difficulty: "Medium",
    topic: "Unix System Calls",
    question: "In POSIX systems, what does the fork() system call return to the parent and child processes respectively?",
    options: [
      "Returns the child's PID to the parent process, and 0 to the newly created child process",
      "Returns 0 to the parent, and 1 to the child",
      "Returns the parent's PID to both processes",
      "Returns -1 to the child and 0 to the parent"
    ],
    correctAnswer: "Returns the child's PID to the parent process, and 0 to the newly created child process",
    explanation: "fork() creates an identical child process. Upon successful creation, the return value is 0 inside the child process, and the child's unique positive PID inside the parent process.",
    points: 20
  },
  {
    id: "os-medium-009",
    category: "Operating Systems",
    difficulty: "Medium",
    topic: "Critical Section",
    question: "Which three requirements must every valid solution to the Critical Section problem satisfy?",
    options: [
      "Mutual Exclusion, Progress, and Bounded Waiting",
      "Atomicity, Consistency, and Durability",
      "Preemption, Circularity, and Starvation avoidance",
      "Fairness, Deadlock, and Real-time latency"
    ],
    correctAnswer: "Mutual Exclusion, Progress, and Bounded Waiting",
    explanation: "A valid critical section solution must ensure: 1) only one process enters at a time (Mutual Exclusion), 2) idle processes don't block others (Progress), and 3) no process waits indefinitely (Bounded Waiting).",
    points: 20
  },
  {
    id: "os-medium-010",
    category: "Operating Systems",
    difficulty: "Medium",
    topic: "Multithreading",
    question: "What is a primary drawback of User-Level Threads (ULT) over Kernel-Level Threads (KLT)?",
    options: [
      "If one user-level thread performs a blocking system call, the entire process and all its peer threads are blocked by the OS kernel",
      "Context switching user-level threads requires expensive kernel traps",
      "User-level threads require hardware virtualization support",
      "User threads cannot access thread-local storage"
    ],
    correctAnswer: "If one user-level thread performs a blocking system call, the entire process and all its peer threads are blocked by the OS kernel",
    explanation: "Because the OS kernel only sees the parent process (Many-to-One model), when a user-level thread executes a blocking system call, the kernel blocks the entire process schedule.",
    points: 20
  },
  {
    id: "os-hard-001",
    category: "Operating Systems",
    difficulty: "Hard",
    topic: "Virtual Memory & TLB",
    question: "In hardware memory management, what role does the Translation Lookaside Buffer (TLB) play, and what happens on a TLB Miss?",
    options: [
      "The TLB is a high-speed hardware associative cache for page table translations; on a miss, the MMU must walk the hierarchical page tables in main memory",
      "The TLB stores swap files on disk; on a miss, the OS shuts down",
      "The TLB caches CPU instructions; on a miss, it invalidates L1 cache",
      "The TLB stores process control blocks in hardware registers"
    ],
    correctAnswer: "The TLB is a high-speed hardware associative cache for page table translations; on a miss, the MMU must walk the hierarchical page tables in main memory",
    explanation: "A TLB caches recent virtual-to-physical address mappings. A TLB hit takes fractions of a nanosecond; a TLB miss forces a multi-step page table walk in RAM, significantly increasing memory access latency.",
    points: 30
  },
  {
    id: "os-hard-002",
    category: "Operating Systems",
    difficulty: "Hard",
    topic: "Synchronization",
    question: "Why might Peterson's Algorithm fail to guarantee mutual exclusion on modern multi-core superscalar processors without memory barriers?",
    options: [
      "Modern CPUs perform out-of-order execution and store buffering, reordering reads and writes to shared memory flags",
      "Modern registers are 64-bit instead of 16-bit",
      "Peterson's algorithm only supports an odd number of threads",
      "Compiler optimizations always convert boolean flags to integer counters"
    ],
    correctAnswer: "Modern CPUs perform out-of-order execution and store buffering, reordering reads and writes to shared memory flags",
    explanation: "Peterson's algorithm assumes sequential consistency. Modern processors reorder independent memory operations (such as store-load reordering), which breaks correctness unless explicit memory fence/barrier instructions are used.",
    points: 30
  },
  {
    id: "os-hard-003",
    category: "Operating Systems",
    difficulty: "Hard",
    topic: "Deadlocks",
    question: "When evaluating a Resource Allocation Graph (RAG), under what condition is the presence of a directed cycle NOT sufficient to prove a deadlock?",
    options: [
      "When resources in the graph have multiple instances each",
      "When the graph has more processes than resources",
      "When all processes are running with root privileges",
      "When the system operates under preemptive priority scheduling"
    ],
    correctAnswer: "When resources in the graph have multiple instances each",
    explanation: "If every resource type has exactly one instance, a cycle is necessary and sufficient for deadlock. With multiple instances per resource, a cycle is merely necessary, because other processes outside the cycle could release instances.",
    points: 30
  },
  {
    id: "os-hard-004",
    category: "Operating Systems",
    difficulty: "Hard",
    topic: "Memory Allocation",
    question: "How does the Buddy Memory Allocation algorithm manage block splitting and coalescing?",
    options: [
      "It divides memory into power-of-two block sizes; when a block is freed, it coalesces immediately with its adjacent 'buddy' block if that buddy is also free",
      "It maintains a sorted linked list of variable-size chunks and performs first-fit scans",
      "It allocates memory randomly and reorganizes pages during periodic garbage collection",
      "It swaps memory blocks between RAM and swap partition in alternate rounds"
    ],
    correctAnswer: "It divides memory into power-of-two block sizes; when a block is freed, it coalesces immediately with its adjacent 'buddy' block if that buddy is also free",
    explanation: "Buddy allocation recursively subdivides memory chunks into halves (powers of 2). Because buddies share identical prefix addresses differing only in a single bit, identifying and recombining them is extremely fast.",
    points: 30
  },
  {
    id: "os-hard-005",
    category: "Operating Systems",
    difficulty: "Hard",
    topic: "Kernel Internals",
    question: "Which of the following describes the state preserved in a Process Control Block (PCB) during a hardware context switch?",
    options: [
      "Program counter, CPU registers, stack pointer, memory limits/page tables, and open file descriptors",
      "The entire physical RAM contents occupied by the application",
      "The source code and compilation flags of the running program",
      "Only the thread ID and process name string"
    ],
    correctAnswer: "Program counter, CPU registers, stack pointer, memory limits/page tables, and open file descriptors",
    explanation: "A PCB encapsulates the entire execution context of a process so that when the scheduler swaps it back onto the CPU, it resumes exactly where it stopped without data corruption or loss of state.",
    points: 30
  }
];
