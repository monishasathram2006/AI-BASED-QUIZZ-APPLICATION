export const networksQuestions = [
  {
    id: "networks-easy-001",
    category: "Computer Networks",
    difficulty: "Easy",
    topic: "OSI Model",
    question: "How many layers are in the ISO Open Systems Interconnection (OSI) reference model?",
    options: ["7", "4", "5", "8"],
    correctAnswer: "7",
    explanation: "The OSI model consists of 7 layers: Physical, Data Link, Network, Transport, Session, Presentation, and Application.",
    points: 10
  },
  {
    id: "networks-easy-002",
    category: "Computer Networks",
    difficulty: "Easy",
    topic: "Transport Layer",
    question: "Which of the following is the defining difference between TCP and UDP?",
    options: [
      "TCP is connection-oriented and guarantees reliable in-order delivery; UDP is connectionless and does not guarantee delivery",
      "TCP is faster than UDP because it has no header bytes",
      "UDP requires a 3-way handshake prior to sending packets",
      "TCP only works over fiber optic cables"
    ],
    correctAnswer: "TCP is connection-oriented and guarantees reliable in-order delivery; UDP is connectionless and does not guarantee delivery",
    explanation: "TCP establishes a connection, provides sequence tracking, retransmission, and flow control. UDP sends datagrams without establishing a handshake or verifying receipt.",
    points: 10
  },
  {
    id: "networks-easy-003",
    category: "Computer Networks",
    difficulty: "Easy",
    topic: "IP Addressing",
    question: "How many bits are used in an IPv4 address?",
    options: ["32 bits", "64 bits", "128 bits", "16 bits"],
    correctAnswer: "32 bits",
    explanation: "An IPv4 address is 32 bits long, partitioned into 4 octets (8 bits each) written in dotted-decimal format (e.g., 192.168.1.1).",
    points: 10
  },
  {
    id: "networks-easy-004",
    category: "Computer Networks",
    difficulty: "Easy",
    topic: "Application Layer",
    question: "What are the standard default port numbers for HTTP and HTTPS traffic?",
    options: ["80 and 443", "21 and 22", "25 and 110", "8080 and 8443"],
    correctAnswer: "80 and 443",
    explanation: "Unencrypted web traffic (HTTP) defaults to port 80, while TLS-encrypted web traffic (HTTPS) defaults to port 443.",
    points: 10
  },
  {
    id: "networks-easy-005",
    category: "Computer Networks",
    difficulty: "Easy",
    topic: "DNS & Services",
    question: "What is the primary function of the Domain Name System (DNS)?",
    options: [
      "Translating human-readable domain names (like example.com) into numerical IP addresses",
      "Encrypting web page contents during transmission",
      "Assigning dynamic IP addresses to home routers via DHCP",
      "Filtering malicious DDoS traffic at data center edge routers"
    ],
    correctAnswer: "Translating human-readable domain names (like example.com) into numerical IP addresses",
    explanation: "DNS acts as the phonebook of the Internet, resolving domain names into the IP addresses required by network devices to locate each other.",
    points: 10
  },
  {
    id: "networks-easy-006",
    category: "Computer Networks",
    difficulty: "Easy",
    topic: "Data Link Layer",
    question: "What is the length of a standard Ethernet MAC (Media Access Control) address?",
    options: ["48 bits (6 bytes)", "32 bits (4 bytes)", "64 bits (8 bytes)", "128 bits (16 bytes)"],
    correctAnswer: "48 bits (6 bytes)",
    explanation: "A standard MAC address is 48 bits (6 octets) long, usually written in hexadecimal format (e.g. 00:1A:2B:3C:4D:5E).",
    points: 10
  },
  {
    id: "networks-easy-007",
    category: "Computer Networks",
    difficulty: "Easy",
    topic: "Network Devices",
    question: "How does a Network Switch differ from a legacy Network Hub?",
    options: [
      "A switch inspects MAC addresses and forwards frames only to the designated destination port, whereas a hub broadcasts incoming frames to all ports",
      "A switch works at the physical layer while a hub works at the transport layer",
      "A hub encrypts packet data while a switch does not",
      "A switch cannot connect more than two computers"
    ],
    correctAnswer: "A switch inspects MAC addresses and forwards frames only to the designated destination port, whereas a hub broadcasts incoming frames to all ports",
    explanation: "A switch maintains a CAM/MAC address table to unicast frames strictly to the matching port, preventing collision domains and reducing unnecessary network traffic.",
    points: 10
  },
  {
    id: "networks-easy-008",
    category: "Computer Networks",
    difficulty: "Easy",
    topic: "Protocols",
    question: "Which protocol is responsible for resolving a known IP address to its physical MAC address on a local area network?",
    options: ["ARP (Address Resolution Protocol)", "RARP", "DHCP", "ICMP"],
    correctAnswer: "ARP (Address Resolution Protocol)",
    explanation: "ARP broadcasts a query asking 'Who has this IP?', and the device owning that IP responds with its physical MAC address.",
    points: 10
  },
  {
    id: "networks-easy-009",
    category: "Computer Networks",
    difficulty: "Easy",
    topic: "Network Topologies",
    question: "In which network topology are all network devices connected directly to a single central device (such as a switch)?",
    options: ["Star topology", "Ring topology", "Bus topology", "Mesh topology"],
    correctAnswer: "Star topology",
    explanation: "In a Star topology, each workstation connects via a dedicated point-to-point link to a central hub or switch. If a single cable breaks, only that node goes down.",
    points: 10
  },
  {
    id: "networks-easy-010",
    category: "Computer Networks",
    difficulty: "Easy",
    topic: "Transport Layer",
    question: "What is the designated numeric range for standard IANA 'Well-Known Ports'?",
    options: ["0 to 1023", "1024 to 49151", "49152 to 65535", "1 to 256"],
    correctAnswer: "0 to 1023",
    explanation: "Well-Known Ports range from 0 to 1023 (reserved for system and ubiquitous protocols like HTTP, SSH, FTP). Registered ports run from 1024 to 49151, and dynamic/private ports run from 49152 to 65535.",
    points: 10
  },
  {
    id: "networks-medium-001",
    category: "Computer Networks",
    difficulty: "Medium",
    topic: "Transport Layer",
    question: "What is the exact sequence of flag exchanges in the standard TCP 3-Way Handshake?",
    options: [
      "SYN -> SYN-ACK -> ACK",
      "ACK -> SYN -> SYN-ACK",
      "SYN -> ACK -> DATA",
      "FIN -> FIN-ACK -> ACK"
    ],
    correctAnswer: "SYN -> SYN-ACK -> ACK",
    explanation: "The client initiates with a SYN segment; the server replies with a SYN-ACK; and the client completes connection establishment by transmitting an ACK.",
    points: 20
  },
  {
    id: "networks-medium-002",
    category: "Computer Networks",
    difficulty: "Medium",
    topic: "Subnetting",
    question: "In a Classless Inter-Domain Routing (CIDR) subnet with prefix /24, how many usable host IP addresses are available?",
    options: ["254", "256", "255", "128"],
    correctAnswer: "254",
    explanation: "A /24 subnet has 32 - 24 = 8 host bits, yielding 2^8 = 256 total IP addresses. Subtracting 2 (one for the Network ID and one for the Broadcast Address) leaves 254 assignable host addresses.",
    points: 20
  },
  {
    id: "networks-medium-003",
    category: "Computer Networks",
    difficulty: "Medium",
    topic: "Flow Control",
    question: "How does TCP's Sliding Window mechanism implement Flow Control between sender and receiver?",
    options: [
      "The receiver advertises a receive window (rwnd) indicating available buffer space, preventing the sender from overflowing the receiver's memory",
      "The sender doubles packet transmission speed every round trip",
      "The router drops every third packet to signal congestion",
      "Both nodes exchange cryptographic keys to limit transmission"
    ],
    correctAnswer: "The receiver advertises a receive window (rwnd) indicating available buffer space, preventing the sender from overflowing the receiver's memory",
    explanation: "Flow control prevents a fast sender from overwhelming a slow receiver. The receiver specifies its free buffer capacity in the TCP header's Window field, dynamically throttling the sender's unacknowledged bytes.",
    points: 20
  },
  {
    id: "networks-medium-004",
    category: "Computer Networks",
    difficulty: "Medium",
    topic: "Routing",
    question: "Which shortest-path algorithm is used by Link-State routing protocols like OSPF (Open Shortest Path First)?",
    options: [
      "Dijkstra's Algorithm",
      "Bellman-Ford Algorithm",
      "Floyd-Warshall Algorithm",
      "Prim's Algorithm"
    ],
    correctAnswer: "Dijkstra's Algorithm",
    explanation: "OSPF routers flood link-state advertisements (LSAs) so every router builds an identical topology map, then each router runs Dijkstra's algorithm to compute the shortest-path tree to all destinations.",
    points: 20
  },
  {
    id: "networks-medium-005",
    category: "Computer Networks",
    difficulty: "Medium",
    topic: "Congestion Control",
    question: "In TCP Reno congestion control, what triggers the transition from 'Slow Start' to 'Congestion Avoidance'?",
    options: [
      "The congestion window (cwnd) reaches or exceeds the slow start threshold (ssthresh)",
      "The receiver sends a zero-window probe",
      "The network round-trip time drops below 1 millisecond",
      "The client sends a FIN segment"
    ],
    correctAnswer: "The congestion window (cwnd) reaches or exceeds the slow start threshold (ssthresh)",
    explanation: "During Slow Start, cwnd increases exponentially (doubling each RTT). Once cwnd >= ssthresh, TCP switches to Congestion Avoidance, growing linearly (adding 1 MSS per RTT) to probe bandwidth gently.",
    points: 20
  },
  {
    id: "networks-medium-006",
    category: "Computer Networks",
    difficulty: "Medium",
    topic: "HTTP Status Codes",
    question: "Which HTTP status code signifies that the client must authenticate, but the provided credentials do not have permission to access the requested resource?",
    options: ["403 Forbidden", "401 Unauthorized", "404 Not Found", "502 Bad Gateway"],
    correctAnswer: "403 Forbidden",
    explanation: "401 indicates authentication is missing or invalid. 403 Forbidden indicates the server understands who the user is, but the authenticated identity lacks permissions for the requested resource.",
    points: 20
  },
  {
    id: "networks-medium-007",
    category: "Computer Networks",
    difficulty: "Medium",
    topic: "Network Layer",
    question: "What protocol powers common diagnostic utilities like 'ping' and 'traceroute'?",
    options: [
      "ICMP (Internet Control Message Protocol)",
      "IGMP (Internet Group Management Protocol)",
      "SNMP (Simple Network Management Protocol)",
      "BGP (Border Gateway Protocol)"
    ],
    correctAnswer: "ICMP (Internet Control Message Protocol)",
    explanation: "ICMP provides network diagnostics and operational feedback. Ping uses ICMP Echo Request and Echo Reply messages; traceroute uses UDP/ICMP with incrementing TTL values causing ICMP Time Exceeded replies.",
    points: 20
  },
  {
    id: "networks-medium-008",
    category: "Computer Networks",
    difficulty: "Medium",
    topic: "NAT & Routing",
    question: "What is PAT (Port Address Translation / NAT Overload)?",
    options: [
      "A technique that maps multiple private IP addresses to a single public IP address using distinct source TCP/UDP port numbers",
      "A protocol to assign permanent static IP addresses to web servers",
      "A method of splitting fiber optic wavelengths for faster bandwidth",
      "An algorithm that balances database queries across replicas"
    ],
    correctAnswer: "A technique that maps multiple private IP addresses to a single public IP address using distinct source TCP/UDP port numbers",
    explanation: "PAT allows hundreds of internal LAN devices with private IP addresses (RFC 1918) to share a single public IPv4 address simultaneously by tracking sessions via unique source port numbers.",
    points: 20
  },
  {
    id: "networks-medium-009",
    category: "Computer Networks",
    difficulty: "Medium",
    topic: "Network Security",
    question: "How do asymmetric and symmetric encryption cooperate during a modern TLS/HTTPS connection?",
    options: [
      "Asymmetric encryption securely authenticates the server and exchanges a shared symmetric session key; symmetric encryption encrypts the actual ongoing payload data",
      "Asymmetric encryption encrypts all data while symmetric encryption generates domain certificates",
      "Symmetric encryption is used for headers and asymmetric for body text",
      "They are never used in the same session"
    ],
    correctAnswer: "Asymmetric encryption securely authenticates the server and exchanges a shared symmetric session key; symmetric encryption encrypts the actual ongoing payload data",
    explanation: "Asymmetric cryptography (RSA/ECDH) is computationally heavy and used only during the handshake to exchange secrets; fast symmetric cryptography (AES/ChaCha20) then handles high-speed bulk data encryption.",
    points: 20
  },
  {
    id: "networks-medium-010",
    category: "Computer Networks",
    difficulty: "Medium",
    topic: "Data Link Layer",
    question: "What does a station do when a collision is detected in CSMA/CD Ethernet networks?",
    options: [
      "Transmits a jamming signal, stops transmission, and waits for a randomized backoff period using the Binary Exponential Backoff algorithm",
      "Increases signal power to override the conflicting frame",
      "Switches to a backup token ring protocol immediately",
      "Discards all packets in the operating system buffer"
    ],
    correctAnswer: "Transmits a jamming signal, stops transmission, and waits for a randomized backoff period using the Binary Exponential Backoff algorithm",
    explanation: "Upon detecting a collision, CSMA/CD sends a 32-bit jam signal to notify all stations, aborts the transmission, and enters binary exponential backoff to reduce odds of colliding again.",
    points: 20
  },
  {
    id: "networks-hard-001",
    category: "Computer Networks",
    difficulty: "Hard",
    topic: "TCP Mechanics",
    question: "Why must a TCP endpoint that initiates active connection teardown stay in the TIME_WAIT state for 2 * MSL (Maximum Segment Lifetime)?",
    options: [
      "To ensure the final ACK is received by the remote peer (and retransmit if lost), and to allow delayed or duplicated segments from the old connection to expire in the network",
      "To flush CPU cache registers before the next connection",
      "To renegotiate TLS certificates for subsequent handshakes",
      "To prevent operating system port starvation during shutdown"
    ],
    correctAnswer: "To ensure the final ACK is received by the remote peer (and retransmit if lost), and to allow delayed or duplicated segments from the old connection to expire in the network",
    explanation: "If the final ACK is lost, the peer retransmits FIN; the TIME_WAIT node must be alive to ACK it. Furthermore, lingering packets from the closed incarnation must drain before port reuse.",
    points: 30
  },
  {
    id: "networks-hard-002",
    category: "Computer Networks",
    difficulty: "Hard",
    topic: "Inter-Domain Routing",
    question: "Which protocol is the de facto exterior gateway routing protocol that connects different Autonomous Systems (AS) across the global Internet?",
    options: [
      "BGP (Border Gateway Protocol)",
      "OSPF (Open Shortest Path First)",
      "IS-IS (Intermediate System to Intermediate System)",
      "RIP (Routing Information Protocol)"
    ],
    correctAnswer: "BGP (Border Gateway Protocol)",
    explanation: "BGP is a path-vector protocol that manages routing decisions between independent Autonomous Systems (ASes) globally, exchanging network reachability through AS-Path attributes.",
    points: 30
  },
  {
    id: "networks-hard-003",
    category: "Computer Networks",
    difficulty: "Hard",
    topic: "TLS Protocol",
    question: "What major performance improvement was introduced in the TLS 1.3 handshake compared to TLS 1.2?",
    options: [
      "Reducing the handshake latency from 2 round trips (2-RTT) down to 1 round trip (1-RTT), with optional 0-RTT session resumption",
      "Removing all symmetric encryption cipher suites",
      "Eliminating the need for certificate validation authorities",
      "Transmitting web responses over raw UDP without acknowledgments"
    ],
    correctAnswer: "Reducing the handshake latency from 2 round trips (2-RTT) down to 1 round trip (1-RTT), with optional 0-RTT session resumption",
    explanation: "TLS 1.3 embeds Diffie-Hellman key shares directly inside the ClientHello message, shaving off an entire network round-trip, significantly accelerating secure HTTPS handshakes.",
    points: 30
  },
  {
    id: "networks-hard-004",
    category: "Computer Networks",
    difficulty: "Hard",
    topic: "IPv6 Architecture",
    question: "How does IPv6 eliminate the need for broadcast addresses and the legacy Address Resolution Protocol (ARP)?",
    options: [
      "By using ICMPv6 Neighbor Discovery Protocol (NDP) over link-local multicast addressing",
      "By assigning every device a fixed global MAC address directly in the DNS root servers",
      "By routing all local traffic through a default gateway",
      "By broadcasting frames on dedicated fiber channels"
    ],
    correctAnswer: "By using ICMPv6 Neighbor Discovery Protocol (NDP) over link-local multicast addressing",
    explanation: "IPv6 replaces broadcast with efficient multicast. The Neighbor Discovery Protocol (NDP) uses ICMPv6 Neighbor Solicitation and Neighbor Advertisement messages sent to solicited-node multicast addresses.",
    points: 30
  },
  {
    id: "networks-hard-005",
    category: "Computer Networks",
    difficulty: "Hard",
    topic: "Congestion & Queuing",
    question: "What phenomenon describes 'Bufferbloat' in network routers, and how do Active Queue Management (AQM) algorithms address it?",
    options: [
      "Excessively oversized network buffers causing persistent high queuing latency without reducing packet loss; addressed by deliberately dropping or marking packets early (e.g. CoDel or RED)",
      "Memory leaks in network card drivers causing system crashes",
      "TCP congestion windows growing larger than physical RAM capacity",
      "Routers caching DNS requests indefinitely"
    ],
    correctAnswer: "Excessively oversized network buffers causing persistent high queuing latency without reducing packet loss; addressed by deliberately dropping or marking packets early (e.g. CoDel or RED)",
    explanation: "Bufferbloat happens when large unmanaged router buffers fill up, holding packets for seconds without signaling congestion. AQM algorithms (like CoDel) drop or ECN-mark packets before buffers fill up to prompt TCP backoff.",
    points: 30
  }
];
