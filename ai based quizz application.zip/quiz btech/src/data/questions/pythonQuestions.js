export const pythonQuestions = [
  {
    id: "python-easy-001",
    category: "Python",
    difficulty: "Easy",
    topic: "Python basics",
    question: "Which of the following best describes Python as a programming language?",
    options: [
      "A compiled, statically-typed language",
      "An interpreted, dynamically-typed language",
      "A markup language for web pages",
      "A low-level assembly language"
    ],
    correctAnswer: "An interpreted, dynamically-typed language",
    explanation: "Python code is executed by an interpreter (CPython by default), and variable types are determined at runtime rather than declared explicitly, making Python dynamically typed.",
    points: 10
  },
  {
    id: "python-easy-002",
    category: "Python",
    difficulty: "Easy",
    topic: "Variables and data types",
    question: "What is the output of the following code?",
    code: 'x = 5\nx = "hello"\nprint(type(x))',
    language: "python",
    options: [
      "<class 'int'>",
      "<class 'str'>",
      "Error: cannot reassign variable to a different type",
      "<class 'NoneType'>"
    ],
    correctAnswer: "<class 'str'>",
    explanation: "Python is dynamically typed, so a variable can be reassigned to a value of a different type; type(x) reflects the most recently assigned value, the string \"hello\".",
    points: 10
  },
  {
    id: "python-easy-003",
    category: "Python",
    difficulty: "Easy",
    topic: "Operators",
    question: "What is the result of the expression 17 // 4 in Python?",
    options: ["4.25", "4", "5", "1"],
    correctAnswer: "4",
    explanation: "The // operator performs floor division, discarding the remainder. 17 / 4 is 4.25, which floors down to 4.",
    points: 10
  },
  {
    id: "python-easy-004",
    category: "Python",
    difficulty: "Easy",
    topic: "Conditional statements",
    question: "Which keyword does Python use to check an additional condition after an 'if' fails, before falling back to 'else'?",
    options: ["elseif", "elif", "else if", "elseiif"],
    correctAnswer: "elif",
    explanation: "Python uses 'elif', a contraction of 'else if', to chain multiple conditional checks. 'elseif' and 'else if' are not valid Python syntax.",
    points: 10
  },
  {
    id: "python-easy-005",
    category: "Python",
    difficulty: "Easy",
    topic: "Loops",
    question: "What is the output of the following code?",
    code: 'for i in range(2, 8, 2):\n    print(i, end=" ")',
    language: "python",
    options: ["2 4 6 ", "2 4 6 8 ", "2 3 4 5 6 7 ", "0 2 4 6 "],
    correctAnswer: "2 4 6 ",
    explanation: "range(2, 8, 2) starts at 2, stops before 8, and steps by 2, producing 2, 4, and 6.",
    points: 10
  },
  {
    id: "python-easy-006",
    category: "Python",
    difficulty: "Easy",
    topic: "Functions",
    question: "What is the output of the following code?",
    code: 'def greet(name="World"):\n    return "Hello, " + name\n\nprint(greet())',
    language: "python",
    options: [
      "Hello, World",
      "Hello, name",
      "Error: missing required argument",
      "Hello, "
    ],
    correctAnswer: "Hello, World",
    explanation: "The parameter 'name' has a default value of \"World\", so calling greet() without arguments uses that default, producing \"Hello, World\".",
    points: 10
  },
  {
    id: "python-easy-007",
    category: "Python",
    difficulty: "Easy",
    topic: "Lists",
    question: "What is the output of the following code?",
    code: "numbers = [1, 2, 3]\nnumbers.append(4)\nprint(numbers)",
    language: "python",
    options: [
      "[1, 2, 3, 4]",
      "[1, 2, 3, [4]]",
      "[4, 1, 2, 3]",
      "Error: lists are immutable"
    ],
    correctAnswer: "[1, 2, 3, 4]",
    explanation: "append() adds a single element to the end of a list in place. Lists are mutable in Python, so this works without error.",
    points: 10
  },
  {
    id: "python-easy-008",
    category: "Python",
    difficulty: "Easy",
    topic: "Tuples",
    question: "Which statement about Python tuples is correct?",
    options: [
      "Tuples are mutable and can be modified after creation",
      "Tuples are immutable and cannot be modified after creation",
      "Tuples can only store integers",
      "Tuples do not support indexing"
    ],
    correctAnswer: "Tuples are immutable and cannot be modified after creation",
    explanation: "Once created, a tuple's elements cannot be changed, added, or removed. This immutability makes tuples hashable and usable as dictionary keys, unlike lists.",
    points: 10
  },
  {
    id: "python-easy-009",
    category: "Python",
    difficulty: "Easy",
    topic: "Dictionaries",
    question: "What is the output of the following code?",
    code: 'student = {"name": "Amit", "age": 21}\nprint(student["age"])',
    language: "python",
    options: ["21", "'age'", "KeyError", "name"],
    correctAnswer: "21",
    explanation: "Accessing a dictionary with square-bracket notation and an existing key returns the value associated with that key, here 21.",
    points: 10
  },
  {
    id: "python-easy-010",
    category: "Python",
    difficulty: "Easy",
    topic: "Strings",
    question: "What is the output of the following code?",
    code: 'text = "Python"\nprint(text[1:4])',
    language: "python",
    options: ["yth", "Pyt", "ytho", "Python"],
    correctAnswer: "yth",
    explanation: "Slicing text[1:4] returns characters from index 1 up to but not including index 4: 'y', 't', 'h', giving \"yth\".",
    points: 10
  },
  {
    id: "python-medium-001",
    category: "Python",
    difficulty: "Medium",
    topic: "List comprehension",
    question: "What is the output of the following code?",
    code: "squares = [x**2 for x in range(5) if x % 2 == 0]\nprint(squares)",
    language: "python",
    options: ["[0, 4, 16]", "[0, 1, 4, 9, 16]", "[1, 9]", "[0, 2, 4]"],
    correctAnswer: "[0, 4, 16]",
    explanation: "The comprehension iterates x over 0-4, keeps only even values (0, 2, 4) because of the if condition, and squares them, giving [0, 4, 16].",
    points: 20
  },
  {
    id: "python-medium-002",
    category: "Python",
    difficulty: "Medium",
    topic: "Sets",
    question: "What is the output of the following code?",
    code: "a = {1, 2, 3, 4}\nb = {3, 4, 5, 6}\nprint(a & b)",
    language: "python",
    options: ["{3, 4}", "{1, 2, 5, 6}", "{1, 2, 3, 4, 5, 6}", "{1, 2}"],
    correctAnswer: "{3, 4}",
    explanation: "The & operator performs set intersection, returning only the elements common to both sets, which are 3 and 4.",
    points: 20
  },
  {
    id: "python-medium-003",
    category: "Python",
    difficulty: "Medium",
    topic: "Exception handling",
    question: "What is the output of the following code?",
    code: 'try:\n    result = 10 / 0\nexcept ZeroDivisionError:\n    print("Error caught")\nfinally:\n    print("Done")',
    language: "python",
    options: [
      "Error caught\nDone",
      "Done",
      "Error caught",
      "ZeroDivisionError: division by zero"
    ],
    correctAnswer: "Error caught\nDone",
    explanation: "The ZeroDivisionError raised by 10 / 0 is caught by the except block, printing \"Error caught\", and the finally block always executes afterward, printing \"Done\".",
    points: 20
  },
  {
    id: "python-medium-004",
    category: "Python",
    difficulty: "Medium",
    topic: "OOP",
    question: "What is the output of the following code?",
    code: "class Counter:\n    count = 0\n\n    def __init__(self):\n        Counter.count += 1\n\na = Counter()\nb = Counter()\nc = Counter()\nprint(Counter.count)",
    language: "python",
    options: ["3", "0", "1", "Error: count is not defined"],
    correctAnswer: "3",
    explanation: "'count' is a class variable shared by all instances. Each call to __init__ increments Counter.count, so after creating three instances it equals 3.",
    points: 20
  },
  {
    id: "python-medium-005",
    category: "Python",
    difficulty: "Medium",
    topic: "Inheritance",
    question: "What is the output of the following code?",
    code: 'class Animal:\n    def speak(self):\n        return "Some sound"\n\nclass Dog(Animal):\n    def speak(self):\n        base = super().speak()\n        return base + " -> Bark"\n\nprint(Dog().speak())',
    language: "python",
    options: [
      "Some sound -> Bark",
      "Bark",
      "Some sound",
      "Error: super() requires arguments"
    ],
    correctAnswer: "Some sound -> Bark",
    explanation: "super().speak() calls the parent class's speak() method to get \"Some sound\", and Dog's overridden method appends \" -> Bark\" to it.",
    points: 20
  },
  {
    id: "python-medium-006",
    category: "Python",
    difficulty: "Medium",
    topic: "Lists",
    question: "Which of the following is a key difference between a Python list and a Python tuple?",
    options: [
      "Lists are immutable while tuples are mutable",
      "Lists are defined with () while tuples are defined with []",
      "Lists are mutable while tuples are immutable",
      "Tuples can store multiple data types but lists cannot"
    ],
    correctAnswer: "Lists are mutable while tuples are immutable",
    explanation: "Lists support in-place modification such as adding, removing, or changing elements, while tuples cannot be changed after creation. Both can store mixed data types.",
    points: 20
  },
  {
    id: "python-medium-007",
    category: "Python",
    difficulty: "Medium",
    topic: "Operators",
    question: "What is the output of the following code?",
    code: "a = [1, 2, 3]\nb = [1, 2, 3]\nprint(a == b, a is b)",
    language: "python",
    options: ["True False", "True True", "False True", "False False"],
    correctAnswer: "True False",
    explanation: "== compares values, and both lists contain equal elements, so a == b is True. 'is' checks object identity, and a and b are distinct list objects in memory, so a is b is False.",
    points: 20
  },
  {
    id: "python-medium-008",
    category: "Python",
    difficulty: "Medium",
    topic: "Lambda functions",
    question: "What is the output of the following code?",
    code: "nums = [1, 2, 3, 4, 5]\nresult = list(filter(lambda x: x % 2 == 0, nums))\nprint(result)",
    language: "python",
    options: [
      "[2, 4]",
      "[1, 3, 5]",
      "[1, 2, 3, 4, 5]",
      "[True, False, True, False, True]"
    ],
    correctAnswer: "[2, 4]",
    explanation: "filter() keeps only elements for which the lambda returns True. Here it keeps even numbers, so only 2 and 4 remain after being collected into a list.",
    points: 20
  },
  {
    id: "python-medium-009",
    category: "Python",
    difficulty: "Medium",
    topic: "Dictionaries",
    question: "What happens when the following code runs?",
    code: 'data = {"a": 1, "b": 2}\nprint(data.get("c", 0))\nprint(data["c"])',
    language: "python",
    options: [
      "It prints 0, then raises a KeyError",
      "It prints 0, then prints None",
      "It raises a KeyError immediately on the first line",
      "It prints 0, then prints 0 again"
    ],
    correctAnswer: "It prints 0, then raises a KeyError",
    explanation: "dict.get(\"c\", 0) safely returns the default value 0 since key \"c\" is missing, but direct bracket access data[\"c\"] raises a KeyError when the key does not exist.",
    points: 20
  },
  {
    id: "python-medium-010",
    category: "Python",
    difficulty: "Medium",
    topic: "File handling",
    question: "What is the main advantage of using 'with open(...) as f:' instead of manually calling open() and close()?",
    options: [
      "It makes file reading faster by using less memory",
      "It automatically closes the file even if an exception occurs inside the block",
      "It allows opening multiple files with a single call",
      "It converts the file content to a string automatically"
    ],
    correctAnswer: "It automatically closes the file even if an exception occurs inside the block",
    explanation: "The 'with' statement uses a context manager whose __exit__ method closes the file automatically, even if an error occurs inside the block, preventing resource leaks.",
    points: 20
  },
  {
    id: "python-hard-001",
    category: "Python",
    difficulty: "Hard",
    topic: "Functions",
    question: "What is the output of the following code?",
    code: 'def add_item(item, items=[]):\n    items.append(item)\n    return items\n\nprint(add_item("a"))\nprint(add_item("b"))',
    language: "python",
    options: [
      "['a']\n['b']",
      "['a']\n['a', 'b']",
      "['a', 'b']\n['a', 'b']",
      "Error: mutable default arguments are not allowed"
    ],
    correctAnswer: "['a']\n['a', 'b']",
    explanation: "Default argument values are evaluated once when the function is defined, not on each call, so the same list object persists across calls. The second call appends 'b' to the list that already contains 'a' from the first call, a classic mutable-default-argument pitfall.",
    points: 30
  },
  {
    id: "python-hard-002",
    category: "Python",
    difficulty: "Hard",
    topic: "Decorators",
    question: "What is the output of the following code?",
    code: 'def decorator(func):\n    def wrapper(*args, **kwargs):\n        print("Before")\n        result = func(*args, **kwargs)\n        print("After")\n        return result\n    return wrapper\n\n@decorator\ndef add(a, b):\n    return a + b\n\nprint(add(2, 3))',
    language: "python",
    options: [
      "Before\nAfter\n5",
      "5\nBefore\nAfter",
      "Before\n5\nAfter",
      "Before\nAfter"
    ],
    correctAnswer: "Before\nAfter\n5",
    explanation: "Calling add(2, 3) invokes wrapper, which prints \"Before\", computes the result via the original function, prints \"After\", and returns 5. Only then does the outer print() output 5, giving the order Before, After, 5.",
    points: 30
  },
  {
    id: "python-hard-003",
    category: "Python",
    difficulty: "Hard",
    topic: "Iterators and generators",
    question: "What is the output of the following code?",
    code: 'def gen():\n    print("start")\n    yield 1\n    print("middle")\n    yield 2\n    print("end")\n\ng = gen()\nprint("created")\nprint(next(g))\nprint(next(g))',
    language: "python",
    options: [
      "created\nstart\n1\nmiddle\n2",
      "start\ncreated\n1\nmiddle\n2",
      "created\nstart\n1\nmiddle\n2\nend",
      "start\nmiddle\nend\ncreated\n1\n2"
    ],
    correctAnswer: "created\nstart\n1\nmiddle\n2",
    explanation: "Calling gen() only creates a generator object without running any code inside it; execution begins only when next() is first called, running up to the first yield (\"start\", then yields 1). The second next() resumes right after that yield and runs until the next yield (\"middle\", then yields 2); \"end\" never prints since no third next() call is made.",
    points: 30
  },
  {
    id: "python-hard-004",
    category: "Python",
    difficulty: "Hard",
    topic: "Inheritance",
    question: "What is the output of the following code, and why?",
    code: 'class A:\n    def greet(self):\n        return "A"\n\nclass B(A):\n    def greet(self):\n        return "B"\n\nclass C(A):\n    def greet(self):\n        return "C"\n\nclass D(B, C):\n    pass\n\nprint(D().greet())',
    language: "python",
    options: [
      "A, because D inherits directly from A",
      "B, because Python's MRO (C3 linearization) checks B before C",
      "C, because C is defined closer to A",
      "Error: ambiguous method resolution between B and C"
    ],
    correctAnswer: "B, because Python's MRO (C3 linearization) checks B before C",
    explanation: "Python resolves method calls using C3 linearization, producing the order D -> B -> C -> A -> object for this diamond hierarchy. Since D itself doesn't define greet(), the search proceeds to B first, so B's greet() is used before C's or A's.",
    points: 30
  },
  {
    id: "python-hard-005",
    category: "Python",
    difficulty: "Hard",
    topic: "Python interview problems",
    question: "In CPython, what is the average time complexity of checking whether an element exists in a list versus in a set?",
    options: [
      "O(1) for both list and set",
      "O(n) for a list, O(1) average for a set",
      "O(log n) for a list, O(n) for a set",
      "O(n) for both list and set"
    ],
    correctAnswer: "O(n) for a list, O(1) average for a set",
    explanation: "Checking membership in a list requires scanning elements one by one in the worst case, giving O(n) time, while sets are implemented as hash tables, giving average O(1) membership checks. This distinction is a common consideration when optimizing lookup-heavy code in interviews.",
    points: 30
  }
];
