export const javaQuestions = [
  // ==================== EASY (10) ====================
  {
    id: "java-easy-001",
    category: "Java Development",
    difficulty: "Easy",
    topic: "JVM",
    question: "What is the primary role of the JVM (Java Virtual Machine)?",
    options: [
      "It compiles Java source code directly into machine code ahead of time",
      "It executes Java bytecode and provides platform independence by abstracting the underlying OS",
      "It is a text editor used to write Java programs",
      "It converts machine code into Java bytecode for debugging"
    ],
    correctAnswer: "It executes Java bytecode and provides platform independence by abstracting the underlying OS",
    explanation: "The JVM interprets/JIT-compiles platform-independent bytecode into native instructions for the host machine, which is the basis of Java's \"write once, run anywhere\" promise. Interviewers frequently check this to gauge understanding of Java's execution model.",
    points: 10
  },
  {
    id: "java-easy-002",
    category: "Java Development",
    difficulty: "Easy",
    topic: "JDK",
    question: "Which of the following best describes the relationship between JDK, JRE, and JVM?",
    options: [
      "JVM contains JRE, which contains JDK",
      "JDK contains JRE, which contains JVM",
      "JRE contains JDK, which contains JVM",
      "All three are identical and interchangeable terms"
    ],
    correctAnswer: "JDK contains JRE, which contains JVM",
    explanation: "The JDK (Java Development Kit) includes development tools plus the JRE (Java Runtime Environment), and the JRE in turn includes the JVM along with core libraries needed to run applications. Knowing this hierarchy is a common first screening question.",
    points: 10
  },
  {
    id: "java-easy-003",
    category: "Java Development",
    difficulty: "Easy",
    topic: "Data types",
    question: "Which of the following is NOT a primitive data type in Java?",
    options: [
      "int",
      "boolean",
      "String",
      "char"
    ],
    correctAnswer: "String",
    explanation: "String is a class (a reference type) in Java, not a primitive type, whereas int, boolean, and char are among the eight built-in primitives. This distinction matters because primitives store values directly while String objects are stored on the heap and are immutable.",
    points: 10
  },
  {
    id: "java-easy-004",
    category: "Java Development",
    difficulty: "Easy",
    topic: "Operators",
    question: "What will the following code print?",
    code: "int x = 5;\nSystem.out.println(x++);\nSystem.out.println(x);",
    language: "java",
    options: [
      "5 followed by 6",
      "6 followed by 6",
      "6 followed by 5",
      "5 followed by 5"
    ],
    correctAnswer: "5 followed by 6",
    explanation: "The post-increment operator x++ returns the current value of x (5) before incrementing it, so the first println prints 5 and x becomes 6, which the second println prints. Confusing pre- and post-increment is a classic interview trap.",
    points: 10
  },
  {
    id: "java-easy-005",
    category: "Java Development",
    difficulty: "Easy",
    topic: "Control flow",
    question: "Which keyword is used to exit a loop immediately in Java, skipping any remaining iterations?",
    options: [
      "continue",
      "break",
      "return",
      "exit"
    ],
    correctAnswer: "break",
    explanation: "The break statement immediately terminates the nearest enclosing loop or switch statement, while continue only skips to the next iteration. This basic control-flow distinction is essential for writing correct loops.",
    points: 10
  },
  {
    id: "java-easy-006",
    category: "Java Development",
    difficulty: "Easy",
    topic: "Arrays",
    question: "What is the default value of elements in a newly created int array in Java, e.g. new int[5]?",
    options: [
      "null",
      "undefined",
      "0",
      "Garbage value, same as in C"
    ],
    correctAnswer: "0",
    explanation: "Java always initializes numeric array elements to 0 (or 0.0 for floating types), boolean to false, and object reference arrays to null, unlike C where array contents can be garbage. This guarantees predictable behavior for uninitialized arrays.",
    points: 10
  },
  {
    id: "java-easy-007",
    category: "Java Development",
    difficulty: "Easy",
    topic: "Classes and objects",
    question: "What is the purpose of a constructor in a Java class?",
    options: [
      "To destroy an object when it is no longer needed",
      "To initialize the state of a newly created object",
      "To define static utility methods only",
      "To compile the class into bytecode"
    ],
    correctAnswer: "To initialize the state of a newly created object",
    explanation: "A constructor is a special method invoked automatically when an object is instantiated with new, and its main job is to set up the initial state (field values) of that object. Java has no destructors; cleanup is instead handled by garbage collection.",
    points: 10
  },
  {
    id: "java-easy-008",
    category: "Java Development",
    difficulty: "Easy",
    topic: "Strings",
    question: "Why are String objects in Java described as immutable?",
    options: [
      "Because String variables cannot be reassigned to point to a different String object",
      "Because once a String object is created, its internal character sequence cannot be changed",
      "Because Strings can only be created at compile time",
      "Because String methods like concat() modify the original object in place"
    ],
    correctAnswer: "Because once a String object is created, its internal character sequence cannot be changed",
    explanation: "Any operation that appears to modify a String, such as concat() or replace(), actually returns a brand-new String object rather than altering the original. This immutability enables safe String pooling and thread-safety, which is why interviewers ask about it often.",
    points: 10
  },
  {
    id: "java-easy-009",
    category: "Java Development",
    difficulty: "Easy",
    topic: "Encapsulation",
    question: "Which of the following best describes encapsulation in object-oriented programming?",
    options: [
      "The ability of a class to inherit fields and methods from another class",
      "Bundling data and the methods that operate on it together while restricting direct access to internal state",
      "The ability of an object to take many forms",
      "Defining a method with the same name but different parameters in the same class"
    ],
    correctAnswer: "Bundling data and the methods that operate on it together while restricting direct access to internal state",
    explanation: "Encapsulation is typically implemented in Java using private fields with public getter/setter methods, protecting an object's internal state from unintended external modification. It is one of the four foundational OOP pillars along with inheritance, polymorphism, and abstraction.",
    points: 10
  },
  {
    id: "java-easy-010",
    category: "Java Development",
    difficulty: "Easy",
    topic: "Methods",
    question: "What does it mean to \"overload\" a method in Java?",
    options: [
      "Defining multiple methods in the same class with the same name but different parameter lists",
      "Redefining a superclass method in a subclass with the exact same signature",
      "Calling a method recursively many times",
      "Making a method run on multiple threads at once"
    ],
    correctAnswer: "Defining multiple methods in the same class with the same name but different parameter lists",
    explanation: "Method overloading is resolved at compile time based on the number, type, or order of arguments, and is a form of compile-time (static) polymorphism. It is distinct from overriding, which happens between a superclass and subclass with an identical signature.",
    points: 10
  },

  // ==================== MEDIUM (10) ====================
  {
    id: "java-medium-001",
    category: "Java Development",
    difficulty: "Medium",
    topic: "Strings",
    question: "What will the following code print?",
    code: "String a = \"hello\";\nString b = \"hello\";\nString c = new String(\"hello\");\nSystem.out.println(a == b);\nSystem.out.println(a == c);\nSystem.out.println(a.equals(c));",
    language: "java",
    options: [
      "true, true, true",
      "true, false, true",
      "false, false, true",
      "true, false, false"
    ],
    correctAnswer: "true, false, true",
    explanation: "String literals \"hello\" are interned in the String pool, so a and b reference the same pooled object and a == b is true. new String(\"hello\") explicitly creates a separate object on the heap, so a == c is false, but equals() compares content, so a.equals(c) is true. This tests understanding of the String pool versus the equals contract.",
    points: 20
  },
  {
    id: "java-medium-002",
    category: "Java Development",
    difficulty: "Medium",
    topic: "Interfaces",
    question: "Which statement correctly distinguishes an interface from an abstract class in modern Java (8+)?",
    options: [
      "A class can implement only one interface but can extend multiple abstract classes",
      "An abstract class can have constructors and instance fields with state, while an interface cannot have instance fields (only constants) or constructors",
      "Interfaces cannot have any method bodies at all, even with default methods",
      "Abstract classes support multiple inheritance of implementation exactly like interfaces"
    ],
    correctAnswer: "An abstract class can have constructors and instance fields with state, while an interface cannot have instance fields (only constants) or constructors",
    explanation: "Abstract classes can maintain mutable instance state and define constructors, whereas interfaces can only declare public static final constants and, since Java 8, default/static methods but never instance fields or constructors. A class can implement multiple interfaces but extend only one class, which is the opposite of the first option.",
    points: 20
  },
  {
    id: "java-medium-003",
    category: "Java Development",
    difficulty: "Medium",
    topic: "Collections",
    question: "Which Collection interface should you use when you need to store unique elements with no guaranteed order and fast O(1) average lookup?",
    options: [
      "List",
      "Set (specifically HashSet)",
      "Map",
      "Queue"
    ],
    correctAnswer: "Set (specifically HashSet)",
    explanation: "A HashSet backed by a hash table stores unique elements (no duplicates) and offers average constant-time add, remove, and contains operations, but does not preserve insertion or sorted order. If order matters, LinkedHashSet or TreeSet would be chosen instead.",
    points: 20
  },
  {
    id: "java-medium-004",
    category: "Java Development",
    difficulty: "Medium",
    topic: "Exception handling",
    question: "What will the following code print?",
    code: "public class Test {\n    static int check() {\n        try {\n            return 1;\n        } finally {\n            System.out.println(\"finally ran\");\n        }\n    }\n    public static void main(String[] args) {\n        System.out.println(check());\n    }\n}",
    language: "java",
    options: [
      "1",
      "finally ran, then 1",
      "1, then finally ran",
      "Compilation error because return and finally cannot be used together"
    ],
    correctAnswer: "finally ran, then 1",
    explanation: "The finally block always executes before the method actually returns to the caller, even though the return value (1) was already determined by the try block. So \"finally ran\" prints first, then the returned value 1 is printed by the caller's println. This is a very common trick question about try-finally semantics.",
    points: 20
  },
  {
    id: "java-medium-005",
    category: "Java Development",
    difficulty: "Medium",
    topic: "Methods",
    question: "What will the following code print?",
    code: "public class Test {\n    static void show(int x) {\n        System.out.println(\"int version: \" + x);\n    }\n    static void show(long x) {\n        System.out.println(\"long version: \" + x);\n    }\n    public static void main(String[] args) {\n        byte b = 10;\n        show(b);\n    }\n}",
    language: "java",
    options: [
      "Compilation error, no matching overload for byte",
      "int version: 10",
      "long version: 10",
      "It is ambiguous and throws a runtime exception"
    ],
    correctAnswer: "int version: 10",
    explanation: "When no exact-type overload exists, Java widens the byte argument to the smallest compatible parameter type through a sequence of widening conversions (byte -> short -> int -> long ...), and picks the first applicable match, which is show(int). This demonstrates Java's overload resolution rules with automatic widening.",
    points: 20
  },
  {
    id: "java-medium-006",
    category: "Java Development",
    difficulty: "Medium",
    topic: "Map",
    question: "In a HashMap, what happens when you insert a key that is equal to (via equals()) an existing key already present in the map?",
    options: [
      "The map throws a DuplicateKeyException",
      "Both key-value pairs are stored side by side",
      "The new value replaces the old value for that key, and put() returns the previous value",
      "The insertion is silently ignored and the old value is kept"
    ],
    correctAnswer: "The new value replaces the old value for that key, and put() returns the previous value",
    explanation: "HashMap uses equals() and hashCode() to detect an existing key; if a match is found, the new value overwrites the old one, and put() returns the value that was previously associated with that key (or null if it was new). This behavior is why correctly overriding equals()/hashCode() together is critical for objects used as map keys.",
    points: 20
  },
  {
    id: "java-medium-007",
    category: "Java Development",
    difficulty: "Medium",
    topic: "Inheritance",
    question: "What will the following code print?",
    code: "class Animal {\n    void sound() {\n        System.out.println(\"Animal makes a sound\");\n    }\n}\nclass Dog extends Animal {\n    @Override\n    void sound() {\n        System.out.println(\"Dog barks\");\n    }\n}\npublic class Test {\n    public static void main(String[] args) {\n        Animal a = new Dog();\n        a.sound();\n    }\n}",
    language: "java",
    options: [
      "Animal makes a sound",
      "Dog barks",
      "Compilation error, cannot assign Dog to Animal reference",
      "Both \"Animal makes a sound\" and \"Dog barks\" are printed"
    ],
    correctAnswer: "Dog barks",
    explanation: "Java uses dynamic (runtime) method dispatch for overridden instance methods, so the actual object type (Dog) determines which overridden version of sound() runs, regardless of the reference type (Animal). This is the core mechanism behind runtime polymorphism.",
    points: 20
  },
  {
    id: "java-medium-008",
    category: "Java Development",
    difficulty: "Medium",
    topic: "Data types",
    question: "What will the following code print?",
    code: "Integer a = 127;\nInteger b = 127;\nInteger c = 200;\nInteger d = 200;\nSystem.out.println(a == b);\nSystem.out.println(c == d);",
    language: "java",
    options: [
      "true, true",
      "false, false",
      "true, false",
      "false, true"
    ],
    correctAnswer: "true, false",
    explanation: "Java caches boxed Integer values from -128 to 127 (the integer cache), so autoboxed Integers in that range returned by valueOf() are shared, making a == b true. Values outside that range, like 200, create distinct Integer objects each time, so c == d is false. This is a classic autoboxing gotcha in interviews.",
    points: 20
  },
  {
    id: "java-medium-009",
    category: "Java Development",
    difficulty: "Medium",
    topic: "List",
    question: "What is the key performance difference between ArrayList and LinkedList in Java?",
    options: [
      "ArrayList provides O(1) random access via index but O(n) insertion/deletion in the middle; LinkedList provides O(1) insertion/deletion at a known node but O(n) random access",
      "ArrayList and LinkedList have identical performance characteristics for all operations",
      "LinkedList provides O(1) random access while ArrayList requires traversal for every access",
      "ArrayList cannot store more than a fixed number of elements while LinkedList can grow indefinitely"
    ],
    correctAnswer: "ArrayList provides O(1) random access via index but O(n) insertion/deletion in the middle; LinkedList provides O(1) insertion/deletion at a known node but O(n) random access",
    explanation: "ArrayList is backed by a resizable array, so get(index) is constant time, but inserting or removing in the middle requires shifting elements. LinkedList is a doubly linked list, so insertion/removal at a known position is constant time once located, but accessing an arbitrary index requires traversal from an end, making it linear time.",
    points: 20
  },
  {
    id: "java-medium-010",
    category: "Java Development",
    difficulty: "Medium",
    topic: "Abstraction",
    question: "Consider a class Shape with an abstract method double area(). Which statement about Shape is correct?",
    options: [
      "Shape can be instantiated directly with new Shape() as long as area() has a default implementation",
      "Shape cannot be instantiated directly; any concrete subclass must implement area() or itself be declared abstract",
      "Abstract methods must always be declared static",
      "A class with even one abstract method does not need to be declared abstract itself"
    ],
    correctAnswer: "Shape cannot be instantiated directly; any concrete subclass must implement area() or itself be declared abstract",
    explanation: "A class containing an abstract method must itself be declared abstract and cannot be instantiated with new; only a concrete (non-abstract) subclass that provides an implementation for every inherited abstract method can be instantiated. This enforces that abstraction defines a contract subclasses must fulfill.",
    points: 20
  },

  // ==================== HARD (5) ====================
  {
    id: "java-hard-001",
    category: "Java Development",
    difficulty: "Hard",
    topic: "Java interview problems",
    question: "What will the following code print?",
    code: "class Base {\n    static void greet() {\n        System.out.println(\"Base static greet\");\n    }\n    void hello() {\n        System.out.println(\"Base hello\");\n    }\n}\nclass Derived extends Base {\n    static void greet() {\n        System.out.println(\"Derived static greet\");\n    }\n    @Override\n    void hello() {\n        System.out.println(\"Derived hello\");\n    }\n}\npublic class Test {\n    public static void main(String[] args) {\n        Base b = new Derived();\n        b.greet();\n        b.hello();\n    }\n}",
    language: "java",
    options: [
      "Base static greet, Base hello",
      "Derived static greet, Derived hello",
      "Base static greet, Derived hello",
      "Derived static greet, Base hello"
    ],
    correctAnswer: "Base static greet, Derived hello",
    explanation: "Static methods are resolved at compile time based on the reference type, so b.greet() calls Base's static method even though b points to a Derived object (static methods are not polymorphic and are technically hidden, not overridden). Instance method hello() is resolved at runtime via dynamic dispatch based on the actual object type, so it calls Derived's overridden version. This distinction between method hiding and method overriding is a favorite hard interview question.",
    points: 30
  },
  {
    id: "java-hard-002",
    category: "Java Development",
    difficulty: "Hard",
    topic: "Multithreading",
    question: "Two threads each call increment() 100,000 times (200,000 calls total) on the same shared Counter instance shown below, with no synchronization. What is the most accurate description of the final value of count?",
    code: "class Counter {\n    private int count = 0;\n    void increment() {\n        count++;\n    }\n    int getCount() {\n        return count;\n    }\n}",
    language: "java",
    options: [
      "There is no risk because count++ is a single bytecode instruction and therefore atomic",
      "count++ actually involves a read, increment, and write, and without synchronization a race condition can cause lost updates, so the final count can be less than the expected total",
      "The JVM automatically synchronizes all increment operations on shared primitive fields",
      "The program will fail to compile because count++ is not thread-safe by default"
    ],
    correctAnswer: "count++ actually involves a read, increment, and write, and without synchronization a race condition can cause lost updates, so the final count can be less than the expected total",
    explanation: "count++ compiles to at least three separate steps (load the value, add one, store it back), so two threads can interleave and both read the same stale value before either writes back, causing one increment to be lost. The fix is to use synchronized blocks/methods, a lock, or java.util.concurrent.atomic.AtomicInteger, which is a very common concurrency interview topic.",
    points: 30
  },
  {
    id: "java-hard-003",
    category: "Java Development",
    difficulty: "Hard",
    topic: "Java interview problems",
    question: "The class Point below overrides equals() to compare x and y fields but does not override hashCode(). What will the following code print?",
    code: "class Point {\n    int x, y;\n    Point(int x, int y) {\n        this.x = x;\n        this.y = y;\n    }\n    @Override\n    public boolean equals(Object o) {\n        if (!(o instanceof Point)) return false;\n        Point p = (Point) o;\n        return this.x == p.x && this.y == p.y;\n    }\n}\npublic class Test {\n    public static void main(String[] args) {\n        Set<Point> set = new HashSet<>();\n        set.add(new Point(1, 2));\n        System.out.println(set.contains(new Point(1, 2)));\n    }\n}",
    language: "java",
    options: [
      "true, because equals() confirms the two Point objects are logically equal",
      "false, because the two Point objects likely land in different hash buckets since hashCode() was not overridden, so equals() is never even checked",
      "Compilation error, because equals() cannot be overridden without hashCode()",
      "It throws a runtime ClassCastException"
    ],
    correctAnswer: "false, because the two Point objects likely land in different hash buckets since hashCode() was not overridden, so equals() is never even checked",
    explanation: "HashMap and HashSet first use hashCode() to locate the correct bucket and only then use equals() to compare within that bucket, so violating the equals/hashCode contract (equal objects must have equal hash codes) means two \"equal\" Point objects can land in different buckets, and contains() returns false because it never even reaches the equals() comparison. This silently breaks lookups and deduplication, and is a frequently tested gotcha about the equals/hashCode contract.",
    points: 30
  },
  {
    id: "java-hard-004",
    category: "Java Development",
    difficulty: "Hard",
    topic: "Generics",
    question: "Why does the following code fail to compile?",
    code: "List<Object> list = new ArrayList<Integer>();",
    language: "java",
    options: [
      "Because ArrayList cannot be used with generics at all",
      "Because Java generics are invariant: List<Integer> is not a subtype of List<Object>, even though Integer is a subtype of Object",
      "Because Integer cannot be added to a List",
      "Because List<Object> requires an explicit cast from List<Integer>"
    ],
    correctAnswer: "Because Java generics are invariant: List<Integer> is not a subtype of List<Object>, even though Integer is a subtype of Object",
    explanation: "Unlike arrays (which are covariant), generic types in Java are invariant, meaning List<Integer> and List<Object> are completely unrelated types despite Integer being a subtype of Object. This design prevents unsafe operations, such as inserting a String into what was actually a List<Integer>, and is why wildcards like List<? extends Object> exist for flexible, safe generic APIs.",
    points: 30
  },
  {
    id: "java-hard-005",
    category: "Java Development",
    difficulty: "Hard",
    topic: "JVM",
    question: "Which statement about garbage collection in Java is most accurate?",
    options: [
      "Calling System.gc() guarantees that garbage collection runs immediately",
      "An object becomes eligible for garbage collection once it is no longer reachable from any live thread, GC root, or static reference, but the exact timing of collection is not guaranteed",
      "Objects with a finalize() method are guaranteed to be collected before the JVM exits",
      "Garbage collection immediately frees memory the instant an object's reference is set to null"
    ],
    correctAnswer: "An object becomes eligible for garbage collection once it is no longer reachable from any live thread, GC root, or static reference, but the exact timing of collection is not guaranteed",
    explanation: "The JVM's garbage collector reclaims memory for objects that are unreachable from GC roots (active thread stacks, static fields, JNI references, etc.), but it decides when and how to run collection cycles; System.gc() only suggests a collection and does not force one. Understanding reachability versus reference-counting, and that timing is non-deterministic, is key for reasoning about memory leaks and performance in Java.",
    points: 30
  }
];
