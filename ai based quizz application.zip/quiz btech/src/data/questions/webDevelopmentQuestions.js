export const webDevelopmentQuestions = [
  // ===================== EASY (10) =====================
  {
    id: "webdev-easy-001",
    category: "Web Development",
    difficulty: "Easy",
    topic: "HTML",
    question: "Which HTML tag is used to define the most important heading on a page?",
    options: ["<h1>", "<head>", "<header>", "<heading>"],
    correctAnswer: "<h1>",
    explanation: "<h1> represents the highest-level heading and is typically used once per page for the main title, which also matters for SEO and accessibility outlines.",
    points: 10
  },
  {
    id: "webdev-easy-002",
    category: "Web Development",
    difficulty: "Easy",
    topic: "CSS",
    question: "In the CSS box model, which property adds space INSIDE an element's border, between the border and the content?",
    options: ["padding", "margin", "border-spacing", "outline"],
    correctAnswer: "padding",
    explanation: "Padding is the space between the content and the border, whereas margin is the space outside the border separating the element from its neighbors.",
    points: 10
  },
  {
    id: "webdev-easy-003",
    category: "Web Development",
    difficulty: "Easy",
    topic: "HTML",
    question: "Which HTML element is the semantically correct choice for the main navigation links of a website?",
    options: ["<nav>", "<div>", "<section>", "<links>"],
    correctAnswer: "<nav>",
    explanation: "<nav> is a semantic HTML5 element specifically intended to wrap major navigation blocks, improving accessibility for screen readers and SEO.",
    points: 10
  },
  {
    id: "webdev-easy-004",
    category: "Web Development",
    difficulty: "Easy",
    topic: "CSS",
    question: "Which CSS selector targets all elements with the class name 'card'?",
    options: [".card", "#card", "card", "*card"],
    correctAnswer: ".card",
    explanation: "A dot prefix (.card) selects elements by class attribute, while a hash (#card) selects by unique id.",
    points: 10
  },
  {
    id: "webdev-easy-005",
    category: "Web Development",
    difficulty: "Easy",
    topic: "JavaScript",
    question: "Which keyword is used to declare a variable that cannot be reassigned after initialization in modern JavaScript?",
    options: ["const", "var", "let", "static"],
    correctAnswer: "const",
    explanation: "const creates a binding that cannot be reassigned; note it still allows mutation of the object/array it points to, which is a common interview follow-up.",
    points: 10
  },
  {
    id: "webdev-easy-006",
    category: "Web Development",
    difficulty: "Easy",
    topic: "DOM",
    question: "Which method is commonly used to select a single element from the DOM using a CSS selector?",
    options: ["document.querySelector()", "document.getElementByClass()", "document.selectElement()", "document.find()"],
    correctAnswer: "document.querySelector()",
    explanation: "document.querySelector() returns the first element matching a given CSS selector; there is no built-in getElementByClass or find method on document.",
    points: 10
  },
  {
    id: "webdev-easy-007",
    category: "Web Development",
    difficulty: "Easy",
    topic: "Forms",
    question: "Which HTML input type is best suited for collecting an email address with basic built-in validation?",
    options: ["type=\"email\"", "type=\"text\"", "type=\"mail\"", "type=\"address\""],
    correctAnswer: "type=\"email\"",
    explanation: "The email input type triggers the browser's built-in email format validation and shows an appropriate virtual keyboard on mobile devices.",
    points: 10
  },
  {
    id: "webdev-easy-008",
    category: "Web Development",
    difficulty: "Easy",
    topic: "Responsive design",
    question: "Which meta tag is essential in the <head> for a webpage to render properly on mobile devices?",
    options: [
      "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">",
      "<meta name=\"mobile\" content=\"true\">",
      "<meta charset=\"UTF-8\">",
      "<meta name=\"responsive\" content=\"yes\">"
    ],
    correctAnswer: "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">",
    explanation: "The viewport meta tag tells mobile browsers to set the page width to the device width and an initial zoom level, which is fundamental for responsive design.",
    points: 10
  },
  {
    id: "webdev-easy-009",
    category: "Web Development",
    difficulty: "Easy",
    topic: "Events",
    question: "Which JavaScript method attaches an event listener to a DOM element without overwriting existing handlers?",
    options: ["addEventListener()", "onClick()", "attachEvent()", "element.on()"],
    correctAnswer: "addEventListener()",
    explanation: "addEventListener() registers a handler and can be called multiple times to attach several listeners for the same event, unlike setting element.onclick which overwrites any previous handler.",
    points: 10
  },
  {
    id: "webdev-easy-010",
    category: "Web Development",
    difficulty: "Easy",
    topic: "Browser storage",
    question: "Which browser storage mechanism persists data even after the browser is closed and reopened, until explicitly cleared?",
    options: ["localStorage", "sessionStorage", "cookies only", "variables in memory"],
    correctAnswer: "localStorage",
    explanation: "localStorage persists data with no expiration date across browser sessions, unlike sessionStorage which is cleared when the tab/browser is closed.",
    points: 10
  },

  // ===================== MEDIUM (10) =====================
  {
    id: "webdev-medium-001",
    category: "Web Development",
    difficulty: "Medium",
    topic: "JavaScript",
    question: "What will the following code print to the console?",
    code: "console.log(1 + '1');\nconsole.log(1 - '1');",
    language: "javascript",
    options: ["'11' and 0", "2 and 0", "'11' and NaN", "2 and NaN"],
    correctAnswer: "'11' and 0",
    explanation: "The + operator with a string operand triggers string concatenation ('1' + '1' = '11'), while - forces numeric coercion of both operands (1 - 1 = 0). This asymmetry is a classic type coercion interview question.",
    points: 20
  },
  {
    id: "webdev-medium-002",
    category: "Web Development",
    difficulty: "Medium",
    topic: "ES6+",
    question: "What is the key difference between 'let' and 'var' when declaring variables inside a for loop in JavaScript?",
    options: [
      "let is block-scoped and creates a new binding per iteration, while var is function-scoped and shares one binding",
      "var is block-scoped while let is globally scoped",
      "let cannot be used inside loops at all",
      "There is no difference; they behave identically in loops"
    ],
    correctAnswer: "let is block-scoped and creates a new binding per iteration, while var is function-scoped and shares one binding",
    explanation: "Because let creates a fresh binding for each loop iteration, closures capturing the loop variable work as expected, which is a frequent source of bugs and interview questions when using var.",
    points: 20
  },
  {
    id: "webdev-medium-003",
    category: "Web Development",
    difficulty: "Medium",
    topic: "Events",
    question: "In the DOM event flow, what is 'event bubbling'?",
    options: [
      "An event triggered on a nested element propagates upward through its ancestor elements",
      "An event triggered on an ancestor element propagates downward to its children",
      "Multiple events firing simultaneously on the same element",
      "An event that only fires once regardless of how many listeners are attached"
    ],
    correctAnswer: "An event triggered on a nested element propagates upward through its ancestor elements",
    explanation: "Event bubbling means the event travels from the target element up through its parents to the document root, which is what enables the event delegation pattern.",
    points: 20
  },
  {
    id: "webdev-medium-004",
    category: "Web Development",
    difficulty: "Medium",
    topic: "Promises",
    question: "What will the following code log?",
    code: "console.log('start');\nPromise.resolve().then(() => console.log('promise'));\nconsole.log('end');",
    language: "javascript",
    options: ["start, end, promise", "start, promise, end", "promise, start, end", "start, end (promise never logs)"],
    correctAnswer: "start, end, promise",
    explanation: "Synchronous code runs first ('start' then 'end'), and the .then() callback is queued as a microtask that only runs after the current synchronous execution finishes, so 'promise' logs last.",
    points: 20
  },
  {
    id: "webdev-medium-005",
    category: "Web Development",
    difficulty: "Medium",
    topic: "Flexbox",
    question: "In a Flexbox container with 'display: flex' and default settings, which property is used to align flex items along the cross axis?",
    options: ["align-items", "justify-content", "flex-direction", "align-self-only"],
    correctAnswer: "align-items",
    explanation: "justify-content aligns items along the main axis, while align-items aligns them along the cross axis (perpendicular to the main axis); confusing the two is a very common Flexbox mistake.",
    points: 20
  },
  {
    id: "webdev-medium-006",
    category: "Web Development",
    difficulty: "Medium",
    topic: "Async/Await",
    question: "What is the output of the following code?",
    code: "async function getData() {\n  return 5;\n}\nconst result = getData();\nconsole.log(result);",
    language: "javascript",
    options: [
      "Promise {<fulfilled>: 5} (a Promise object, not the raw value 5)",
      "5",
      "undefined",
      "A syntax error because async functions cannot return values"
    ],
    correctAnswer: "Promise {<fulfilled>: 5} (a Promise object, not the raw value 5)",
    explanation: "An async function always returns a Promise, even when it returns a plain value; the value 5 becomes the resolution value of that promise, accessible via .then() or await.",
    points: 20
  },
  {
    id: "webdev-medium-007",
    category: "Web Development",
    difficulty: "Medium",
    topic: "Browser storage",
    question: "What is the primary difference between localStorage and sessionStorage?",
    options: [
      "sessionStorage data is cleared when the page's tab/session ends, while localStorage persists across sessions",
      "localStorage has no storage limit while sessionStorage is limited to 5KB",
      "sessionStorage can store objects directly while localStorage can only store strings",
      "localStorage is only accessible over HTTPS while sessionStorage works on HTTP too"
    ],
    correctAnswer: "sessionStorage data is cleared when the page's tab/session ends, while localStorage persists across sessions",
    explanation: "Both store string data with similar size limits (typically ~5-10MB), but sessionStorage is scoped to a single tab session and cleared when that tab closes, whereas localStorage persists indefinitely until explicitly removed.",
    points: 20
  },
  {
    id: "webdev-medium-008",
    category: "Web Development",
    difficulty: "Medium",
    topic: "JavaScript",
    question: "What does the following code output, and why?",
    code: "console.log(typeof null);\nconsole.log(null == undefined);\nconsole.log(null === undefined);",
    language: "javascript",
    options: [
      "'object', true, false",
      "'null', true, true",
      "'object', false, false",
      "'undefined', true, false"
    ],
    correctAnswer: "'object', true, false",
    explanation: "typeof null is 'object' due to a long-standing JavaScript bug kept for backward compatibility; == performs loose comparison where null and undefined are considered equal, but === requires matching types so it is false.",
    points: 20
  },
  {
    id: "webdev-medium-009",
    category: "Web Development",
    difficulty: "Medium",
    topic: "CSS Grid",
    question: "In CSS Grid, what does the property value 'grid-template-columns: repeat(3, 1fr)' produce?",
    options: [
      "Three equal-width columns that share the available space",
      "Three columns each exactly 1 pixel wide",
      "A single column repeated three times vertically",
      "Three rows of flexible height"
    ],
    correctAnswer: "Three equal-width columns that share the available space",
    explanation: "The fr unit represents a fraction of the remaining free space in the grid container, so repeat(3, 1fr) creates three columns that split the available width equally.",
    points: 20
  },
  {
    id: "webdev-medium-010",
    category: "Web Development",
    difficulty: "Medium",
    topic: "Fetch API",
    question: "What is a key characteristic of the Fetch API's behavior when a server responds with a 404 or 500 HTTP status code?",
    options: [
      "The fetch() promise still resolves successfully; only network failures cause it to reject",
      "The fetch() promise automatically rejects for any non-2xx status code",
      "fetch() throws a synchronous exception immediately",
      "fetch() retries the request automatically up to three times"
    ],
    correctAnswer: "The fetch() promise still resolves successfully; only network failures cause it to reject",
    explanation: "fetch() only rejects on network-level errors (like DNS failure or no connectivity); HTTP error statuses must be checked manually via response.ok or response.status, a common interview gotcha.",
    points: 20
  },

  // ===================== HARD (5) =====================
  {
    id: "webdev-hard-001",
    category: "Web Development",
    difficulty: "Hard",
    topic: "Browser concepts",
    question: "What is the exact console output order of the following code, considering the event loop's microtask and macrotask queues?",
    code: "console.log('1');\nsetTimeout(() => console.log('2'), 0);\nPromise.resolve().then(() => console.log('3'));\nPromise.resolve().then(() => console.log('4'));\nconsole.log('5');",
    language: "javascript",
    options: ["1, 5, 3, 4, 2", "1, 5, 2, 3, 4", "1, 3, 4, 5, 2", "1, 2, 3, 4, 5"],
    correctAnswer: "1, 5, 3, 4, 2",
    explanation: "Synchronous code ('1', '5') runs first, then all queued microtasks (the two .then callbacks, '3' and '4') drain completely before the event loop moves to the macrotask queue where the setTimeout callback ('2') runs, even with a 0ms delay.",
    points: 30
  },
  {
    id: "webdev-hard-002",
    category: "Web Development",
    difficulty: "Hard",
    topic: "JavaScript",
    question: "Given the closure-based counter factory below, what does the code output?",
    code: "function makeCounter() {\n  let count = 0;\n  return function () {\n    count += 1;\n    return count;\n  };\n}\nconst counterA = makeCounter();\nconst counterB = makeCounter();\nconsole.log(counterA());\nconsole.log(counterA());\nconsole.log(counterB());",
    language: "javascript",
    options: ["1, 2, 1", "1, 2, 3", "1, 1, 1", "undefined, undefined, undefined"],
    correctAnswer: "1, 2, 1",
    explanation: "Each call to makeCounter() creates a new lexical environment with its own independent 'count' variable, so counterA and counterB maintain separate closures over separate state, and counterB starts fresh at 1.",
    points: 30
  },
  {
    id: "webdev-hard-003",
    category: "Web Development",
    difficulty: "Hard",
    topic: "CSS",
    question: "Given the following CSS rules applied to the same element, which color will actually be rendered and why?",
    code: "/* Rule A */\n.box { color: blue; }\n\n/* Rule B */\ndiv.box { color: red; }\n\n/* Rule C */\n#main .box { color: green; }\n\n<div id=\"main\" class=\"box\"></div>",
    language: "css",
    options: [
      "Green, because the id-based selector #main .box has the highest specificity (1,1,0) among the three rules",
      "Red, because div.box is more specific due to combining a tag and class selector",
      "Blue, because Rule A appears first in source order",
      "Red, because the last matching rule in the cascade always wins regardless of specificity"
    ],
    correctAnswer: "Green, because the id-based selector #main .box has the highest specificity (1,1,0) among the three rules",
    explanation: "CSS specificity is calculated as (inline, id, class/attribute/pseudo-class, element); #main .box scores (0,1,1,0) versus div.box's (0,0,1,1) and .box's (0,0,1,0), so the id-containing selector wins regardless of source order.",
    points: 30
  },
  {
    id: "webdev-hard-004",
    category: "Web Development",
    difficulty: "Hard",
    topic: "Performance",
    question: "A search input fires an expensive API call on every 'input' event, causing the UI to lag while typing. Which technique is most appropriate to fix this, and what does it do?",
    code: "input.addEventListener('input', (e) => {\n  fetchSearchResults(e.target.value);\n});",
    language: "javascript",
    options: [
      "Debouncing: delay the API call until the user has stopped typing for a set pause, resetting the timer on every keystroke",
      "Throttling: guarantee the API call fires at most once immediately on every single keystroke with no delay",
      "Memoization: cache the DOM event object itself to avoid re-creating it",
      "Using event.stopPropagation() to prevent the input event from bubbling and firing multiple times"
    ],
    correctAnswer: "Debouncing: delay the API call until the user has stopped typing for a set pause, resetting the timer on every keystroke",
    explanation: "Debouncing resets a timer on every keystroke and only fires the callback after typing pauses, which is ideal for search-as-you-type since it collapses rapid-fire events into a single call, unlike throttling which limits call frequency but still fires periodically during continuous typing.",
    points: 30
  },
  {
    id: "webdev-hard-005",
    category: "Web Development",
    difficulty: "Hard",
    topic: "Web security",
    question: "A web application inserts unsanitized user input directly into the page using innerHTML, as shown below. What vulnerability does this create, and what is the standard mitigation?",
    code: "const comment = getUserInput(); // e.g. \"<img src=x onerror=alert(1)>\"\ncommentBox.innerHTML = comment;",
    language: "javascript",
    options: [
      "Cross-Site Scripting (XSS); mitigate by sanitizing/escaping user input or using textContent instead of innerHTML",
      "Cross-Site Request Forgery (CSRF); mitigate by adding a CSRF token to every form",
      "SQL Injection; mitigate by using parameterized queries on the client",
      "Clickjacking; mitigate by setting the X-Frame-Options header"
    ],
    correctAnswer: "Cross-Site Scripting (XSS); mitigate by sanitizing/escaping user input or using textContent instead of innerHTML",
    explanation: "Injecting raw user-controlled HTML via innerHTML allows attacker-supplied scripts or event handlers (like onerror) to execute in the victim's browser, which is stored/reflected XSS; the fix is to escape HTML entities, use a sanitizer library, or prefer textContent for plain text.",
    points: 30
  }
];
