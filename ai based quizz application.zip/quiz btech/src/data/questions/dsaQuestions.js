export const dsaQuestions = [
  {
    id: "dsa-easy-001",
    category: "Data Structures & Algorithms",
    difficulty: "Easy",
    topic: "Arrays & Strings",
    question: "What is the time complexity to access an element in an array by its index?",
    options: ["O(1)", "O(n)", "O(log n)", "O(n^2)"],
    correctAnswer: "O(1)",
    explanation: "Arrays store elements in contiguous memory locations. Using the base address, element size, and index, the memory address is calculated in O(1) constant time directly without traversing.",
    points: 10
  },
  {
    id: "dsa-easy-002",
    category: "Data Structures & Algorithms",
    difficulty: "Easy",
    topic: "Linked Lists",
    question: "Which advantage does a singly linked list have over a standard fixed-size array?",
    options: [
      "Dynamic size allocation at runtime without pre-allocating memory",
      "O(1) random access to any element by index",
      "Better cache locality of reference",
      "Lower memory overhead per element"
    ],
    correctAnswer: "Dynamic size allocation at runtime without pre-allocating memory",
    explanation: "Linked lists allocate nodes dynamically in memory as needed, allowing effortless growth and shrinkage without resizing or copying the whole collection.",
    points: 10
  },
  {
    id: "dsa-easy-003",
    category: "Data Structures & Algorithms",
    difficulty: "Easy",
    topic: "Stacks & Queues",
    question: "Which abstract data structure follows the Last-In, First-Out (LIFO) order?",
    options: ["Queue", "Stack", "Binary Heap", "Hash Table"],
    correctAnswer: "Stack",
    explanation: "A Stack follows the LIFO (Last-In, First-Out) principle, where the most recently pushed element is the first one popped off.",
    points: 10
  },
  {
    id: "dsa-easy-004",
    category: "Data Structures & Algorithms",
    difficulty: "Easy",
    topic: "Stacks & Queues",
    question: "In a standard queue, from which ends do insertion (enqueue) and deletion (dequeue) occur?",
    options: [
      "Insertion at Rear, Deletion at Front",
      "Insertion at Front, Deletion at Rear",
      "Insertion and Deletion both at Top",
      "Insertion and Deletion both at Rear"
    ],
    correctAnswer: "Insertion at Rear, Deletion at Front",
    explanation: "A Queue operates on the First-In, First-Out (FIFO) principle: elements are inserted at the Rear (tail) and removed from the Front (head).",
    points: 10
  },
  {
    id: "dsa-easy-005",
    category: "Data Structures & Algorithms",
    difficulty: "Easy",
    topic: "Searching & Sorting",
    question: "What is the worst-case time complexity of Binary Search on a sorted array of size n?",
    options: ["O(log n)", "O(n)", "O(n log n)", "O(1)"],
    correctAnswer: "O(log n)",
    explanation: "Binary search divides the search space in half with every comparison, leading to logarithmic O(log n) time complexity.",
    points: 10
  },
  {
    id: "dsa-easy-006",
    category: "Data Structures & Algorithms",
    difficulty: "Easy",
    topic: "Binary Trees",
    question: "What is the maximum number of nodes in a binary tree of height h (where height of root is 0)?",
    options: ["2^(h + 1) - 1", "2^h", "2^(h - 1)", "h^2"],
    correctAnswer: "2^(h + 1) - 1",
    explanation: "A full binary tree has 2^0 + 2^1 + ... + 2^h nodes, which sums up by geometric series to 2^(h + 1) - 1.",
    points: 10
  },
  {
    id: "dsa-easy-007",
    category: "Data Structures & Algorithms",
    difficulty: "Easy",
    topic: "Searching & Sorting",
    question: "Which sorting algorithm is guaranteed to have O(n log n) time complexity in all cases (best, average, and worst)?",
    options: ["Merge Sort", "Quick Sort", "Bubble Sort", "Insertion Sort"],
    correctAnswer: "Merge Sort",
    explanation: "Merge Sort consistently divides the array in half and merges sorted halves, guaranteeing O(n log n) in best, average, and worst cases.",
    points: 10
  },
  {
    id: "dsa-easy-008",
    category: "Data Structures & Algorithms",
    difficulty: "Easy",
    topic: "Hashing",
    question: "Under ideal circumstances with a uniform hash function, what is the average time complexity of inserting a key in a Hash Map?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n^2)"],
    correctAnswer: "O(1)",
    explanation: "A hash map calculates the bucket index via the hash code in O(1) time, yielding constant average-case time for insertions, lookups, and deletions.",
    points: 10
  },
  {
    id: "dsa-easy-009",
    category: "Data Structures & Algorithms",
    difficulty: "Easy",
    topic: "Recursion",
    question: "What happens if a recursive function does not define or reach a base case?",
    options: [
      "A Stack Overflow error occurs due to unbounded call stack growth",
      "The program terminates with return value null",
      "The compiler converts it to a while loop automatically",
      "Garbage collection reclaims memory seamlessly"
    ],
    correctAnswer: "A Stack Overflow error occurs due to unbounded call stack growth",
    explanation: "Without reaching a base case, the function keeps calling itself infinitely until the allocated call stack memory is exhausted, throwing a Stack Overflow.",
    points: 10
  },
  {
    id: "dsa-easy-010",
    category: "Data Structures & Algorithms",
    difficulty: "Easy",
    topic: "Two Pointers",
    question: "Which technique is most optimal to check if a string is a palindrome in O(n) time and O(1) extra space?",
    options: [
      "Two Pointers moving inward from both ends",
      "Recursion with substring slicing",
      "Pushing characters to a stack and popping",
      "Sorting the string"
    ],
    correctAnswer: "Two Pointers moving inward from both ends",
    explanation: "Placing one pointer at index 0 and another at index n-1 and comparing characters while advancing inward requires only O(n) comparisons and O(1) auxiliary memory.",
    points: 10
  },
  {
    id: "dsa-medium-001",
    category: "Data Structures & Algorithms",
    difficulty: "Medium",
    topic: "Linked Lists",
    question: "Which algorithm detects a cycle in a linked list using two pointers moving at different speeds?",
    options: [
      "Floyd's Tortoise and Hare algorithm",
      "Dijkstra's algorithm",
      "Kruskal's algorithm",
      "Boyer-Moore voting algorithm"
    ],
    correctAnswer: "Floyd's Tortoise and Hare algorithm",
    explanation: "Floyd's Cycle-Finding algorithm uses a slow pointer (moves 1 step) and a fast pointer (moves 2 steps). If a cycle exists, they are guaranteed to meet inside the loop in O(n) time and O(1) space.",
    points: 20
  },
  {
    id: "dsa-medium-002",
    category: "Data Structures & Algorithms",
    difficulty: "Medium",
    topic: "Stacks & Queues",
    question: "What data structure is standardly used to validate matching parentheses, brackets, and braces in an expression string?",
    options: ["Stack", "Queue", "Priority Queue", "Binary Search Tree"],
    correctAnswer: "Stack",
    explanation: "An opening bracket is pushed onto a stack. When a closing bracket is found, the top of the stack is popped and checked for a matching pair.",
    points: 20
  },
  {
    id: "dsa-medium-003",
    category: "Data Structures & Algorithms",
    difficulty: "Medium",
    topic: "Binary Trees",
    question: "Which traversal of a Binary Search Tree (BST) visits nodes in strictly ascending sorted order?",
    options: ["Inorder traversal", "Preorder traversal", "Postorder traversal", "Level-order traversal"],
    correctAnswer: "Inorder traversal",
    explanation: "In a BST, all keys in the left subtree are smaller than the root, and all keys in the right subtree are larger. Inorder (Left -> Root -> Right) naturally visits them in non-decreasing order.",
    points: 20
  },
  {
    id: "dsa-medium-004",
    category: "Data Structures & Algorithms",
    difficulty: "Medium",
    topic: "Searching & Sorting",
    question: "Under what condition does standard QuickSort degrade to its worst-case O(n^2) time complexity?",
    options: [
      "When the chosen pivot is repeatedly the smallest or largest element (e.g. sorted array with first element as pivot)",
      "When all elements in the array are distinct and in random order",
      "When the array size is a power of 2",
      "When median-of-three pivot selection is employed"
    ],
    correctAnswer: "When the chosen pivot is repeatedly the smallest or largest element (e.g. sorted array with first element as pivot)",
    explanation: "If the pivot divides the array into partitions of size 0 and n - 1 at every step, the recursion tree height becomes n, yielding O(n^2) time.",
    points: 20
  },
  {
    id: "dsa-medium-005",
    category: "Data Structures & Algorithms",
    difficulty: "Medium",
    topic: "Heaps & Priority Queues",
    question: "What is the time complexity to build a Binary Heap from an unsorted array of n elements using bottom-up heapify (Build-Heap)?",
    options: ["O(n)", "O(n log n)", "O(log n)", "O(n^2)"],
    correctAnswer: "O(n)",
    explanation: "Because the number of nodes decreases exponentially with height, the mathematical summation of (height * nodes at height) converges to O(n) total operations.",
    points: 20
  },
  {
    id: "dsa-medium-006",
    category: "Data Structures & Algorithms",
    difficulty: "Medium",
    topic: "Graphs",
    question: "Which graph traversal finds the shortest path in terms of number of edges from a source node in an unweighted graph?",
    options: [
      "Breadth-First Search (BFS)",
      "Depth-First Search (DFS)",
      "Topological Sort",
      "Tarjan's strongly connected components"
    ],
    correctAnswer: "Breadth-First Search (BFS)",
    explanation: "BFS explores all vertices level-by-level (distance 1, distance 2, etc.), ensuring the first time a target vertex is reached, the path has the minimum number of edges.",
    points: 20
  },
  {
    id: "dsa-medium-007",
    category: "Data Structures & Algorithms",
    difficulty: "Medium",
    topic: "Dynamic Programming",
    question: "What are the two foundational properties required for a problem to be solved using Dynamic Programming?",
    options: [
      "Optimal Substructure and Overlapping Subproblems",
      "Greedy Choice Property and Divide & Conquer",
      "Independence of Subproblems and Binary Symmetry",
      "Deterministic Finite Automata and State Invariance"
    ],
    correctAnswer: "Optimal Substructure and Overlapping Subproblems",
    explanation: "DP is applicable when an optimal solution can be constructed from optimal solutions of subproblems (Optimal Substructure) and the same subproblems are computed repeatedly (Overlapping Subproblems).",
    points: 20
  },
  {
    id: "dsa-medium-008",
    category: "Data Structures & Algorithms",
    difficulty: "Medium",
    topic: "Sliding Window",
    question: "What is the time complexity to find the maximum sum subarray of fixed size k in an array of size n using the Sliding Window technique?",
    options: ["O(n)", "O(n * k)", "O(n log k)", "O(n^2)"],
    correctAnswer: "O(n)",
    explanation: "Instead of recalculating the sum of k elements at every step, the sliding window subtracts the exiting element and adds the entering element in O(1) time per step, requiring O(n) overall.",
    points: 20
  },
  {
    id: "dsa-medium-009",
    category: "Data Structures & Algorithms",
    difficulty: "Medium",
    topic: "Binary Trees",
    question: "How can the Lowest Common Ancestor (LCA) of two nodes p and q in a Binary Search Tree be identified efficiently?",
    options: [
      "Find the first node during traversal whose value lies between p.val and q.val (inclusive)",
      "Perform a level-order traversal and find the deepest common parent",
      "Store all paths in two hash sets and find the intersection",
      "Calculate the Hamming distance between their keys"
    ],
    correctAnswer: "Find the first node during traversal whose value lies between p.val and q.val (inclusive)",
    explanation: "In a BST, if both p and q are smaller than current node, LCA is in left subtree; if both are larger, LCA is in right subtree; otherwise, current node is the LCA splitting them.",
    points: 20
  },
  {
    id: "dsa-medium-010",
    category: "Data Structures & Algorithms",
    difficulty: "Medium",
    topic: "Graphs",
    question: "How is a cycle detected in a directed graph using Depth-First Search (DFS)?",
    options: [
      "By detecting a back-edge to an ancestor node currently present in the recursion stack",
      "By checking if the number of edges equals the number of vertices",
      "By verifying if any vertex has an odd degree",
      "By checking if BFS reaches the same vertex twice"
    ],
    correctAnswer: "By detecting a back-edge to an ancestor node currently present in the recursion stack",
    explanation: "In a directed graph, a cycle exists if and only if DFS encounters a back-edge pointing to a node currently active in the current recursion call stack.",
    points: 20
  },
  {
    id: "dsa-hard-001",
    category: "Data Structures & Algorithms",
    difficulty: "Hard",
    topic: "Dynamic Programming",
    question: "What is the recurrence relation for finding the length of the Longest Common Subsequence (LCS) of two strings X[1..m] and Y[1..n]?",
    options: [
      "If X[i] == Y[j]: 1 + LCS(i-1, j-1); Else: max(LCS(i-1, j), LCS(i, j-1))",
      "If X[i] == Y[j]: 2 + LCS(i-1, j-1); Else: min(LCS(i-1, j), LCS(i, j-1))",
      "LCS(i, j) = LCS(i-1, j-1) + LCS(i-1, j) + LCS(i, j-1)",
      "If X[i] == Y[j]: LCS(i-1, j-1); Else: 1 + max(LCS(i-1, j), LCS(i, j-1))"
    ],
    correctAnswer: "If X[i] == Y[j]: 1 + LCS(i-1, j-1); Else: max(LCS(i-1, j), LCS(i, j-1))",
    explanation: "When current characters match, they contribute 1 to the subsequence length from the remaining prefixes. When they differ, the result is the best of dropping one character from either string.",
    points: 30
  },
  {
    id: "dsa-hard-002",
    category: "Data Structures & Algorithms",
    difficulty: "Hard",
    topic: "Graphs",
    question: "What is the time complexity of Dijkstra's Single-Source Shortest Path algorithm implemented with an adjacency list and a Binary Min-Heap Priority Queue for a graph with V vertices and E edges?",
    options: ["O((V + E) log V)", "O(V^2)", "O(E * V)", "O(V log E)"],
    correctAnswer: "O((V + E) log V)",
    explanation: "Each vertex is extracted from the min-heap once (V log V), and every edge can cause at most one decrease-key / insertion operation in the heap (E log V), yielding O((V + E) log V).",
    points: 30
  },
  {
    id: "dsa-hard-003",
    category: "Data Structures & Algorithms",
    difficulty: "Hard",
    topic: "Binary Trees",
    question: "To uniquely reconstruct a Binary Tree (not necessarily a BST), which combination of tree traversals is required?",
    options: [
      "Inorder traversal along with either Preorder or Postorder traversal",
      "Preorder and Postorder traversals alone",
      "Level-order traversal alone",
      "Any single depth-first traversal"
    ],
    correctAnswer: "Inorder traversal along with either Preorder or Postorder traversal",
    explanation: "Inorder traversal provides the dividing line between left and right subtrees, while Preorder (or Postorder) reveals the root node of the current subtree. Both together uniquely determine tree topology.",
    points: 30
  },
  {
    id: "dsa-hard-004",
    category: "Data Structures & Algorithms",
    difficulty: "Hard",
    topic: "Backtracking",
    question: "In solving the N-Queens problem using backtracking, what enables efficient O(1) safety validation for row, column, and both diagonals?",
    options: [
      "Hash sets/boolean arrays tracking occupied columns, (row - col) diagonals, and (row + col) anti-diagonals",
      "Recalculating Euclidean distance between all placed queens",
      "Running breadth-first search across all board states",
      "Using matrix multiplication of board coordinates"
    ],
    correctAnswer: "Hash sets/boolean arrays tracking occupied columns, (row - col) diagonals, and (row + col) anti-diagonals",
    explanation: "Because elements on the same main diagonal share the same difference (row - col) and anti-diagonal share the same sum (row + col), constant-time O(1) lookups determine if a square is under attack.",
    points: 30
  },
  {
    id: "dsa-hard-005",
    category: "Data Structures & Algorithms",
    difficulty: "Hard",
    topic: "Disjoint Set Union (DSU)",
    question: "What is the amortized time complexity per operation for Disjoint Set Union (DSU / Union-Find) when both Path Compression and Union by Rank/Size optimizations are used?",
    options: [
      "O(α(n)), where α is the inverse Ackermann function (nearly constant)",
      "O(log n)",
      "O(n)",
      "O(1) strictly deterministic"
    ],
    correctAnswer: "O(α(n)), where α is the inverse Ackermann function (nearly constant)",
    explanation: "Combining path compression and union by rank flattens the tree structure so effectively that operations run in O(α(n)) amortized time, which is strictly less than 5 for all practical universe sizes.",
    points: 30
  }
];
