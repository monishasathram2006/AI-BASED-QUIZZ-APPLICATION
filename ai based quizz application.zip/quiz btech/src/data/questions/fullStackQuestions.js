export const fullStackQuestions = [
  // ===================== EASY (10) =====================
  {
    id: "fullstack-easy-001",
    category: "Full Stack",
    difficulty: "Easy",
    topic: "REST APIs",
    question: "What does REST stand for in the context of web APIs?",
    options: [
      "Representational State Transfer",
      "Remote Execution Service Technology",
      "Reliable State Transmission",
      "Resource Exchange Style Transfer"
    ],
    correctAnswer: "Representational State Transfer",
    explanation: "REST (Representational State Transfer) is an architectural style for designing networked applications using stateless communication and standard HTTP methods to operate on resources.",
    points: 10
  },
  {
    id: "fullstack-easy-002",
    category: "Full Stack",
    difficulty: "Easy",
    topic: "HTTP",
    question: "Which HTTP method is typically used to update an entire existing resource?",
    options: ["GET", "PUT", "DELETE", "OPTIONS"],
    correctAnswer: "PUT",
    explanation: "PUT is used to replace an existing resource entirely with the data sent in the request, while PATCH is used for partial updates. This distinction is commonly tested in interviews.",
    points: 10
  },
  {
    id: "fullstack-easy-003",
    category: "Full Stack",
    difficulty: "Easy",
    topic: "HTTP",
    question: "Which HTTP status code indicates that a resource was successfully created?",
    options: ["200 OK", "201 Created", "204 No Content", "301 Moved Permanently"],
    correctAnswer: "201 Created",
    explanation: "201 Created is returned when a request has successfully resulted in the creation of a new resource, commonly after a POST request.",
    points: 10
  },
  {
    id: "fullstack-easy-004",
    category: "Full Stack",
    difficulty: "Easy",
    topic: "MVC",
    question: "In the MVC (Model-View-Controller) architecture, what is the primary responsibility of the Model?",
    options: [
      "Rendering the user interface",
      "Handling incoming HTTP requests and routing",
      "Managing application data and business logic",
      "Styling components with CSS"
    ],
    correctAnswer: "Managing application data and business logic",
    explanation: "The Model represents the application's data and business rules, the View handles presentation, and the Controller mediates input and updates between them.",
    points: 10
  },
  {
    id: "fullstack-easy-005",
    category: "Full Stack",
    difficulty: "Easy",
    topic: "Git",
    question: "What is the purpose of the 'git clone' command?",
    options: [
      "To create a new branch in the current repository",
      "To download a copy of a remote repository to your local machine",
      "To merge two branches together",
      "To permanently delete commit history"
    ],
    correctAnswer: "To download a copy of a remote repository to your local machine",
    explanation: "'git clone' creates a full local copy of a remote repository, including its history and branches, which developers use to start working on a project.",
    points: 10
  },
  {
    id: "fullstack-easy-006",
    category: "Full Stack",
    difficulty: "Easy",
    topic: "Environment variables",
    question: "Why are environment variables commonly used in full-stack applications?",
    options: [
      "To store configuration values like API keys and database URLs outside the source code",
      "To speed up JavaScript execution at runtime",
      "To automatically format code before committing",
      "To replace the need for a database entirely"
    ],
    correctAnswer: "To store configuration values like API keys and database URLs outside the source code",
    explanation: "Environment variables let developers keep secrets and environment-specific settings (like database credentials) out of source code, which improves security and portability across dev, staging, and production.",
    points: 10
  },
  {
    id: "fullstack-easy-007",
    category: "Full Stack",
    difficulty: "Easy",
    topic: "Frontend fundamentals",
    question: "What is the main responsibility of the frontend layer in a full-stack application?",
    options: [
      "Storing data permanently on disk",
      "Rendering the user interface and handling user interactions",
      "Managing database transactions",
      "Enforcing server-side authentication logic"
    ],
    correctAnswer: "Rendering the user interface and handling user interactions",
    explanation: "The frontend runs in the browser (or client device) and is responsible for the UI, user interactions, and communicating with the backend via APIs, while the backend handles data and business logic.",
    points: 10
  },
  {
    id: "fullstack-easy-008",
    category: "Full Stack",
    difficulty: "Easy",
    topic: "Backend fundamentals",
    question: "Which of the following is a typical responsibility of the backend in a web application?",
    options: [
      "Applying CSS styles to buttons",
      "Handling business logic, database access, and authentication",
      "Managing browser DOM events",
      "Rendering animations in the browser"
    ],
    correctAnswer: "Handling business logic, database access, and authentication",
    explanation: "The backend runs on the server and is responsible for processing requests, applying business rules, interacting with databases, and handling authentication/authorization.",
    points: 10
  },
  {
    id: "fullstack-easy-009",
    category: "Full Stack",
    difficulty: "Easy",
    topic: "Databases",
    question: "What does CRUD stand for in the context of database operations?",
    options: [
      "Create, Read, Update, Delete",
      "Connect, Retrieve, Upload, Deploy",
      "Compile, Run, Undo, Debug",
      "Create, Route, Update, Deploy"
    ],
    correctAnswer: "Create, Read, Update, Delete",
    explanation: "CRUD describes the four basic operations applications perform on persistent data: Create, Read, Update, and Delete, which map naturally to HTTP methods POST, GET, PUT/PATCH, and DELETE.",
    points: 10
  },
  {
    id: "fullstack-easy-010",
    category: "Full Stack",
    difficulty: "Easy",
    topic: "Node.js",
    question: "What is Node.js primarily used for?",
    options: [
      "Running JavaScript code outside the browser, commonly for backend development",
      "Styling web pages using a CSS preprocessor",
      "Compiling Java code into bytecode",
      "Managing version control for a project"
    ],
    correctAnswer: "Running JavaScript code outside the browser, commonly for backend development",
    explanation: "Node.js is a JavaScript runtime built on Chrome's V8 engine that allows JavaScript to run on the server, enabling backend development, tooling, and scripting outside the browser.",
    points: 10
  },

  // ===================== MEDIUM (10) =====================
  {
    id: "fullstack-medium-001",
    category: "Full Stack",
    difficulty: "Medium",
    topic: "Express.js",
    question: "What is the purpose of calling 'next()' inside the middleware function below?",
    code: "app.use((req, res, next) => {\n  console.log(`${req.method} ${req.url}`);\n  next();\n});",
    language: "javascript",
    options: [
      "It sends the HTTP response back to the client",
      "It passes control to the next middleware function in the stack",
      "It terminates the Node.js process",
      "It restarts the Express server"
    ],
    correctAnswer: "It passes control to the next middleware function in the stack",
    explanation: "Calling next() hands off control to the next middleware or route handler; without it, the request would hang because no response is ever sent and the chain stops.",
    points: 20
  },
  {
    id: "fullstack-medium-002",
    category: "Full Stack",
    difficulty: "Medium",
    topic: "HTTP",
    question: "A client sends a request with an expired authentication token to a protected API endpoint. Which HTTP status code should the server return?",
    options: ["400 Bad Request", "401 Unauthorized", "403 Forbidden", "404 Not Found"],
    correctAnswer: "401 Unauthorized",
    explanation: "401 Unauthorized indicates that authentication is required or has failed (such as an expired/invalid token), whereas 403 Forbidden means the client is authenticated but lacks permission for the resource.",
    points: 20
  },
  {
    id: "fullstack-medium-003",
    category: "Full Stack",
    difficulty: "Medium",
    topic: "SQL",
    question: "Given a 'users' table and an 'orders' table linked by user_id, which SQL query correctly returns each user's name along with their total number of orders, including users with zero orders?",
    code: "-- Option being evaluated:\nSELECT u.name, COUNT(o.id) AS order_count\nFROM users u\nLEFT JOIN orders o ON u.id = o.user_id\nGROUP BY u.name;",
    language: "sql",
    options: [
      "The query is correct; LEFT JOIN keeps all users, and unmatched orders count as zero",
      "The query is incorrect; INNER JOIN must be used instead",
      "The query is incorrect; COUNT cannot be used with GROUP BY",
      "The query is incorrect; LEFT JOIN excludes users with no orders"
    ],
    correctAnswer: "The query is correct; LEFT JOIN keeps all users, and unmatched orders count as zero",
    explanation: "A LEFT JOIN keeps every row from the left table (users) even when there's no matching row in orders; COUNT(o.id) then correctly returns 0 for users with no matching orders since NULL values aren't counted.",
    points: 20
  },
  {
    id: "fullstack-medium-004",
    category: "Full Stack",
    difficulty: "Medium",
    topic: "NoSQL",
    question: "Which statement best describes a key difference between SQL and NoSQL databases?",
    options: [
      "SQL databases use a fixed schema with tables and rows, while NoSQL databases often use flexible schemas like documents or key-value pairs",
      "NoSQL databases always guarantee ACID transactions while SQL databases never do",
      "SQL databases cannot store relationships between data, but NoSQL databases can",
      "NoSQL databases are a type of SQL database optimized for joins"
    ],
    correctAnswer: "SQL databases use a fixed schema with tables and rows, while NoSQL databases often use flexible schemas like documents or key-value pairs",
    explanation: "SQL (relational) databases enforce a structured schema with defined tables and relationships, while NoSQL databases (document, key-value, column, graph) typically offer flexible or schema-less data models suited to different scaling and data-shape needs.",
    points: 20
  },
  {
    id: "fullstack-medium-005",
    category: "Full Stack",
    difficulty: "Medium",
    topic: "JWT",
    question: "In a typical JWT-based authentication flow, where is the token usually stored and sent on subsequent requests?",
    options: [
      "It is stored on the server in a session table and never sent to the client",
      "It is stored on the client (e.g., localStorage or a cookie) and sent in the Authorization header on each request",
      "It is embedded permanently in the URL of every page",
      "It is regenerated by the database on every request automatically"
    ],
    correctAnswer: "It is stored on the client (e.g., localStorage or a cookie) and sent in the Authorization header on each request",
    explanation: "After login, the server issues a signed JWT to the client, which stores it and includes it in the 'Authorization: Bearer <token>' header (or a cookie) on subsequent requests so the server can verify identity without maintaining server-side session state.",
    points: 20
  },
  {
    id: "fullstack-medium-006",
    category: "Full Stack",
    difficulty: "Medium",
    topic: "REST APIs",
    question: "You are designing a REST API for a blogging platform. Which endpoint design best follows REST conventions for fetching a single blog post with ID 42?",
    options: [
      "GET /getPost?id=42",
      "GET /posts/42",
      "POST /posts/fetch/42",
      "GET /post_fetch_by_id/42"
    ],
    correctAnswer: "GET /posts/42",
    explanation: "RESTful conventions use nouns for resource paths and identify specific resources with a path parameter, so 'GET /posts/42' cleanly maps to 'fetch the post resource with id 42' without verbs in the URL.",
    points: 20
  },
  {
    id: "fullstack-medium-007",
    category: "Full Stack",
    difficulty: "Medium",
    topic: "Node.js",
    question: "What will be logged to the console when the following Node.js code runs?",
    code: "console.log('A');\nsetTimeout(() => console.log('B'), 0);\nPromise.resolve().then(() => console.log('C'));\nconsole.log('D');",
    language: "javascript",
    options: ["A, B, C, D", "A, D, C, B", "A, D, B, C", "A, C, D, B"],
    correctAnswer: "A, D, C, B",
    explanation: "Synchronous code (A, D) runs first, then the microtask queue (Promise callback C) runs before the macrotask queue (setTimeout callback B), even with a 0ms delay.",
    points: 20
  },
  {
    id: "fullstack-medium-008",
    category: "Full Stack",
    difficulty: "Medium",
    topic: "React",
    question: "In React, what is the main difference between props and state?",
    options: [
      "Props are mutable and owned by the component; state is passed in from a parent and immutable",
      "Props are read-only data passed from a parent component; state is local, mutable data managed within a component",
      "Props and state are functionally identical and can be used interchangeably",
      "State can only be used in class components, and props only in functional components"
    ],
    correctAnswer: "Props are read-only data passed from a parent component; state is local, mutable data managed within a component",
    explanation: "Props flow one-way from parent to child and are read-only within the receiving component, while state is managed internally by a component and can change over time, triggering re-renders.",
    points: 20
  },
  {
    id: "fullstack-medium-009",
    category: "Full Stack",
    difficulty: "Medium",
    topic: "Authorization",
    question: "In the Express middleware below, what is this code primarily responsible for?",
    code: "function requireAdmin(req, res, next) {\n  if (req.user && req.user.role === 'admin') {\n    return next();\n  }\n  return res.status(403).json({ error: 'Forbidden' });\n}\n\napp.delete('/users/:id', authenticate, requireAdmin, deleteUserHandler);",
    language: "javascript",
    options: [
      "Authenticating the user by verifying their password",
      "Authorizing the request by checking that the already-authenticated user has the admin role",
      "Encrypting the user's session token before storage",
      "Validating that the :id route parameter is a valid number"
    ],
    correctAnswer: "Authorizing the request by checking that the already-authenticated user has the admin role",
    explanation: "requireAdmin runs after the authenticate middleware and checks req.user.role, which is an authorization check (what the already-identified user is allowed to do), not authentication (verifying who they are). Authentication confirms identity; authorization confirms permission.",
    points: 20
  },
  {
    id: "fullstack-medium-010",
    category: "Full Stack",
    difficulty: "Medium",
    topic: "Express.js",
    question: "Given the Express route below, what will the response body contain when a client sends 'GET /users/7'?",
    code: "app.get('/users/:id', (req, res) => {\n  res.json({ userId: req.params.id });\n});",
    language: "javascript",
    options: [
      '{ "userId": "7" }',
      '{ "userId": 7 }',
      '{ "id": "7" }',
      "An empty response body"
    ],
    correctAnswer: '{ "userId": "7" }',
    explanation: "Route parameters captured via req.params are always strings, so req.params.id for '/users/7' is the string '7', and res.json serializes it as \"userId\": \"7\" (a string, not a number).",
    points: 20
  },

  // ===================== HARD (5) =====================
  {
    id: "fullstack-hard-001",
    category: "Full Stack",
    difficulty: "Hard",
    topic: "Authentication",
    question: "When choosing between JWT-based authentication and traditional server-side sessions for a full-stack app, which tradeoff is most accurate?",
    options: [
      "JWTs are stateless and scale easily across servers but are harder to revoke immediately, while sessions require server-side storage but can be invalidated instantly",
      "Sessions are stateless and easier to scale, while JWTs always require a shared database to function",
      "JWTs and sessions are functionally identical in terms of revocation and scalability",
      "Sessions cannot be used with cookies, so JWTs are required for any cookie-based authentication"
    ],
    correctAnswer: "JWTs are stateless and scale easily across servers but are harder to revoke immediately, while sessions require server-side storage but can be invalidated instantly",
    explanation: "JWTs carry their own signed claims so any server can verify them without shared state, which aids horizontal scaling, but revoking a compromised JWT before expiry requires extra mechanisms (blocklists, short expiry). Sessions need centralized/shared storage (like Redis) but can be revoked immediately by deleting the session record.",
    points: 30
  },
  {
    id: "fullstack-hard-002",
    category: "Full Stack",
    difficulty: "Hard",
    topic: "Security",
    question: "A web application stores a user's session ID in a cookie without the HttpOnly flag, and it does not sanitize user-generated content before rendering it in the page. What attack does this combination make the application most vulnerable to, and why?",
    options: [
      "SQL Injection, because unsanitized input is always passed to database queries",
      "Cross-Site Scripting (XSS), because injected scripts can read the accessible cookie and exfiltrate the session ID",
      "Cross-Site Request Forgery (CSRF), because the cookie lacks the Secure flag",
      "DNS spoofing, because the cookie does not specify a domain attribute"
    ],
    correctAnswer: "Cross-Site Scripting (XSS), because injected scripts can read the accessible cookie and exfiltrate the session ID",
    explanation: "Without input sanitization, an attacker can inject malicious JavaScript that runs in victims' browsers (XSS); since the cookie lacks HttpOnly, that script can access document.cookie and steal the session ID, enabling session hijacking. HttpOnly cookies mitigate this by hiding the cookie from JavaScript.",
    points: 30
  },
  {
    id: "fullstack-hard-003",
    category: "Full Stack",
    difficulty: "Hard",
    topic: "Security",
    question: "The following Express/Node.js code is vulnerable to SQL injection. What is the correct fix?",
    code: "app.get('/user', (req, res) => {\n  const username = req.query.username;\n  const query = \"SELECT * FROM users WHERE username = '\" + username + \"'\";\n  db.query(query, (err, results) => {\n    res.json(results);\n  });\n});",
    language: "javascript",
    options: [
      "Use parameterized queries / prepared statements instead of string concatenation, e.g. db.query('SELECT * FROM users WHERE username = ?', [username])",
      "Rename the 'username' variable to something less predictable",
      "Switch from GET to POST for this route",
      "Wrap the query in a try/catch block to suppress SQL errors"
    ],
    correctAnswer: "Use parameterized queries / prepared statements instead of string concatenation, e.g. db.query('SELECT * FROM users WHERE username = ?', [username])",
    explanation: "Concatenating raw user input into a SQL string lets an attacker inject SQL (e.g., ' OR '1'='1). Parameterized queries send the input as data rather than executable SQL, which the database driver safely escapes, eliminating the injection vector. Renaming variables, changing HTTP methods, or catching errors do not address the root cause.",
    points: 30
  },
  {
    id: "fullstack-hard-004",
    category: "Full Stack",
    difficulty: "Hard",
    topic: "Databases",
    question: "A 'products' table with 10 million rows is frequently queried with the statement below, and it has become slow, doing a full table scan. What is the most effective first step to improve performance?",
    code: "SELECT id, name, price, created_at\nFROM products\nWHERE category_id = 42\nORDER BY created_at DESC\nLIMIT 20;",
    language: "sql",
    options: [
      "Add a composite index on (category_id, created_at) to support both the filter and the sort in one index",
      "Normalize the table further by splitting it into more tables",
      "Switch the entire database from SQL to NoSQL",
      "Increase the application server's RAM"
    ],
    correctAnswer: "Add a composite index on (category_id, created_at) to support both the filter and the sort in one index",
    explanation: "A composite index on (category_id, created_at) lets the database quickly locate rows for a given category and retrieve them already sorted by created_at, avoiding a full table scan and a separate sort step. Server RAM, further normalization, or a database migration are unrelated to this specific query pattern and are far more disruptive.",
    points: 30
  },
  {
    id: "fullstack-hard-005",
    category: "Full Stack",
    difficulty: "Hard",
    topic: "Full-stack architecture",
    question: "An API endpoint handles file uploads by reading the entire file into memory before processing, and traffic has grown to the point where the Node.js server frequently crashes with out-of-memory errors during peak load. What is the most appropriate architectural fix?",
    code: "app.post('/upload', (req, res) => {\n  let chunks = [];\n  req.on('data', (chunk) => chunks.push(chunk));\n  req.on('end', () => {\n    const fileBuffer = Buffer.concat(chunks);\n    processFile(fileBuffer);\n    res.send('Uploaded');\n  });\n});",
    language: "javascript",
    options: [
      "Stream the upload directly to disk or object storage using Node streams instead of buffering the whole file in memory",
      "Increase the Node.js server's max heap size using the --max-old-space-size flag and keep the same buffering logic",
      "Move file processing to the frontend so the server never receives the file",
      "Switch the endpoint from POST to PUT to reduce payload size"
    ],
    correctAnswer: "Stream the upload directly to disk or object storage using Node streams instead of buffering the whole file in memory",
    explanation: "Buffering entire files in memory doesn't scale with concurrent uploads or large files; using Node's streaming APIs (e.g., piping the request stream to disk or cloud storage) keeps memory usage bounded and constant regardless of file size or concurrency, which is the standard fix for this class of problem. Increasing heap size only delays the crash and doesn't solve the underlying scalability issue.",
    points: 30
  }
];
