export const cppQuestions = [
  {
    id: "cpp-easy-001",
    category: "C++",
    difficulty: "Easy",
    topic: "C++ fundamentals",
    question: "Which of the following best describes C++ as a programming language?",
    options: [
      "A purely functional programming language",
      "A multi-paradigm language that supports both procedural and object-oriented programming",
      "A markup language used for structuring web pages",
      "An interpreted scripting language with no compilation step"
    ],
    correctAnswer: "A multi-paradigm language that supports both procedural and object-oriented programming",
    explanation: "C++ supports multiple programming paradigms, including procedural, object-oriented, and generic programming, and it is a compiled language rather than an interpreted scripting language.",
    points: 10
  },
  {
    id: "cpp-easy-002",
    category: "C++",
    difficulty: "Easy",
    topic: "Variables and data types",
    question: "Which data type is typically used in C++ to store a single character such as 'A'?",
    options: ["int", "char", "string", "bool"],
    correctAnswer: "char",
    explanation: "char is the fundamental built-in type used to store a single character, usually occupying 1 byte, whereas string is a standard library class used for text made of multiple characters.",
    points: 10
  },
  {
    id: "cpp-easy-003",
    category: "C++",
    difficulty: "Easy",
    topic: "Functions",
    question: "What is the output of the following code?",
    code: "#include <iostream>\nusing namespace std;\n\nint add(int a, int b = 5) {\n    return a + b;\n}\n\nint main() {\n    cout << add(10);\n    return 0;\n}",
    language: "cpp",
    options: ["10", "15", "5", "Compilation error"],
    correctAnswer: "15",
    explanation: "Since add() is called with only one argument, the default value b = 5 is used, so the function returns 10 + 5 = 15.",
    points: 10
  },
  {
    id: "cpp-easy-004",
    category: "C++",
    difficulty: "Easy",
    topic: "Classes and objects",
    question: "What is a class in C++?",
    options: [
      "A built-in data type like int or float",
      "A user-defined blueprint or prototype from which objects are created",
      "A function that returns multiple values",
      "A loop construct used for iteration"
    ],
    correctAnswer: "A user-defined blueprint or prototype from which objects are created",
    explanation: "A class defines the data members and member functions that describe a type; an object is a concrete instance created from that class blueprint.",
    points: 10
  },
  {
    id: "cpp-easy-005",
    category: "C++",
    difficulty: "Easy",
    topic: "Constructors",
    question: "Which statement about constructors in C++ is true?",
    options: [
      "A constructor must always have a return type of void",
      "A constructor has the same name as the class and no return type",
      "A class can have only one constructor",
      "Constructors cannot accept parameters"
    ],
    correctAnswer: "A constructor has the same name as the class and no return type",
    explanation: "A constructor shares its name with the class and has no return type at all, not even void. Classes can also be overloaded with multiple constructors that take different parameters.",
    points: 10
  },
  {
    id: "cpp-easy-006",
    category: "C++",
    difficulty: "Easy",
    topic: "Destructors",
    question: "What is the correct syntax for declaring a destructor of a class named 'Box'?",
    options: ["~Box()", "delete Box()", "Box::~()", "void ~Box()"],
    correctAnswer: "~Box()",
    explanation: "A destructor is declared with a tilde followed by the class name and no parameters or return type, for example ~Box(). It is automatically called when an object goes out of scope or is deleted.",
    points: 10
  },
  {
    id: "cpp-easy-007",
    category: "C++",
    difficulty: "Easy",
    topic: "Encapsulation",
    question: "Which C++ access specifier restricts member access to only within the class itself, excluding even derived classes?",
    options: ["public", "protected", "private", "static"],
    correctAnswer: "private",
    explanation: "private members can be accessed only within the class in which they are declared, while protected members can additionally be accessed by derived classes, and public members are accessible from anywhere.",
    points: 10
  },
  {
    id: "cpp-easy-008",
    category: "C++",
    difficulty: "Easy",
    topic: "Inheritance",
    question: "What does the following program print?",
    code: "#include <iostream>\nusing namespace std;\n\nclass Animal {\npublic:\n    void sound() { cout << \"Animal sound\"; }\n};\n\nclass Dog : public Animal {\npublic:\n    void sound() { cout << \"Bark\"; }\n};\n\nint main() {\n    Dog d;\n    d.sound();\n    return 0;\n}",
    language: "cpp",
    options: ["Animal sound", "Bark", "Animal soundBark", "Compilation error"],
    correctAnswer: "Bark",
    explanation: "Dog defines its own sound() function that hides the base class version. Since sound() is called directly on a Dog object, Dog::sound() is invoked, printing 'Bark'.",
    points: 10
  },
  {
    id: "cpp-easy-009",
    category: "C++",
    difficulty: "Easy",
    topic: "Pointers",
    question: "What does the '*' symbol mean when placed before a variable name in a declaration like 'int *p'?",
    options: [
      "It declares p as an integer multiplied by another variable",
      "It declares p as a pointer that stores the address of an integer",
      "It declares p as a reference to an integer",
      "It declares p as a constant integer"
    ],
    correctAnswer: "It declares p as a pointer that stores the address of an integer",
    explanation: "The '*' in a declaration marks the variable as a pointer, meaning it holds the memory address of a value of the specified type rather than the value itself.",
    points: 10
  },
  {
    id: "cpp-easy-010",
    category: "C++",
    difficulty: "Easy",
    topic: "References",
    question: "Which statement about references in C++ is correct?",
    options: [
      "A reference must be initialized at the time it is declared",
      "A reference can be reassigned to refer to a different variable later",
      "A reference can be set to null like a pointer",
      "A reference always uses extra memory to store an address, exactly like a pointer"
    ],
    correctAnswer: "A reference must be initialized at the time it is declared",
    explanation: "Unlike pointers, references must be bound to a variable at the moment they are declared and cannot later be made to refer to a different object, and they cannot legally be null.",
    points: 10
  },
  {
    id: "cpp-medium-001",
    category: "C++",
    difficulty: "Medium",
    topic: "Constructors",
    question: "What is the output when main() runs in the following program?",
    code: "#include <iostream>\nusing namespace std;\n\nclass A {\npublic:\n    A() { cout << \"A \"; }\n    ~A() { cout << \"~A \"; }\n};\n\nclass B {\npublic:\n    B() { cout << \"B \"; }\n    ~B() { cout << \"~B \"; }\n};\n\nint main() {\n    A a;\n    B b;\n    return 0;\n}",
    language: "cpp",
    options: ["A B ~A ~B", "A B ~B ~A", "B A ~A ~B", "A ~A B ~B"],
    correctAnswer: "A B ~B ~A",
    explanation: "Local objects are constructed in the order they are declared (a then b), and destroyed in the reverse order when the enclosing scope ends, so b is destroyed before a.",
    points: 20
  },
  {
    id: "cpp-medium-002",
    category: "C++",
    difficulty: "Medium",
    topic: "Function overloading",
    question: "What is the output of the following program?",
    code: "#include <iostream>\nusing namespace std;\n\nvoid print(int x) { cout << \"int: \" << x; }\nvoid print(double x) { cout << \"double: \" << x; }\n\nint main() {\n    print(5);\n    return 0;\n}",
    language: "cpp",
    options: ["int: 5", "double: 5", "Compilation error due to ambiguity", "double: 5.0"],
    correctAnswer: "int: 5",
    explanation: "The literal 5 is an int, which is an exact match for the print(int) overload, so no implicit conversion to double is needed and that overload is selected.",
    points: 20
  },
  {
    id: "cpp-medium-003",
    category: "C++",
    difficulty: "Medium",
    topic: "Vector",
    question: "What is printed by the following code?",
    code: "#include <iostream>\n#include <vector>\nusing namespace std;\n\nint main() {\n    vector<int> v = {1, 2, 3};\n    v.push_back(4);\n    v.erase(v.begin());\n    for (int x : v) cout << x << \" \";\n    return 0;\n}",
    language: "cpp",
    options: ["1 2 3 4", "2 3 4", "1 2 3", "2 3 4 1"],
    correctAnswer: "2 3 4",
    explanation: "push_back(4) appends 4 to make {1, 2, 3, 4}, and erase(v.begin()) then removes the first element, 1, leaving {2, 3, 4}.",
    points: 20
  },
  {
    id: "cpp-medium-004",
    category: "C++",
    difficulty: "Medium",
    topic: "Map",
    question: "What is printed by the following code?",
    code: "#include <iostream>\n#include <map>\nusing namespace std;\n\nint main() {\n    map<string, int> m;\n    m[\"apple\"] = 3;\n    m[\"banana\"] = 5;\n    m[\"apple\"] = 7;\n    cout << m[\"apple\"] << \" \" << m.size();\n    return 0;\n}",
    language: "cpp",
    options: ["3 2", "7 2", "7 3", "3 3"],
    correctAnswer: "7 2",
    explanation: "Assigning m[\"apple\"] = 7 overwrites the existing value for the already-present key 'apple' rather than inserting a duplicate, so the map keeps only its 2 unique keys with 'apple' now mapped to 7.",
    points: 20
  },
  {
    id: "cpp-medium-005",
    category: "C++",
    difficulty: "Medium",
    topic: "Polymorphism",
    question: "What is the output of the following program?",
    code: "#include <iostream>\nusing namespace std;\n\nclass Base {\npublic:\n    virtual void show() { cout << \"Base\"; }\n};\n\nclass Derived : public Base {\npublic:\n    void show() override { cout << \"Derived\"; }\n};\n\nint main() {\n    Base* b = new Derived();\n    b->show();\n    delete b;\n    return 0;\n}",
    language: "cpp",
    options: ["Base", "Derived", "BaseDerived", "Compilation error"],
    correctAnswer: "Derived",
    explanation: "Because show() is declared virtual, the call through the Base pointer is resolved at runtime based on the actual object type (Derived), which is the essence of dynamic polymorphism.",
    points: 20
  },
  {
    id: "cpp-medium-006",
    category: "C++",
    difficulty: "Medium",
    topic: "Pointers",
    question: "Which of the following is a key difference between a pointer and a reference in C++?",
    options: [
      "A pointer can be reassigned to point to a different object, but a reference cannot be re-bound after initialization",
      "A reference can be null, but a pointer can never be null",
      "A pointer must always be initialized at the point of declaration, but a reference does not",
      "References support pointer arithmetic while pointers do not"
    ],
    correctAnswer: "A pointer can be reassigned to point to a different object, but a reference cannot be re-bound after initialization",
    explanation: "Pointers are variables that can be reassigned, left uninitialized, or set to null, while a reference must be bound to a valid object at initialization and continues to refer to that same object for its entire lifetime.",
    points: 20
  },
  {
    id: "cpp-medium-007",
    category: "C++",
    difficulty: "Medium",
    topic: "Operator overloading",
    question: "What is the output of the following program?",
    code: "#include <iostream>\nusing namespace std;\n\nclass Point {\npublic:\n    int x, y;\n    Point(int x, int y) : x(x), y(y) {}\n    Point operator+(const Point& p) {\n        return Point(x + p.x, y + p.y);\n    }\n};\n\nint main() {\n    Point p1(1, 2), p2(3, 4);\n    Point p3 = p1 + p2;\n    cout << p3.x << \" \" << p3.y;\n    return 0;\n}",
    language: "cpp",
    options: ["1 2", "3 4", "4 6", "Compilation error"],
    correctAnswer: "4 6",
    explanation: "The overloaded operator+ adds the corresponding x and y members of the two Point objects, producing (1+3, 2+4) which is (4, 6).",
    points: 20
  },
  {
    id: "cpp-medium-008",
    category: "C++",
    difficulty: "Medium",
    topic: "Stack",
    question: "What is printed by the following code?",
    code: "#include <iostream>\n#include <stack>\nusing namespace std;\n\nint main() {\n    stack<int> s;\n    s.push(1);\n    s.push(2);\n    s.push(3);\n    s.pop();\n    cout << s.top();\n    return 0;\n}",
    language: "cpp",
    options: ["1", "2", "3", "Compilation error"],
    correctAnswer: "2",
    explanation: "std::stack is a LIFO container. After pushing 1, 2, and 3, the top element is 3. Calling pop() removes 3, so top() now returns the next element down, which is 2.",
    points: 20
  },
  {
    id: "cpp-medium-009",
    category: "C++",
    difficulty: "Medium",
    topic: "Exception handling",
    question: "What is the output of the following program?",
    code: "#include <iostream>\nusing namespace std;\n\nint main() {\n    try {\n        throw 10;\n    } catch (double d) {\n        cout << \"double: \" << d;\n    } catch (int i) {\n        cout << \"int: \" << i;\n    }\n    return 0;\n}",
    language: "cpp",
    options: ["double: 10", "int: 10", "Compilation error", "Program terminates with an unhandled exception"],
    correctAnswer: "int: 10",
    explanation: "C++ does not implicitly convert a thrown value's type to match a catch clause; catch handlers are tried in order and matched by type, so the thrown int matches the catch (int) handler, not catch (double).",
    points: 20
  },
  {
    id: "cpp-medium-010",
    category: "C++",
    difficulty: "Medium",
    topic: "C++ interview problems",
    question: "What is the key difference between function overloading and function overriding in C++?",
    options: [
      "Overloading occurs within the same class with different parameter lists and is resolved at compile time; overriding occurs in a derived class redefining a base class virtual function and is resolved at runtime",
      "Overloading is resolved at runtime while overriding is resolved at compile time",
      "Overloading requires inheritance while overriding does not",
      "Overloading and overriding are simply two names for the same mechanism in C++"
    ],
    correctAnswer: "Overloading occurs within the same class with different parameter lists and is resolved at compile time; overriding occurs in a derived class redefining a base class virtual function and is resolved at runtime",
    explanation: "Overloading is a form of compile-time (static) polymorphism based on differing function signatures in the same scope, whereas overriding is runtime (dynamic) polymorphism achieved through virtual functions across a class hierarchy.",
    points: 20
  },
  {
    id: "cpp-hard-001",
    category: "C++",
    difficulty: "Hard",
    topic: "Polymorphism",
    question: "What is the output of the following program?",
    code: "#include <iostream>\nusing namespace std;\n\nclass Base {\npublic:\n    void show() { cout << \"Base::show \"; }\n    virtual void display() { cout << \"Base::display\"; }\n};\n\nclass Derived : public Base {\npublic:\n    void show() { cout << \"Derived::show \"; }\n    void display() override { cout << \"Derived::display\"; }\n};\n\nint main() {\n    Base* b = new Derived();\n    b->show();\n    b->display();\n    delete b;\n    return 0;\n}",
    language: "cpp",
    options: [
      "Base::show Base::display",
      "Derived::show Derived::display",
      "Base::show Derived::display",
      "Derived::show Base::display"
    ],
    correctAnswer: "Base::show Derived::display",
    explanation: "show() is not virtual, so the call is resolved statically based on the pointer's declared type (Base), calling Base::show. display() is virtual, so it is resolved dynamically through the vtable based on the actual object type (Derived), calling Derived::display.",
    points: 30
  },
  {
    id: "cpp-hard-002",
    category: "C++",
    difficulty: "Hard",
    topic: "Inheritance",
    question: "In the code below, both Mammal and Bird inherit from Animal using 'public virtual Animal'. What is the purpose of using virtual inheritance here for class Bat?",
    code: "#include <iostream>\nusing namespace std;\n\nclass Animal {\npublic:\n    void eat() { cout << \"Eating\"; }\n};\n\nclass Mammal : public virtual Animal {};\nclass Bird : public virtual Animal {};\nclass Bat : public Mammal, public Bird {};\n\nint main() {\n    Bat b;\n    b.eat();\n    return 0;\n}",
    language: "cpp",
    options: [
      "It ensures Bat contains only a single shared subobject of Animal, avoiding the ambiguity that two separate copies via Mammal and Bird would otherwise cause (the diamond problem)",
      "It makes eat() a virtual function so it can be overridden in Bat",
      "It has no effect since Bat does not directly inherit from Animal",
      "It forces Animal's constructor to run twice, once for each inheritance path"
    ],
    correctAnswer: "It ensures Bat contains only a single shared subobject of Animal, avoiding the ambiguity that two separate copies via Mammal and Bird would otherwise cause (the diamond problem)",
    explanation: "This is the classic diamond inheritance problem: without virtual inheritance, Bat would contain two distinct Animal subobjects (one via Mammal, one via Bird), making an unqualified call like b.eat() ambiguous. Virtual inheritance makes Mammal and Bird share a single Animal subobject, resolving the ambiguity.",
    points: 30
  },
  {
    id: "cpp-hard-003",
    category: "C++",
    difficulty: "Hard",
    topic: "Templates",
    question: "What is the output of the following program?",
    code: "#include <iostream>\nusing namespace std;\n\ntemplate <typename T>\nT maxVal(T a, T b) {\n    return (a > b) ? a : b;\n}\n\nint main() {\n    cout << maxVal(3, 7) << \" \" << maxVal(2.5, 1.5);\n    return 0;\n}",
    language: "cpp",
    options: [
      "7 2.5",
      "3 1.5",
      "7 1.5",
      "Compilation error because maxVal is called with different types"
    ],
    correctAnswer: "7 2.5",
    explanation: "A function template generates a distinct instantiation for each type used with it. The compiler deduces T as int for maxVal(3, 7) and T as double for maxVal(2.5, 1.5), so both calls compile and evaluate correctly, returning 7 and 2.5 respectively.",
    points: 30
  },
  {
    id: "cpp-hard-004",
    category: "C++",
    difficulty: "Hard",
    topic: "STL",
    question: "What is the average-case time complexity of insertion, deletion, and lookup for std::unordered_map, and how does it compare to std::map?",
    options: [
      "O(1) average for unordered_map, since it is implemented as a hash table, versus O(log n) for map, which is typically implemented as a balanced red-black tree",
      "O(log n) for both containers, since both are implemented as hash tables internally",
      "O(1) for both containers, since both are implemented as hash tables internally",
      "O(n) for unordered_map and O(1) for map"
    ],
    correctAnswer: "O(1) average for unordered_map, since it is implemented as a hash table, versus O(log n) for map, which is typically implemented as a balanced red-black tree",
    explanation: "std::unordered_map is backed by a hash table, giving average O(1) operations (degrading to O(n) worst case under heavy collisions), while std::map is backed by a balanced binary search tree (commonly a red-black tree), giving guaranteed O(log n) operations along with sorted key iteration order.",
    points: 30
  },
  {
    id: "cpp-hard-005",
    category: "C++",
    difficulty: "Hard",
    topic: "Exception handling",
    question: "What is the output of the following program?",
    code: "#include <iostream>\n#include <stdexcept>\nusing namespace std;\n\nclass Resource {\npublic:\n    Resource() { cout << \"Acquire \"; }\n    ~Resource() { cout << \"Release \"; }\n};\n\nvoid process() {\n    Resource r;\n    throw runtime_error(\"error\");\n}\n\nint main() {\n    try {\n        process();\n    } catch (const exception& e) {\n        cout << \"Caught: \" << e.what();\n    }\n    return 0;\n}",
    language: "cpp",
    options: [
      "Acquire Release Caught: error",
      "Acquire Caught: error",
      "Acquire (the program crashes and the destructor never runs)",
      "Release Acquire Caught: error"
    ],
    correctAnswer: "Acquire Release Caught: error",
    explanation: "This demonstrates RAII: as the exception propagates out of process() and unwinds the stack, the local object r goes out of scope and its destructor runs automatically, printing 'Release' before control reaches the catch block in main, guaranteeing cleanup even though process() never returns normally.",
    points: 30
  }
];
