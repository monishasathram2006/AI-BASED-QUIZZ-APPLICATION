export const cQuestions = [
  {
    id: "c-easy-001",
    category: "C",
    difficulty: "Easy",
    topic: "C fundamentals",
    question: "Which function is the entry point of every standalone C program?",
    options: ["start()", "main()", "init()", "run()"],
    correctAnswer: "main()",
    explanation: "Execution of a C program begins at the main() function, which the compiler and linker treat as the program's entry point.",
    points: 10
  },
  {
    id: "c-easy-002",
    category: "C",
    difficulty: "Easy",
    topic: "Data types",
    question: "Which of these is the correct format specifier to print a float value using printf?",
    options: ["%d", "%c", "%f", "%s"],
    correctAnswer: "%f",
    explanation: "%f is the format specifier used to print floating-point values with printf; %d is for int, %c for char, and %s for strings.",
    points: 10
  },
  {
    id: "c-easy-003",
    category: "C",
    difficulty: "Easy",
    topic: "Operators",
    question: "What is the result of the expression 7 % 2 in C?",
    options: ["3.5", "1", "0", "3"],
    correctAnswer: "1",
    explanation: "The modulus operator % returns the remainder of integer division; 7 divided by 2 gives quotient 3 and remainder 1.",
    points: 10
  },
  {
    id: "c-easy-004",
    category: "C",
    difficulty: "Easy",
    topic: "Control statements",
    question: "Which keyword is used to exit a loop immediately in C, skipping any remaining iterations?",
    options: ["continue", "break", "exit", "return"],
    correctAnswer: "break",
    explanation: "The break statement immediately terminates the nearest enclosing loop or switch statement, transferring control to the statement after it.",
    points: 10
  },
  {
    id: "c-easy-005",
    category: "C",
    difficulty: "Easy",
    topic: "Loops",
    question: "How many times will the loop body execute in: for (int i = 0; i < 5; i++) { }",
    options: ["4", "5", "6", "Infinite"],
    correctAnswer: "5",
    explanation: "The loop starts at i = 0 and continues while i < 5, executing for i = 0,1,2,3,4, which is 5 iterations total.",
    points: 10
  },
  {
    id: "c-easy-006",
    category: "C",
    difficulty: "Easy",
    topic: "Functions",
    question: "What does a function declaration like 'int add(int a, int b);' represent in C?",
    options: [
      "A function definition with body",
      "A function prototype specifying signature only",
      "A variable declaration",
      "A macro definition"
    ],
    correctAnswer: "A function prototype specifying signature only",
    explanation: "A statement ending in a semicolon that only lists the return type, name, and parameter types is a prototype telling the compiler the function's signature, without providing its implementation.",
    points: 10
  },
  {
    id: "c-easy-007",
    category: "C",
    difficulty: "Easy",
    topic: "Arrays",
    question: "In C, what is the index of the first element of an array declared as int arr[10]?",
    options: ["1", "0", "-1", "10"],
    correctAnswer: "0",
    explanation: "C arrays are zero-indexed, so the first element is arr[0] and the last valid element is arr[9] for a 10-element array.",
    points: 10
  },
  {
    id: "c-easy-008",
    category: "C",
    difficulty: "Easy",
    topic: "Strings",
    question: "Which character does the C compiler automatically append to the end of a string literal?",
    options: ["Space character ' '", "Newline '\\n'", "Null character '\\0'", "EOF"],
    correctAnswer: "Null character '\\0'",
    explanation: "String literals in C are stored as arrays of characters terminated by a null character '\\0', which library functions use to detect the end of the string.",
    points: 10
  },
  {
    id: "c-easy-009",
    category: "C",
    difficulty: "Easy",
    topic: "Pointers",
    question: "What does the '&' operator do when applied to a variable in C?",
    options: [
      "Dereferences a pointer",
      "Returns the address of the variable",
      "Performs bitwise AND",
      "Declares a reference variable"
    ],
    correctAnswer: "Returns the address of the variable",
    explanation: "The unary '&' operator, called the address-of operator, yields the memory address of its operand, which is commonly stored in a pointer variable.",
    points: 10
  },
  {
    id: "c-easy-010",
    category: "C",
    difficulty: "Easy",
    topic: "C fundamentals",
    question: "What will the following code print?",
    code: "int x = 5;\nprintf(\"%d\", x++);",
    language: "c",
    options: ["4", "5", "6", "Compilation error"],
    correctAnswer: "5",
    explanation: "The post-increment operator x++ returns the current value of x (5) before incrementing it, so 5 is printed even though x becomes 6 afterward.",
    points: 10
  },
  {
    id: "c-medium-001",
    category: "C",
    difficulty: "Medium",
    topic: "Pointers",
    question: "What will the following code print?",
    code: "int arr[] = {10, 20, 30, 40};\nint *p = arr;\nprintf(\"%d\", *(p + 2));",
    language: "c",
    options: ["10", "20", "30", "Address of arr[2]"],
    correctAnswer: "30",
    explanation: "Pointer arithmetic p + 2 moves the pointer two int-sized steps forward from the base address, and dereferencing it accesses arr[2], which is 30.",
    points: 20
  },
  {
    id: "c-medium-002",
    category: "C",
    difficulty: "Medium",
    topic: "Strings",
    question: "What is the output of the following program?",
    code: "char str[] = \"Hello\";\nprintf(\"%d\", (int)strlen(str));",
    language: "c",
    options: ["4", "5", "6", "Undefined"],
    correctAnswer: "5",
    explanation: "strlen() counts characters up to but excluding the terminating null character, and \"Hello\" has 5 visible characters, so it returns 5.",
    points: 20
  },
  {
    id: "c-medium-003",
    category: "C",
    difficulty: "Medium",
    topic: "Storage classes",
    question: "What value is printed by the second call to the function below?",
    code: "void counter() {\n    static int count = 0;\n    count++;\n    printf(\"%d \", count);\n}\nint main() {\n    counter();\n    counter();\n    return 0;\n}",
    language: "c",
    options: ["0 then 0", "1 then 1", "1 then 2", "0 then 1"],
    correctAnswer: "1 then 2",
    explanation: "A static local variable is initialized only once and retains its value across function calls, so count becomes 1 on the first call and 2 on the second.",
    points: 20
  },
  {
    id: "c-medium-004",
    category: "C",
    difficulty: "Medium",
    topic: "Recursion",
    question: "What does the following recursive function return when called as factorial(4)?",
    code: "int factorial(int n) {\n    if (n <= 1)\n        return 1;\n    return n * factorial(n - 1);\n}",
    language: "c",
    options: ["12", "16", "24", "4"],
    correctAnswer: "24",
    explanation: "factorial(4) computes 4 * factorial(3) = 4 * 3 * factorial(2) = 4 * 3 * 2 * factorial(1), which unwinds to 4 * 3 * 2 * 1 = 24.",
    points: 20
  },
  {
    id: "c-medium-005",
    category: "C",
    difficulty: "Medium",
    topic: "Structures",
    question: "In the following code, what is printed?",
    code: "struct Point {\n    int x;\n    int y;\n};\nint main() {\n    struct Point p1 = {3, 4};\n    struct Point p2 = p1;\n    p2.x = 10;\n    printf(\"%d %d\", p1.x, p2.x);\n    return 0;\n}",
    language: "c",
    options: ["10 10", "3 10", "3 3", "10 3"],
    correctAnswer: "3 10",
    explanation: "Assigning one struct to another (p2 = p1) copies all member values into a separate memory location, so modifying p2.x does not affect p1.x, leaving p1.x as 3 and p2.x as 10.",
    points: 20
  },
  {
    id: "c-medium-006",
    category: "C",
    difficulty: "Medium",
    topic: "Dynamic memory allocation",
    question: "Find the bug in the following code intended to allocate memory for 5 integers.",
    code: "int *arr = (int *) malloc(5);\nfor (int i = 0; i < 5; i++) {\n    arr[i] = i;\n}",
    language: "c",
    options: [
      "malloc should not be cast",
      "malloc(5) allocates only 5 bytes, not 5 integers; it should be malloc(5 * sizeof(int))",
      "The for loop condition should be i <= 5",
      "arr should be declared as int arr[5] instead"
    ],
    correctAnswer: "malloc(5) allocates only 5 bytes, not 5 integers; it should be malloc(5 * sizeof(int))",
    explanation: "malloc() takes a size in bytes, so malloc(5) reserves only 5 bytes; writing 5 ints (typically 20 bytes) overflows the allocation, causing undefined behavior. The correct call is malloc(5 * sizeof(int)).",
    points: 20
  },
  {
    id: "c-medium-007",
    category: "C",
    difficulty: "Medium",
    topic: "Preprocessor",
    question: "What is printed by the following code using a macro?",
    code: "#define SQUARE(x) x * x\nint main() {\n    int result = 100 / SQUARE(5);\n    printf(\"%d\", result);\n    return 0;\n}",
    language: "c",
    options: ["4", "100", "20", "0"],
    correctAnswer: "100",
    explanation: "Because SQUARE(x) expands textually to x * x without protective parentheses, 100 / SQUARE(5) becomes 100 / 5 * 5, which evaluates left to right as (100 / 5) * 5 = 100; this demonstrates why macro arguments and the whole expansion should be wrapped in parentheses.",
    points: 20
  },
  {
    id: "c-medium-008",
    category: "C",
    difficulty: "Medium",
    topic: "Unions",
    question: "What is a key difference between a union and a structure in C?",
    options: [
      "A union can have member functions while a structure cannot",
      "All members of a union share the same memory location, while structure members each get their own memory",
      "A structure can only hold one data type, while a union can hold multiple types simultaneously",
      "Unions cannot be used with pointers"
    ],
    correctAnswer: "All members of a union share the same memory location, while structure members each get their own memory",
    explanation: "In a union, all members overlap in the same memory block sized to the largest member, so writing to one member overwrites the others; in a structure, each member has distinct, separate storage.",
    points: 20
  },
  {
    id: "c-medium-009",
    category: "C",
    difficulty: "Medium",
    topic: "Arrays",
    question: "What does the following code print?",
    code: "int arr[5] = {1, 2, 3};\nprintf(\"%d %d\", arr[3], arr[4]);",
    language: "c",
    options: ["Garbage values", "0 0", "3 4", "Compilation error"],
    correctAnswer: "0 0",
    explanation: "When an array is partially initialized with an initializer list, the C standard guarantees that all remaining elements are zero-initialized, so arr[3] and arr[4] are both 0.",
    points: 20
  },
  {
    id: "c-medium-010",
    category: "C",
    difficulty: "Medium",
    topic: "Functions",
    question: "In C, when an array is passed to a function as a parameter, what is actually passed?",
    options: [
      "A full copy of the array",
      "A pointer to the first element of the array",
      "The array's length only",
      "Nothing; arrays cannot be passed to functions"
    ],
    correctAnswer: "A pointer to the first element of the array",
    explanation: "C does not pass arrays by value; instead, the array decays into a pointer to its first element, which means the function operates on the original array's memory and array size information is lost inside the function.",
    points: 20
  },
  {
    id: "c-hard-001",
    category: "C",
    difficulty: "Hard",
    topic: "Pointers",
    question: "What does the following program print?",
    code: "int a = 10;\nint *p = &a;\nint **pp = &p;\n**pp = 20;\nprintf(\"%d %d\", a, *p);",
    language: "c",
    options: ["10 10", "20 20", "10 20", "20 10"],
    correctAnswer: "20 20",
    explanation: "pp is a pointer to a pointer holding the address of p; *pp dereferences to get p, and **pp dereferences again to reach a, so assigning **pp = 20 changes a itself, and both a and *p (which reads a through p) become 20.",
    points: 30
  },
  {
    id: "c-hard-002",
    category: "C",
    difficulty: "Hard",
    topic: "Dynamic memory allocation",
    question: "What is the primary danger illustrated by the following code?",
    code: "int *ptr = (int *) malloc(sizeof(int));\n*ptr = 5;\nfree(ptr);\nfree(ptr);",
    language: "c",
    options: [
      "Memory leak because malloc was never matched with free",
      "Double free: freeing the same pointer twice, which causes undefined behavior and can corrupt the heap",
      "Dangling pointer because ptr was never initialized",
      "Stack overflow due to repeated allocation"
    ],
    correctAnswer: "Double free: freeing the same pointer twice, which causes undefined behavior and can corrupt the heap",
    explanation: "Calling free() twice on the same pointer is a double-free bug; it corrupts the heap's internal bookkeeping structures and results in undefined behavior, potentially crashing the program or creating a security vulnerability.",
    points: 30
  },
  {
    id: "c-hard-003",
    category: "C",
    difficulty: "Hard",
    topic: "Structures",
    question: "Given a 32-bit system where int is 4 bytes and char is 1 byte, what is the most likely sizeof(struct S) due to structure padding?",
    code: "struct S {\n    char a;\n    int b;\n    char c;\n};",
    language: "c",
    options: ["6", "9", "12", "5"],
    correctAnswer: "12",
    explanation: "To satisfy alignment requirements, the compiler inserts 3 padding bytes after 'a' so 'b' starts on a 4-byte boundary, and 3 trailing padding bytes after 'c' so the struct's total size is a multiple of its largest member's alignment (4), giving 1+3+4+1+3 = 12 bytes.",
    points: 30
  },
  {
    id: "c-hard-004",
    category: "C",
    difficulty: "Hard",
    topic: "Memory management",
    question: "What problem does the function below have, and what does it return?",
    code: "int *createArray() {\n    int local[5] = {1, 2, 3, 4, 5};\n    return local;\n}",
    language: "c",
    options: [
      "It correctly returns a valid pointer to the array",
      "It returns a dangling pointer because 'local' is a stack-allocated array that is destroyed when the function returns",
      "It causes a compilation error because arrays cannot be returned",
      "It causes a memory leak because 'local' is never freed"
    ],
    correctAnswer: "It returns a dangling pointer because 'local' is a stack-allocated array that is destroyed when the function returns",
    explanation: "local is a local (automatic) array stored on the stack, and its memory becomes invalid once createArray() returns, so the returned pointer is dangling; accessing it afterward is undefined behavior. The fix is to use dynamic allocation (malloc) or a static array instead.",
    points: 30
  },
  {
    id: "c-hard-005",
    category: "C",
    difficulty: "Hard",
    topic: "Recursion",
    question: "Consider the recursive Fibonacci function below. What is the primary reason this implementation performs poorly for larger values of n, such as n = 40?",
    code: "int fib(int n) {\n    if (n <= 1)\n        return n;\n    return fib(n - 1) + fib(n - 2);\n}",
    language: "c",
    options: [
      "It causes a stack overflow immediately for any n greater than 10",
      "It has exponential time complexity because it recomputes the same subproblems repeatedly, without memoization",
      "It causes integer overflow for all values of n",
      "The compiler cannot optimize recursive functions at all, making it always slower than iteration"
    ],
    correctAnswer: "It has exponential time complexity because it recomputes the same subproblems repeatedly, without memoization",
    explanation: "This naive recursive Fibonacci recomputes overlapping subproblems (e.g., fib(38) is computed independently within both fib(39) and fib(40) branches), leading to roughly O(2^n) time; using memoization or an iterative approach reduces this to O(n).",
    points: 30
  }
];
