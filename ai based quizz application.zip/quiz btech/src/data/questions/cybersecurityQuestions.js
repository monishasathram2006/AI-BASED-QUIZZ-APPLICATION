export const cybersecurityQuestions = [
  {
    id: "cyber-easy-001",
    category: "Cybersecurity",
    difficulty: "Easy",
    topic: "Security Principles",
    question: "What three foundational pillars constitute the 'CIA Triad' of information security?",
    options: [
      "Confidentiality, Integrity, and Availability",
      "Control, Inspection, and Auditing",
      "Cryptography, Identity, and Authentication",
      "Compliance, Interoperability, and Agility"
    ],
    correctAnswer: "Confidentiality, Integrity, and Availability",
    explanation: "The CIA triad guides information security policies: Confidentiality ensures data is concealed from unauthorized entities, Integrity guarantees data is uncorrupted, and Availability ensures authorized users have timely access.",
    points: 10
  },
  {
    id: "cyber-easy-002",
    category: "Cybersecurity",
    difficulty: "Easy",
    topic: "Web Vulnerabilities",
    question: "What is an SQL Injection (SQLi) attack?",
    options: [
      "Malicious SQL code inserted into user input fields that tricks the database into executing unintended commands",
      "Injecting virus binaries into a SQL database backup file",
      "Overloading the database server with excessive SELECT queries",
      "Changing the database table names from uppercase to lowercase"
    ],
    correctAnswer: "Malicious SQL code inserted into user input fields that tricks the database into executing unintended commands",
    explanation: "SQLi occurs when untrusted user input is directly concatenated into database queries without parameterization or escaping, allowing attackers to view, modify, or delete database contents.",
    points: 10
  },
  {
    id: "cyber-easy-003",
    category: "Cybersecurity",
    difficulty: "Easy",
    topic: "Social Engineering",
    question: "What is Phishing?",
    options: [
      "A deceptive social engineering attack where an adversary poses as a legitimate institution to trick individuals into divulging sensitive data or credentials",
      "Scanning a network for open TCP ports",
      "Brute-forcing an SSH password using dictionaries",
      "Injecting advertising banners into browser sessions"
    ],
    correctAnswer: "A deceptive social engineering attack where an adversary poses as a legitimate institution to trick individuals into divulging sensitive data or credentials",
    explanation: "Phishing emails, fake login portals, and spoofed messages trick victims into revealing passwords, credit card numbers, or installing trojans under the guise of an authentic trusted party.",
    points: 10
  },
  {
    id: "cyber-easy-004",
    category: "Cybersecurity",
    difficulty: "Easy",
    topic: "Authentication",
    question: "Which of the following constitutes true Multi-Factor Authentication (MFA)?",
    options: [
      "Requiring credentials from two distinct authentication factor categories (e.g. something you know like a password, and something you have like a hardware token)",
      "Entering two different passwords in sequence",
      "Entering a password and answering two security questions",
      "Logging in from two different browser tabs simultaneously"
    ],
    correctAnswer: "Requiring credentials from two distinct authentication factor categories (e.g. something you know like a password, and something you have like a hardware token)",
    explanation: "MFA requires factors from different categories: Knowledge (something you know), Possession (something you have), or Inherence (something you are - biometrics). Two passwords are just two items from the same factor.",
    points: 10
  },
  {
    id: "cyber-easy-005",
    category: "Cybersecurity",
    difficulty: "Easy",
    topic: "Cryptography Basics",
    question: "What is the key difference between Symmetric and Asymmetric encryption?",
    options: [
      "Symmetric encryption uses a single shared secret key for both encryption and decryption; Asymmetric uses a mathematically paired public key and private key",
      "Symmetric encryption is unhackable while asymmetric is easy to break",
      "Asymmetric encryption can only encrypt single numbers",
      "Symmetric encryption requires Internet access to decrypt"
    ],
    correctAnswer: "Symmetric encryption uses a single shared secret key for both encryption and decryption; Asymmetric uses a mathematically paired public key and private key",
    explanation: "In symmetric ciphers (AES), sender and receiver share one key. In asymmetric ciphers (RSA, ECC), anyone can encrypt with the public key, but only the private key holder can decrypt.",
    points: 10
  },
  {
    id: "cyber-easy-006",
    category: "Cybersecurity",
    difficulty: "Easy",
    topic: "Web Vulnerabilities",
    question: "What is Cross-Site Scripting (XSS)?",
    options: [
      "A vulnerability that allows attackers to inject malicious scripts into trusted web pages viewed by other users",
      "A technique to bypass SQL database authentication using cookies",
      "A denial of service attack that crashes server operating systems",
      "A tool to convert JavaScript code into C++"
    ],
    correctAnswer: "A vulnerability that allows attackers to inject malicious scripts into trusted web pages viewed by other users",
    explanation: "XSS occurs when an application includes untrusted data in a web page without proper escaping, allowing arbitrary JavaScript to execute in victim browsers to steal session tokens or deface content.",
    points: 10
  },
  {
    id: "cyber-easy-007",
    category: "Cybersecurity",
    difficulty: "Easy",
    topic: "Network Defense",
    question: "What is the primary function of a Network Firewall?",
    options: [
      "Inspecting incoming and outgoing network traffic and permitting or blocking packets based on established security rules",
      "Speeding up internet bandwidth for authorized workstations",
      "Automatically backing up hard drives during lightning strikes",
      "Encrypting hard disk drives when computers sleep"
    ],
    correctAnswer: "Inspecting incoming and outgoing network traffic and permitting or blocking packets based on established security rules",
    explanation: "Firewalls establish a barrier between trusted internal networks and untrusted external networks (like the public Internet), filtering traffic by IP address, port, and protocol rules.",
    points: 10
  },
  {
    id: "cyber-easy-008",
    category: "Cybersecurity",
    difficulty: "Easy",
    topic: "Malware",
    question: "What defines Ransomware malware?",
    options: [
      "Malicious software that encrypts victim files and data storage, demanding extortion payment to provide the decryption key",
      "A script that displays pop-up advertisements in browser windows",
      "A worm that turns the computer screen into a screensaver",
      "A utility that secretly mines Bitcoin on idle CPUs"
    ],
    correctAnswer: "Malicious software that encrypts victim files and data storage, demanding extortion payment to provide the decryption key",
    explanation: "Ransomware locks down digital assets using strong asymmetric/symmetric cryptography, holding corporate and personal systems hostage until a cryptocurrency ransom is paid.",
    points: 10
  },
  {
    id: "cyber-easy-009",
    category: "Cybersecurity",
    difficulty: "Easy",
    topic: "Denial of Service",
    question: "What differentiates a DDoS (Distributed Denial of Service) attack from a standard DoS attack?",
    options: [
      "A DDoS attack originates from thousands of compromised machines (botnets) distributed globally, making IP-based blocking far more difficult",
      "A DDoS attack uses quantum computers",
      "A DDoS attack only targets mobile phones",
      "A DDoS attack requires physical access to the server room"
    ],
    correctAnswer: "A DDoS attack originates from thousands of compromised machines (botnets) distributed globally, making IP-based blocking far more difficult",
    explanation: "DoS uses a single attacking host, easily filtered by IP. DDoS coordinates vast botnets of infected endpoints, overwhelming bandwidth and compute resources from thousands of distinct addresses.",
    points: 10
  },
  {
    id: "cyber-easy-010",
    category: "Cybersecurity",
    difficulty: "Easy",
    topic: "Password Security",
    question: "Why should passwords stored in databases always be hashed with a unique cryptographic 'Salt'?",
    options: [
      "To prevent attackers from using precomputed Rainbow Tables and to ensure users with identical passwords produce completely different hash outputs",
      "To compress passwords to 8 characters",
      "To allow administrators to easily decrypt passwords when users forget them",
      "To format passwords in alphabetical order"
    ],
    correctAnswer: "To prevent attackers from using precomputed Rainbow Tables and to ensure users with identical passwords produce completely different hash outputs",
    explanation: "A salt is a cryptographically random string concatenated to passwords before hashing. It invalidates precomputed lookup tables (rainbow tables) and guarantees identical passwords yield distinct hashes.",
    points: 10
  },
  {
    id: "cyber-medium-001",
    category: "Cybersecurity",
    difficulty: "Medium",
    topic: "Web Vulnerabilities",
    question: "How does a Cross-Site Request Forgery (CSRF) attack work, and how do Anti-CSRF Tokens defend against it?",
    options: [
      "CSRF exploits the browser's automatic inclusion of session cookies with cross-site requests; unique unpredictable Anti-CSRF tokens validate that the request originated intentionally from the trusted site",
      "CSRF steals the user's password from local storage; tokens encrypt the keyboard strokes",
      "CSRF shuts down the web server; tokens restart the service automatically",
      "CSRF injects SQL queries into URL parameters; tokens sanitize the input"
    ],
    correctAnswer: "CSRF exploits the browser's automatic inclusion of session cookies with cross-site requests; unique unpredictable Anti-CSRF tokens validate that the request originated intentionally from the trusted site",
    explanation: "Browsers attach cookies automatically to requests. In CSRF, a malicious site tricks the browser into sending an authenticated state-changing action. Anti-CSRF tokens ensure requests contain a secret value untrusted sites cannot access.",
    points: 20
  },
  {
    id: "cyber-medium-002",
    category: "Cybersecurity",
    difficulty: "Medium",
    topic: "Public Key Infrastructure",
    question: "What is the role of a Certificate Authority (CA) in Public Key Infrastructure (PKI)?",
    options: [
      "A trusted third party that cryptographically signs digital certificates to verify the ownership and identity of a public key and domain",
      "A government agency that regulates database schema formats",
      "A software service that decrypts all Internet traffic for national monitoring",
      "A server that assigns dynamic IP addresses to home Wi-Fi routers"
    ],
    correctAnswer: "A trusted third party that cryptographically signs digital certificates to verify the ownership and identity of a public key and domain",
    explanation: "CAs prevent Man-in-the-Middle impersonation. Browsers trust root CA certificates installed in their trust store to validate that a website's public key genuinely belongs to the domain operator.",
    points: 20
  },
  {
    id: "cyber-medium-003",
    category: "Cybersecurity",
    difficulty: "Medium",
    topic: "Browser Security",
    question: "What is the Same-Origin Policy (SOP) in modern web browsers?",
    options: [
      "A critical security mechanism that restricts scripts on one origin (protocol, domain, port) from accessing sensitive DOM or data on a different origin",
      "A rule that all web servers must be hosted in the same physical country",
      "A browser setting that requires all images to be PNG format",
      "A policy requiring all websites to have identical CSS font styles"
    ],
    correctAnswer: "A critical security mechanism that restricts scripts on one origin (protocol, domain, port) from accessing sensitive DOM or data on a different origin",
    explanation: "SOP isolates distinct websites. A malicious script loaded on evil.com cannot read cookies, local storage, or XMLHttpRequest response bodies belonging to yourbank.com unless CORS headers explicitly permit it.",
    points: 20
  },
  {
    id: "cyber-medium-004",
    category: "Cybersecurity",
    difficulty: "Medium",
    topic: "Network Attacks",
    question: "How does ARP Spoofing (Poisoning) enable a Man-in-the-Middle (MitM) attack on a local area network?",
    options: [
      "An attacker sends forged ARP replies linking their own MAC address with the IP address of the legitimate default gateway, diverting LAN traffic through the attacker's machine",
      "An attacker floods DNS root servers with UDP amplification traffic",
      "An attacker cracks WPA3 passwords using dictionary attacks",
      "An attacker alters physical Ethernet copper wire layout"
    ],
    correctAnswer: "An attacker sends forged ARP replies linking their own MAC address with the IP address of the legitimate default gateway, diverting LAN traffic through the attacker's machine",
    explanation: "ARP is stateless and does not authenticate replies. By repeatedly sending unsolicited ARP packets, an attacker corrupts the ARP cache of victims, tricking them into forwarding all outbound traffic to the attacker.",
    points: 20
  },
  {
    id: "cyber-medium-005",
    category: "Cybersecurity",
    difficulty: "Medium",
    topic: "Web Security Headers",
    question: "What does the Content Security Policy (CSP) HTTP response header provide to web applications?",
    options: [
      "An allowlist of trusted domains and sources from which scripts, styles, images, and frames can be loaded and executed, mitigating XSS attacks",
      "A list of database usernames allowed to log in",
      "A directive that forces browsers to delete cookies after 5 minutes",
      "A policy setting the maximum size of uploaded files"
    ],
    correctAnswer: "An allowlist of trusted domains and sources from which scripts, styles, images, and frames can be loaded and executed, mitigating XSS attacks",
    explanation: "CSP restricts where scripts and assets can load from and disables dangerous inline scripts (`eval`, `<script>` tags without nonces), effectively neutering injected XSS payloads.",
    points: 20
  },
  {
    id: "cyber-medium-006",
    category: "Cybersecurity",
    difficulty: "Medium",
    topic: "Cryptographic Primitives",
    question: "What is 'Pre-image Resistance' in cryptographic hash functions (such as SHA-256)?",
    options: [
      "Given a hash output h, it is computationally infeasible to find any input x such that hash(x) = h",
      "Finding two distinct inputs that produce the same hash output",
      "Ensuring small changes to the input produce identical hash outputs",
      "Reversing the hash function using matrix inversion"
    ],
    correctAnswer: "Given a hash output h, it is computationally infeasible to find any input x such that hash(x) = h",
    explanation: "Pre-image resistance (one-way property) ensures that an attacker possessing a hash digest cannot mathematically compute the original plaintext input that generated it.",
    points: 20
  },
  {
    id: "cyber-medium-007",
    category: "Cybersecurity",
    difficulty: "Medium",
    topic: "Access Control",
    question: "How does Attribute-Based Access Control (ABAC) differ from Role-Based Access Control (RBAC)?",
    options: [
      "ABAC evaluates contextual attributes (user role, department, time of day, location, resource sensitivity) dynamically, whereas RBAC assigns permissions strictly based on predefined static user roles",
      "ABAC only works on Windows servers",
      "RBAC is dynamic while ABAC cannot use boolean logic",
      "RBAC encrypts data while ABAC only compresses it"
    ],
    correctAnswer: "ABAC evaluates contextual attributes (user role, department, time of day, location, resource sensitivity) dynamically, whereas RBAC assigns permissions strictly based on predefined static user roles",
    explanation: "RBAC is simple and assigns permissions to roles (Admin, Editor). ABAC provides fine-grained, dynamic policy rules based on combinations of subject, action, resource, and environmental context.",
    points: 20
  },
  {
    id: "cyber-medium-008",
    category: "Cybersecurity",
    difficulty: "Medium",
    topic: "Auth Protocols",
    question: "What is the relationship between OAuth 2.0 and OpenID Connect (OIDC)?",
    options: [
      "OAuth 2.0 is an Authorization framework providing access tokens; OpenID Connect is an Identity layer built on top of OAuth 2.0 providing authentication via ID tokens (JWT)",
      "OAuth 2.0 is for passwords; OIDC is for credit card payments",
      "OIDC is deprecated and replaced entirely by SAML 1.0",
      "They are two unrelated symmetric encryption ciphers"
    ],
    correctAnswer: "OAuth 2.0 is an Authorization framework providing access tokens; OpenID Connect is an Identity layer built on top of OAuth 2.0 providing authentication via ID tokens (JWT)",
    explanation: "OAuth 2.0 only authorizes API scopes (what a client can do). OIDC standardizes authentication (who the user is), adding a signed ID Token (JWT) and a /userinfo endpoint.",
    points: 20
  },
  {
    id: "cyber-medium-009",
    category: "Cybersecurity",
    difficulty: "Medium",
    topic: "Network Defense",
    question: "How does an Intrusion Prevention System (IPS) differ operationally from an Intrusion Detection System (IDS)?",
    options: [
      "An IPS is deployed in-line and actively drops or blocks malicious packets in real time, whereas an IDS monitors passively and generates alerts without terminating traffic",
      "An IDS modifies firewall hardware while an IPS only logs DNS requests",
      "An IPS cannot inspect application layer protocols",
      "An IDS requires manual reboots after every blocked packet"
    ],
    correctAnswer: "An IPS is deployed in-line and actively drops or blocks malicious packets in real time, whereas an IDS monitors passively and generates alerts without terminating traffic",
    explanation: "An IDS (like Snort in tap mode) passively inspects mirrored traffic and alerts administrators. An IPS sits directly in the traffic flow and can automatically drop packets, reset connections, or blacklist IPs.",
    points: 20
  },
  {
    id: "cyber-medium-010",
    category: "Cybersecurity",
    difficulty: "Medium",
    topic: "Cookie Security",
    question: "What protection does the 'HttpOnly' flag on session cookies provide against cyber attacks?",
    options: [
      "It prevents clientside JavaScript (document.cookie) from accessing the cookie, thwarting cookie-stealing XSS attacks",
      "It enforces TLS encryption across all network hops",
      "It restricts the cookie to subdomains only",
      "It automatically deletes the cookie after 30 seconds"
    ],
    correctAnswer: "It prevents clientside JavaScript (document.cookie) from accessing the cookie, thwarting cookie-stealing XSS attacks",
    explanation: "By setting HttpOnly, browsers hide the cookie from `document.cookie` scripts. Even if an attacker successfully injects and runs malicious XSS JavaScript, they cannot extract the user's session cookie.",
    points: 20
  },
  {
    id: "cyber-hard-001",
    category: "Cybersecurity",
    difficulty: "Hard",
    topic: "Cryptography",
    question: "What is 'Perfect Forward Secrecy' (PFS) in secure communication protocols like TLS and Signal?",
    options: [
      "A property where compromise of a server's long-term private key does not compromise past session keys or allow decryption of previously recorded ciphertexts",
      "A technique that guarantees quantum computers can never factor prime numbers",
      "A hash function that produces outputs larger than 1024 bits",
      "An algorithm that changes IP addresses every millisecond"
    ],
    correctAnswer: "A property where compromise of a server's long-term private key does not compromise past session keys or allow decryption of previously recorded ciphertexts",
    explanation: "PFS uses ephemeral Diffie-Hellman key exchanges (ECDHE). Unique, temporary session keys are negotiated for every connection and discarded immediately afterward, rendering past wiretapped traffic undecryptable.",
    points: 30
  },
  {
    id: "cyber-hard-002",
    category: "Cybersecurity",
    difficulty: "Hard",
    topic: "Binary Exploitation",
    question: "How does Address Space Layout Randomization (ASLR) defend against Buffer Overflow code execution exploits?",
    options: [
      "By randomizing the memory locations of the stack, heap, and libraries on program execution, making fixed hardcoded return addresses and shellcode jump targets unpredictable",
      "By encrypting CPU registers with AES-256",
      "By preventing programs from allocating more than 4KB of RAM",
      "By compiling C code without pointer arithmetic"
    ],
    correctAnswer: "By randomizing the memory locations of the stack, heap, and libraries on program execution, making fixed hardcoded return addresses and shellcode jump targets unpredictable",
    explanation: "Traditional buffer overflows overwrite the return address with a known static address in memory. ASLR shuffles base addresses of binary sections on every execution, causing hardcoded jumps to crash instead of running shellcode.",
    points: 30
  },
  {
    id: "cyber-hard-003",
    category: "Cybersecurity",
    difficulty: "Hard",
    topic: "Web Vulnerabilities",
    question: "In Server-Side Request Forgery (SSRF) attacks against cloud-hosted applications (AWS/GCP), what is the typical critical target abused by attackers?",
    options: [
      "The internal Instance Metadata Service (IMDS, e.g. http://169.254.169.254/) to steal temporary IAM role credentials and security tokens",
      "The client's local browser bookmarks file",
      "The physical CPU cooling fans inside the rack",
      "Public Wikipedia articles"
    ],
    correctAnswer: "The internal Instance Metadata Service (IMDS, e.g. http://169.254.169.254/) to steal temporary IAM role credentials and security tokens",
    explanation: "SSRF tricks the backend server into sending requests to internal URLs. Cloud instances query the non-routable link-local address 169.254.169.254 for instance metadata, which exposes sensitive temporary IAM credentials if SSRF succeeds.",
    points: 30
  },
  {
    id: "cyber-hard-004",
    category: "Cybersecurity",
    difficulty: "Hard",
    topic: "Side-Channel Attacks",
    question: "Why must cryptographic Message Authentication Code (MAC) comparisons and password verification always be performed using Constant-Time comparison algorithms?",
    options: [
      "Standard string comparisons terminate early on the first non-matching byte, leaking timing information that enables an attacker to deduce the secret byte-by-byte",
      "Constant-time algorithms execute in zero milliseconds",
      "CPUs require constant-time comparisons to prevent hardware overclocking",
      "Variable-time comparisons throw unhandled segmentation faults"
    ],
    correctAnswer: "Standard string comparisons terminate early on the first non-matching byte, leaking timing information that enables an attacker to deduce the secret byte-by-byte",
    explanation: "In a timing side-channel attack, subtle nanosecond differences reveal how many leading bytes matched before early return. Constant-time algorithms (like `crypto.timingSafeEqual`) always inspect every byte regardless of match.",
    points: 30
  },
  {
    id: "cyber-hard-005",
    category: "Cybersecurity",
    difficulty: "Hard",
    topic: "Cryptographic Attacks",
    question: "Based on the Birthday Paradox, what is the approximate number of random hash trials required to find a collision in an n-bit cryptographic hash function?",
    options: [
      "O(2^(n/2)) hash operations",
      "O(2^n) hash operations",
      "O(n^2) hash operations",
      "O(n log n) hash operations"
    ],
    correctAnswer: "O(2^(n/2)) hash operations",
    explanation: "While finding a specific pre-image takes 2^n operations, finding ANY two messages with the same hash (collision) requires only ~2^(n/2) operations due to the birthday paradox. Hence, 128-bit hashes provide only 64 bits of collision resistance.",
    points: 30
  }
];
