export const cloudDevOpsQuestions = [
  {
    id: "cloud-easy-001",
    category: "Cloud & DevOps",
    difficulty: "Easy",
    topic: "Cloud Fundamentals",
    question: "What is the difference between IaaS, PaaS, and SaaS in cloud computing?",
    options: [
      "IaaS provides raw infrastructure (VMs, storage); PaaS provides runtime platforms for code; SaaS delivers fully managed ready-to-use software",
      "IaaS is for mobile apps; PaaS is for desktop apps; SaaS is for web apps",
      "SaaS provides physical servers; IaaS provides web browsers",
      "They are identical terms for virtual machines"
    ],
    correctAnswer: "IaaS provides raw infrastructure (VMs, storage); PaaS provides runtime platforms for code; SaaS delivers fully managed ready-to-use software",
    explanation: "Infrastructure as a Service (e.g. AWS EC2) manages hardware and hypervisors. Platform as a Service (e.g. Heroku, Elastic Beanstalk) manages runtimes so developers only write code. Software as a Service (e.g. Gmail, Salesforce) manages everything.",
    points: 10
  },
  {
    id: "cloud-easy-002",
    category: "Cloud & DevOps",
    difficulty: "Easy",
    topic: "Docker & Containers",
    question: "What is a Docker container?",
    options: [
      "A lightweight, standalone, executable package that includes code, runtime, system tools, and libraries running isolated on the host OS kernel",
      "A complete virtual computer that emulates BIOS and hardware with a full guest OS",
      "A cloud database table stored in RAM",
      "A physical metal server in an enterprise data center"
    ],
    correctAnswer: "A lightweight, standalone, executable package that includes code, runtime, system tools, and libraries running isolated on the host OS kernel",
    explanation: "Unlike heavy virtual machines, Docker containers share the host operating system's kernel, providing isolated, standardized runtimes with near-instant boot times and minimal memory footprint.",
    points: 10
  },
  {
    id: "cloud-easy-003",
    category: "Cloud & DevOps",
    difficulty: "Easy",
    topic: "CI/CD",
    question: "What do the acronyms CI and CD stand for in modern DevOps workflows?",
    options: [
      "Continuous Integration and Continuous Delivery / Deployment",
      "Cloud Infrastructure and Container Deployment",
      "Code Inspection and Data Distribution",
      "Centralized Interface and Dynamic Configuration"
    ],
    correctAnswer: "Continuous Integration and Continuous Delivery / Deployment",
    explanation: "CI automates code merging, building, and automated testing. CD automates packaging, staging verification, and deployment to production environments.",
    points: 10
  },
  {
    id: "cloud-easy-004",
    category: "Cloud & DevOps",
    difficulty: "Easy",
    topic: "AWS Storage",
    question: "Which AWS service is designed for highly durable, scalable object storage accessible over HTTP REST APIs?",
    options: ["Amazon S3 (Simple Storage Service)", "Amazon EBS", "Amazon RDS", "Amazon EFS"],
    correctAnswer: "Amazon S3 (Simple Storage Service)",
    explanation: "Amazon S3 is an object storage service offering industry-leading 99.999999999% (11 9's) of data durability, storing unstructured files as objects within buckets.",
    points: 10
  },
  {
    id: "cloud-easy-005",
    category: "Cloud & DevOps",
    difficulty: "Easy",
    topic: "Git Version Control",
    question: "How does 'git rebase' fundamentally differ from 'git merge'?",
    options: [
      "Rebase re-applies commits on top of another base tip creating a clean linear history, whereas merge creates a dedicated merge commit joining histories",
      "Rebase deletes the master branch permanently",
      "Merge deletes uncommitted files from the staging area",
      "Rebase only works when disconnected from the Internet"
    ],
    correctAnswer: "Rebase re-applies commits on top of another base tip creating a clean linear history, whereas merge creates a dedicated merge commit joining histories",
    explanation: "git merge preserves complete historical branch topology via merge commits. git rebase rewrites project history by replaying branch commits one-by-one onto the target branch tip.",
    points: 10
  },
  {
    id: "cloud-easy-006",
    category: "Cloud & DevOps",
    difficulty: "Easy",
    topic: "Virtualization",
    question: "Why do Docker containers boot significantly faster and consume fewer resources than traditional Virtual Machines (VMs)?",
    options: [
      "Containers share the host operating system kernel and do not require running a separate guest OS",
      "Containers run on specialized hardware CPUs",
      "Virtual Machines do not support networking",
      "Containers only run compiled binary code"
    ],
    correctAnswer: "Containers share the host operating system kernel and do not require running a separate guest OS",
    explanation: "A VM must boot a complete guest operating system kernel, device drivers, and system daemons. Containers simply run as isolated user-space processes on the host kernel.",
    points: 10
  },
  {
    id: "cloud-easy-007",
    category: "Cloud & DevOps",
    difficulty: "Easy",
    topic: "Kubernetes",
    question: "What is Kubernetes (K8s)?",
    options: [
      "An open-source container orchestration platform for automating deployment, scaling, and management of containerized applications",
      "A relational database management system designed by Google",
      "A programming language for writing cloud lambdas",
      "A proprietary network router manufactured by Cisco"
    ],
    correctAnswer: "An open-source container orchestration platform for automating deployment, scaling, and management of containerized applications",
    explanation: "Kubernetes automates the lifecycle of containers across clusters of machines, handling service discovery, load balancing, rolling updates, self-healing, and auto-scaling.",
    points: 10
  },
  {
    id: "cloud-easy-008",
    category: "Cloud & DevOps",
    difficulty: "Easy",
    topic: "Infrastructure as Code",
    question: "Which popular open-source tool enables teams to define and provision multi-cloud infrastructure using declarative configuration files?",
    options: ["Terraform", "Docker Swarm", "Jenkins", "Postman"],
    correctAnswer: "Terraform",
    explanation: "HashiCorp Terraform uses HashiCorp Configuration Language (HCL) to declaratively define cloud resources (AWS, Azure, GCP), generating execution plans and managing infrastructure state safely.",
    points: 10
  },
  {
    id: "cloud-easy-009",
    category: "Cloud & DevOps",
    difficulty: "Easy",
    topic: "Serverless Computing",
    question: "What defines Serverless computing (such as AWS Lambda or Google Cloud Functions)?",
    options: [
      "The cloud provider manages server provisioning, scaling, and maintenance automatically, and you only pay for actual compute execution time",
      "Servers are replaced with satellite antennas",
      "Applications run without electricity",
      "Code is executed exclusively in client web browsers"
    ],
    correctAnswer: "The cloud provider manages server provisioning, scaling, and maintenance automatically, and you only pay for actual compute execution time",
    explanation: "In serverless architectures, developers write event-driven functions. The cloud provider automatically handles scaling, patching, and resource allocation, charging only for active CPU execution milliseconds.",
    points: 10
  },
  {
    id: "cloud-easy-010",
    category: "Cloud & DevOps",
    difficulty: "Easy",
    topic: "Cloud Security",
    question: "What is the primary function of AWS IAM (Identity and Access Management)?",
    options: [
      "Securely controlling access to AWS cloud services and resources through users, groups, roles, and fine-grained permission policies",
      "Monitoring CPU temperature inside AWS physical data centers",
      "Routing DNS queries to the nearest geographic region",
      "Scanning hard drives for physical magnetic defects"
    ],
    correctAnswer: "Securely controlling access to AWS cloud services and resources through users, groups, roles, and fine-grained permission policies",
    explanation: "IAM enables administrators to enforce the principle of least privilege by defining who (authentication) is authorized to perform which specific actions on which resources (authorization).",
    points: 10
  },
  {
    id: "cloud-medium-001",
    category: "Cloud & DevOps",
    difficulty: "Medium",
    topic: "Docker",
    question: "In a Dockerfile, how does ENTRYPOINT differ from CMD?",
    options: [
      "ENTRYPOINT defines the fixed executable to run, while CMD specifies default arguments that can easily be overridden from the command line",
      "CMD cannot be overridden during docker run",
      "ENTRYPOINT only works for shell scripts, not binary executables",
      "CMD runs during image build time while ENTRYPOINT runs at container runtime"
    ],
    correctAnswer: "ENTRYPOINT defines the fixed executable to run, while CMD specifies default arguments that can easily be overridden from the command line",
    explanation: "ENTRYPOINT configures a container that will run as an executable. Arguments passed to `docker run <image> [args]` will append to the ENTRYPOINT, overriding the default parameters provided by CMD.",
    points: 20
  },
  {
    id: "cloud-medium-002",
    category: "Cloud & DevOps",
    difficulty: "Medium",
    topic: "Kubernetes Architecture",
    question: "Which Kubernetes control-plane component acts as the consistent, highly-available key-value store for all cluster data?",
    options: ["etcd", "kube-apiserver", "kube-scheduler", "kube-controller-manager"],
    correctAnswer: "etcd",
    explanation: "etcd is a distributed, reliable key-value store using the Raft consensus algorithm. It holds the definitive state of the entire Kubernetes cluster, specs, and secrets.",
    points: 20
  },
  {
    id: "cloud-medium-003",
    category: "Cloud & DevOps",
    difficulty: "Medium",
    topic: "Kubernetes Objects",
    question: "In Kubernetes, what is the smallest deployable computing unit that can be created and managed?",
    options: ["Pod", "Deployment", "Service", "ReplicaSet"],
    correctAnswer: "Pod",
    explanation: "A Pod represents a single instance of a running process in your cluster. It encapsulates one or more containers sharing storage volumes, network IP, and container specifications.",
    points: 20
  },
  {
    id: "cloud-medium-004",
    category: "Cloud & DevOps",
    difficulty: "Medium",
    topic: "Cloud Networking",
    question: "In an AWS Virtual Private Cloud (VPC), how do backend database instances in a Private Subnet securely download software updates from the Internet?",
    options: [
      "Through a NAT Gateway located in a Public Subnet",
      "By assigning them public IPv4 addresses directly",
      "By opening port 0.0.0.0/0 on the database security group",
      "Instances in private subnets can never communicate with external servers"
    ],
    correctAnswer: "Through a NAT Gateway located in a Public Subnet",
    explanation: "A NAT Gateway allows instances in private subnets to initiate outbound connections to the Internet (for updates or APIs) while strictly preventing incoming unsolicited connections from the public Internet.",
    points: 20
  },
  {
    id: "cloud-medium-005",
    category: "Cloud & DevOps",
    difficulty: "Medium",
    topic: "Deployment Strategies",
    question: "What characterizes a Blue-Green Deployment strategy?",
    options: [
      "Maintaining two identical production environments; new code is deployed to the idle Green environment, tested, and router traffic is swapped instantaneously from Blue to Green",
      "Deploying updates to 10% of users first and slowly increasing traffic over 2 weeks",
      "Shutting down all servers for 4 hours while running database migrations",
      "Compiling the application in dark mode"
    ],
    correctAnswer: "Maintaining two identical production environments; new code is deployed to the idle Green environment, tested, and router traffic is swapped instantaneously from Blue to Green",
    explanation: "Blue-Green deployment minimizes downtime and risk: if any unexpected defect arises after swapping router traffic to the new Green environment, traffic can instantly roll back to Blue.",
    points: 20
  },
  {
    id: "cloud-medium-006",
    category: "Cloud & DevOps",
    difficulty: "Medium",
    topic: "Terraform",
    question: "Why is Remote State storage (e.g. AWS S3 with DynamoDB state locking) crucial when using Terraform in team environments?",
    options: [
      "To prevent concurrent Terraform runs from corrupting infrastructure state and ensure all team members share the exact current infrastructure mapping",
      "To convert Terraform code into compiled machine bytecode",
      "To encrypt local developer hard drives",
      "To bypass cloud provider billing"
    ],
    correctAnswer: "To prevent concurrent Terraform runs from corrupting infrastructure state and ensure all team members share the exact current infrastructure mapping",
    explanation: "Terraform tracks real-world resources in terraform.tfstate. Remote backend storage with DynamoDB distributed locks prevents race conditions where two engineers apply changes simultaneously.",
    points: 20
  },
  {
    id: "cloud-medium-007",
    category: "Cloud & DevOps",
    difficulty: "Medium",
    topic: "Observability",
    question: "What are the three canonical pillars of modern system Observability?",
    options: [
      "Metrics, Logs, and Traces",
      "CPU, RAM, and Disk space",
      "Alerts, Dashboards, and Reports",
      "Authentication, Authorization, and Auditing"
    ],
    correctAnswer: "Metrics, Logs, and Traces",
    explanation: "Metrics provide aggregated numerical trends over time (counters, gauges); Logs capture detailed timestamped event records; Traces follow the end-to-end request lifecycle across distributed microservices.",
    points: 20
  },
  {
    id: "cloud-medium-008",
    category: "Cloud & DevOps",
    difficulty: "Medium",
    topic: "Linux CLI for DevOps",
    question: "Which Linux command displays real-time journal logs for a specific systemd service unit?",
    options: ["journalctl -u servicename -f", "systemctl status -all", "tail -n 100 /dev/null", "dmesg --follow-systemd"],
    correctAnswer: "journalctl -u servicename -f",
    explanation: "`journalctl -u servicename -f` queries the systemd journal for the specified unit name and follows (-f) new entries in real time, essential for debugging running services on Linux nodes.",
    points: 20
  },
  {
    id: "cloud-medium-009",
    category: "Cloud & DevOps",
    difficulty: "Medium",
    topic: "Container Optimization",
    question: "What is the primary benefit of using Multi-Stage Builds in Dockerfiles?",
    options: [
      "Producing drastically smaller and more secure production container images by separating compilation tooling from the final lightweight runtime image",
      "Running containers on multiple cloud providers simultaneously",
      "Bypassing the Docker build cache",
      "Automatically upgrading Linux kernel versions"
    ],
    correctAnswer: "Producing drastically smaller and more secure production container images by separating compilation tooling from the final lightweight runtime image",
    explanation: "Multi-stage builds allow developers to use a heavy SDK/compiler image to build binaries, then copy only the compiled artifact into a minimal base (like Alpine or distroless), shedding gigabytes of build bloat.",
    points: 20
  },
  {
    id: "cloud-medium-010",
    category: "Cloud & DevOps",
    difficulty: "Medium",
    topic: "High Availability",
    question: "In AWS architecture, how does deploying across Multi-AZ (Availability Zones) protect against outages compared to a single AZ?",
    options: [
      "Availability Zones are distinct physical data centers with independent power, cooling, and networking within a region, surviving local facility failures",
      "Multi-AZ deployment reduces monthly AWS billing by 50%",
      "Multi-AZ ensures data is copied to every country in the world",
      "It eliminates the need for software bug fixes"
    ],
    correctAnswer: "Availability Zones are distinct physical data centers with independent power, cooling, and networking within a region, surviving local facility failures",
    explanation: "Each AZ is physically isolated from failures in other AZs within the same AWS Region. Multi-AZ applications fail over automatically if a specific physical data center experiences a flood or power failure.",
    points: 20
  },
  {
    id: "cloud-hard-001",
    category: "Cloud & DevOps",
    difficulty: "Hard",
    topic: "Kubernetes Networking",
    question: "How does kube-proxy route traffic to Pods backing a ClusterIP Service inside a Kubernetes cluster?",
    options: [
      "By configuring Linux iptables or IPVS (IP Virtual Server) rules on each node to intercept the Service virtual IP and load-balance across endpoint Pod IPs",
      "By running an Apache HTTP server inside the control plane",
      "By modifying hardware BIOS settings on worker nodes",
      "By broadcasting ARP requests across all physical switch ports"
    ],
    correctAnswer: "By configuring Linux iptables or IPVS (IP Virtual Server) rules on each node to intercept the Service virtual IP and load-balance across endpoint Pod IPs",
    explanation: "kube-proxy watches the API server for Service and Endpoint changes, generating netfilter iptables or high-performance IPVS hash tables in the Linux kernel to rewrite virtual ClusterIP packets to real Pod IPs.",
    points: 30
  },
  {
    id: "cloud-hard-002",
    category: "Cloud & DevOps",
    difficulty: "Hard",
    topic: "Service Mesh",
    question: "What architectural role does a Service Mesh (such as Istio or Linkerd) fulfill in complex microservice deployments?",
    options: [
      "Injecting sidecar network proxies (e.g. Envoy) next to each container to transparently manage mTLS encryption, traffic routing, circuit breaking, and telemetry",
      "Compiling Java code into native machine executables",
      "Replacing Kubernetes Pods with virtual hardware machines",
      "Managing database relational foreign keys"
    ],
    correctAnswer: "Injecting sidecar network proxies (e.g. Envoy) next to each container to transparently manage mTLS encryption, traffic routing, circuit breaking, and telemetry",
    explanation: "A service mesh handles service-to-service communication at the infrastructure layer without modifying application code, delivering automatic mutual TLS (mTLS), distributed tracing headers, and canary percentage splits.",
    points: 30
  },
  {
    id: "cloud-hard-003",
    category: "Cloud & DevOps",
    difficulty: "Hard",
    topic: "GitOps",
    question: "What core principle governs GitOps continuous delivery tools like ArgoCD and Flux?",
    options: [
      "Git is treated as the single source of truth for desired system state; automated agents continuously reconcile cluster state to match the Git repository",
      "Developers push Docker containers directly to production servers via FTP",
      "All code commits must be written in YAML instead of programming languages",
      "Manual approvals in production terminal shells are required for every container"
    ],
    correctAnswer: "Git is treated as the single source of truth for desired system state; automated agents continuously reconcile cluster state to match the Git repository",
    explanation: "In GitOps, declarative manifests stored in Git define production. Reconcilers inside the cluster pull and apply changes automatically, eliminating developer cluster credentials and ensuring zero config drift.",
    points: 30
  },
  {
    id: "cloud-hard-004",
    category: "Cloud & DevOps",
    difficulty: "Hard",
    topic: "Linux Containers Internals",
    question: "Which two Linux kernel features form the foundational building blocks for Docker and OCI container isolation and resource management?",
    options: [
      "Namespaces (for process, network, and mount isolation) and cgroups (Control Groups, for CPU, memory, and I/O resource limits)",
      "Swap partitions and cron jobs",
      "Ext4 file systems and SSH keys",
      "GCC compilers and systemd journalctl"
    ],
    correctAnswer: "Namespaces (for process, network, and mount isolation) and cgroups (Control Groups, for CPU, memory, and I/O resource limits)",
    explanation: "Linux Namespaces (pid, net, ipc, mnt, uts, user) create the illusion of dedicated system resources for each container. Control Groups (cgroups) strictly enforce resource rationing (RAM, CPU shares, blkio).",
    points: 30
  },
  {
    id: "cloud-hard-005",
    category: "Cloud & DevOps",
    difficulty: "Hard",
    topic: "Cloud Security",
    question: "In Zero Trust cloud architecture, what security principle replaces traditional perimeter-based network security ('castle-and-moat')?",
    options: [
      "Never trust, always verify: every request must be authenticated, authorized, and encrypted regardless of whether it originates inside or outside the network perimeter",
      "Allow all traffic inside the corporate office Wi-Fi without passwords",
      "Store all API secret keys in public GitHub repositories",
      "Disable firewalls to improve network throughput"
    ],
    correctAnswer: "Never trust, always verify: every request must be authenticated, authorized, and encrypted regardless of whether it originates inside or outside the network perimeter",
    explanation: "Zero Trust assumes hostile actors already operate within the internal network. Microsegmentation, continuous identity verification, short-lived certificates, and least-privilege RBAC protect every single transaction.",
    points: 30
  }
];
