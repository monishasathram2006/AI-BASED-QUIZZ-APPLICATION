export const systemDesignQuestions = [
  {
    id: "systemdesign-easy-001",
    category: "System Design",
    difficulty: "Easy",
    topic: "Scalability",
    question: "What is the primary difference between Horizontal Scaling (scaling out) and Vertical Scaling (scaling up)?",
    options: [
      "Horizontal scaling adds more machines to the pool; vertical scaling adds more CPU/RAM resources to an existing machine",
      "Horizontal scaling upgrades the operating system; vertical scaling moves servers to the cloud",
      "Vertical scaling is always cheaper and has no hardware limits",
      "Horizontal scaling only applies to relational databases"
    ],
    correctAnswer: "Horizontal scaling adds more machines to the pool; vertical scaling adds more CPU/RAM resources to an existing machine",
    explanation: "Scaling out (horizontal) distributes load across multiple independent servers, providing resilience and infinite scalability. Scaling up (vertical) beefs up a single server, which eventually hits physical hardware limits.",
    points: 10
  },
  {
    id: "systemdesign-easy-002",
    category: "System Design",
    difficulty: "Easy",
    topic: "Caching",
    question: "Why do distributed architectures implement in-memory caching layers (such as Redis or Memcached)?",
    options: [
      "To serve frequently read data directly from RAM with sub-millisecond latency, reducing expensive database load",
      "To permanently store relational tables instead of hard drives",
      "To encrypt passwords before sending them to users",
      "To execute background cron jobs"
    ],
    correctAnswer: "To serve frequently read data directly from RAM with sub-millisecond latency, reducing expensive database load",
    explanation: "RAM access is orders of magnitude faster than disk or database queries. Caches store hot data in memory, slashing API response times and shielding backend databases from excessive queries.",
    points: 10
  },
  {
    id: "systemdesign-easy-003",
    category: "System Design",
    difficulty: "Easy",
    topic: "Load Balancing",
    question: "What is the primary responsibility of a Load Balancer in high-availability web applications?",
    options: [
      "Evenly distributing incoming client network traffic across a pool of backend application servers",
      "Compressing database backups on disk",
      "Writing SQL queries on behalf of backend microservices",
      "Compiling TypeScript code into production bundles"
    ],
    correctAnswer: "Evenly distributing incoming client network traffic across a pool of backend application servers",
    explanation: "Load balancers (like Nginx, HAProxy, AWS ALB) sit between clients and servers, distributing traffic across healthy instances to maximize throughput and eliminate single points of failure.",
    points: 10
  },
  {
    id: "systemdesign-easy-004",
    category: "System Design",
    difficulty: "Easy",
    topic: "Architecture",
    question: "What describes a Microservices Architecture compared to a Monolithic Architecture?",
    options: [
      "Decomposing an application into a collection of small, independently deployable services organized around business capabilities",
      "Packaging all UI, business logic, and database schemas into a single binary",
      "Writing all services in pure assembly language",
      "A system that runs without an operating system"
    ],
    correctAnswer: "Decomposing an application into a collection of small, independently deployable services organized around business capabilities",
    explanation: "Microservices break a large app into discrete, loosely-coupled services that communicate via APIs, enabling independent scaling, deployment, and technology selection per domain.",
    points: 10
  },
  {
    id: "systemdesign-easy-005",
    category: "System Design",
    difficulty: "Easy",
    topic: "Content Delivery Networks",
    question: "How does a Content Delivery Network (CDN) reduce page load times for global users?",
    options: [
      "By caching static assets (images, CSS, JS, videos) on geographically distributed edge servers near users",
      "By increasing the user's home broadband connection speed",
      "By running server-side business logic on client smartphones",
      "By converting HTTP requests to SMS text messages"
    ],
    correctAnswer: "By caching static assets (images, CSS, JS, videos) on geographically distributed edge servers near users",
    explanation: "CDNs operate Point of Presence (PoP) edge servers worldwide. When a user requests assets, the nearest edge server responds, minimizing physical latency and round-trip distances.",
    points: 10
  },
  {
    id: "systemdesign-easy-006",
    category: "System Design",
    difficulty: "Easy",
    topic: "CAP Theorem",
    question: "What three guarantees are balanced in Eric Brewer's CAP Theorem for distributed data stores?",
    options: [
      "Consistency, Availability, and Partition Tolerance",
      "Concurrency, Authenticity, and Performance",
      "Capacity, Accuracy, and Persistence",
      "Complexity, Agility, and Portability"
    ],
    correctAnswer: "Consistency, Availability, and Partition Tolerance",
    explanation: "CAP states that in a distributed data store subject to network Partitions (P), the system can guarantee either Consistency (C - all nodes see same data) or Availability (A - every request gets non-error response), but not both simultaneously.",
    points: 10
  },
  {
    id: "systemdesign-easy-007",
    category: "System Design",
    difficulty: "Easy",
    topic: "Databases",
    question: "When is a NoSQL Document store (e.g. MongoDB) typically chosen over a traditional relational database (e.g. PostgreSQL)?",
    options: [
      "When schema requirements are dynamic/rapidly evolving, and nested hierarchical data is naturally queried without complex multi-table joins",
      "When strict ACID transactions across dozens of normalized tables are paramount",
      "When all data fits in 100 kilobytes of storage",
      "When no indexes are ever needed"
    ],
    correctAnswer: "When schema requirements are dynamic/rapidly evolving, and nested hierarchical data is naturally queried without complex multi-table joins",
    explanation: "Document databases excel when unstructured or polymorphic data benefits from JSON-like flexible schemas, high write volume, and horizontal sharding without expensive relational joins.",
    points: 10
  },
  {
    id: "systemdesign-easy-008",
    category: "System Design",
    difficulty: "Easy",
    topic: "Message Queues",
    question: "What architectural problem do Message Queues (like RabbitMQ or Amazon SQS) solve?",
    options: [
      "Decoupling producer and consumer services, enabling asynchronous processing and buffering spikes in traffic",
      "Encrypting disk storage on database servers",
      "Replacing CSS stylesheets in mobile apps",
      "Compiling backend code on the fly"
    ],
    correctAnswer: "Decoupling producer and consumer services, enabling asynchronous processing and buffering spikes in traffic",
    explanation: "Message queues allow producers to enqueue jobs and return instantly without waiting for slow operations (e.g. video rendering, emails) to finish, smoothing out traffic surges.",
    points: 10
  },
  {
    id: "systemdesign-easy-009",
    category: "System Design",
    difficulty: "Easy",
    topic: "Rate Limiting",
    question: "Why do production public APIs enforce Rate Limiting?",
    options: [
      "To prevent server overload, defend against brute-force attacks and abuse, and ensure fair resource allocation",
      "To increase latency for mobile clients",
      "To limit how many bytes can be stored on hard drives",
      "To prevent databases from creating indexes"
    ],
    correctAnswer: "To prevent server overload, defend against brute-force attacks and abuse, and ensure fair resource allocation",
    explanation: "Rate limiting caps the number of requests a client or IP can send within a timeframe (e.g., 100 req/min), preventing denial of service, bot scrapers, and cascading system failure.",
    points: 10
  },
  {
    id: "systemdesign-easy-010",
    category: "System Design",
    difficulty: "Easy",
    topic: "Design Patterns",
    question: "Which software design pattern ensures that a class has only one instance and provides a global point of access to it?",
    options: ["Singleton Pattern", "Factory Pattern", "Adapter Pattern", "Decorator Pattern"],
    correctAnswer: "Singleton Pattern",
    explanation: "The Singleton pattern restricts class instantiation to a single unique instance, useful for coordinating shared global resources like database connection pools or configuration managers.",
    points: 10
  },
  {
    id: "systemdesign-easy-011",
    category: "System Design",
    difficulty: "Medium",
    topic: "Caching Strategies",
    question: "In the 'Cache-Aside' (Lazy Loading) caching pattern, how does the application handle a read request?",
    options: [
      "The app checks the cache; on a hit it returns data; on a miss it queries the database, writes the result to cache, and returns it",
      "The database automatically pushes all updates to the cache synchronously before returning",
      "The cache queries the database asynchronously every 5 seconds regardless of user traffic",
      "Writes only go to the cache and are never saved to disk"
    ],
    correctAnswer: "The app checks the cache; on a hit it returns data; on a miss it queries the database, writes the result to cache, and returns it",
    explanation: "Cache-Aside places caching logic in the application layer. Data is only loaded into the cache on-demand when requested, preventing cache bloat with unread records.",
    points: 20
  },
  {
    id: "systemdesign-medium-002",
    category: "System Design",
    difficulty: "Medium",
    topic: "Database Sharding",
    question: "What is Database Sharding and what is its primary benefit?",
    options: [
      "Horizontally partitioning data rows across multiple database instances based on a shard key, enabling writes and storage to scale beyond a single node",
      "Creating read-only copies of the master database",
      "Storing all database tables in encrypted CSV files",
      "Merging multiple microservice schemas into one central table"
    ],
    correctAnswer: "Horizontally partitioning data rows across multiple database instances based on a shard key, enabling writes and storage to scale beyond a single node",
    explanation: "Sharding breaks a massive database into smaller independent shards spread across different servers. This allows write throughput, memory, and disk space to scale horizontally.",
    points: 20
  },
  {
    id: "systemdesign-medium-003",
    category: "System Design",
    difficulty: "Medium",
    topic: "Consistent Hashing",
    question: "Why is Consistent Hashing preferred over simple modular hashing (hash(key) % N) in distributed caching systems?",
    options: [
      "When a cache node is added or removed, only k/N keys need to be remapped on average rather than almost all keys",
      "It eliminates the need for hash functions entirely",
      "It guarantees that all cache keys have the exact same byte length",
      "It encrypts cached data with public-private key cryptography"
    ],
    correctAnswer: "When a cache node is added or removed, only k/N keys need to be remapped on average rather than almost all keys",
    explanation: "Under simple hash(key) % N, changing N causes almost 100% of keys to invalidate, sparking a devastating database thundering herd. Consistent Hashing maps nodes to a virtual ring so only adjacent keys move.",
    points: 20
  },
  {
    id: "systemdesign-medium-004",
    category: "System Design",
    difficulty: "Medium",
    topic: "Streaming & Messaging",
    question: "In Apache Kafka, how do Partitions within a Topic facilitate horizontal consumer scalability?",
    options: [
      "Each partition can be consumed concurrently by at most one consumer instance within a consumer group, allowing parallel consumption",
      "Partitions compress messages into zip archives before sending",
      "Partitions eliminate disk writes by keeping topics in RAM",
      "Partitions restrict messages to 256 characters"
    ],
    correctAnswer: "Each partition can be consumed concurrently by at most one consumer instance within a consumer group, allowing parallel consumption",
    explanation: "Kafka partitions act as ordered commit logs. By having P partitions, up to P consumers in the same group can read in parallel without contention or lock overhead.",
    points: 20
  },
  {
    id: "systemdesign-medium-005",
    category: "System Design",
    difficulty: "Medium",
    topic: "Rate Limiting Algorithms",
    question: "How does the 'Token Bucket' rate limiting algorithm handle sudden bursts of traffic?",
    options: [
      "It allows bursts of requests up to the maximum bucket capacity as long as sufficient tokens have accumulated",
      "It immediately drops all requests when traffic spikes above the average rate",
      "It delays all burst requests into the next calendar day",
      "It blocks the user's IP permanently"
    ],
    correctAnswer: "It allows bursts of requests up to the maximum bucket capacity as long as sufficient tokens have accumulated",
    explanation: "Tokens are added to the bucket at a constant refill rate up to a max capacity. A burst can consume all accumulated tokens immediately, providing burst tolerance while capping sustained throughput.",
    points: 20
  },
  {
    id: "systemdesign-medium-006",
    category: "System Design",
    difficulty: "Medium",
    topic: "API Gateway",
    question: "Which of the following is typically centralized inside an API Gateway rather than duplicated across microservices?",
    options: [
      "Authentication, SSL termination, rate limiting, and request routing",
      "Core domain business rules and entity persistence",
      "Individual unit test execution",
      "Local code syntax linting"
    ],
    correctAnswer: "Authentication, SSL termination, rate limiting, and request routing",
    explanation: "The API Gateway acts as the single reverse-proxy entry point for clients, centralizing cross-cutting concerns (CORS, SSL, JWT validation, throttling) so individual microservices stay focused on domain logic.",
    points: 20
  },
  {
    id: "systemdesign-medium-007",
    category: "System Design",
    difficulty: "Medium",
    topic: "Consistency Models",
    question: "What does Eventual Consistency mean in distributed storage systems (like Amazon Dynamo or Cassandra)?",
    options: [
      "If no new updates are made, all replicas will eventually converge and return the same latest value",
      "Transactions are guaranteed to commit immediately across all servers within 1 microsecond",
      "Reads will always be blocked until the master node confirms disk write",
      "Data is permanently deleted after 24 hours"
    ],
    correctAnswer: "If no new updates are made, all replicas will eventually converge and return the same latest value",
    explanation: "Eventual consistency trades off immediate consistency for high availability and low latency. Replicas synchronize asynchronously in the background, guaranteeing convergence over time.",
    points: 20
  },
  {
    id: "systemdesign-medium-008",
    category: "System Design",
    difficulty: "Medium",
    topic: "API Idempotency",
    question: "Why is Idempotency critical in payment processing APIs (e.g. Stripe)?",
    options: [
      "To ensure that if a network timeout causes a client to retry the payment request, the customer is not charged twice",
      "To encrypt credit card numbers with quantum keys",
      "To convert foreign currencies without transaction fees",
      "To enable payment processing when the customer is offline"
    ],
    correctAnswer: "To ensure that if a network timeout causes a client to retry the payment request, the customer is not charged twice",
    explanation: "An idempotent operation yields the exact same state regardless of how many times it is repeated. Using unique Idempotency Keys guarantees network retries recognize previous executions.",
    points: 20
  },
  {
    id: "systemdesign-medium-009",
    category: "System Design",
    difficulty: "Medium",
    topic: "Design Patterns",
    question: "What is the key structural difference between the Observer Pattern and the Publish-Subscribe (Pub/Sub) Pattern?",
    options: [
      "In Observer, the subject and observers know of each other directly; in Pub/Sub, publishers and subscribers are decoupled via an intermediary message broker",
      "Observer pattern only works on the client-side; Pub/Sub only runs in the Linux kernel",
      "Pub/Sub does not support multiple subscribers",
      "Observer pattern requires database tables"
    ],
    correctAnswer: "In Observer, the subject and observers know of each other directly; in Pub/Sub, publishers and subscribers are decoupled via an intermediary message broker",
    explanation: "In Observer, the Subject maintains a list of dependents and calls their methods directly. In Pub/Sub, publishers send messages to an external broker/topic without any knowledge of who or where subscribers are.",
    points: 20
  },
  {
    id: "systemdesign-medium-010",
    category: "System Design",
    difficulty: "Medium",
    topic: "Database Replication",
    question: "What is the primary trade-off of Asynchronous Master-Slave Database Replication?",
    options: [
      "High write throughput on the master, but read replicas may experience replication lag and risk data loss if the master fails before syncing",
      "Writes are blocked until all slaves confirm receipt on disk",
      "Slaves can never be promoted to become the master",
      "Replication requires fiber optic cables"
    ],
    correctAnswer: "High write throughput on the master, but read replicas may experience replication lag and risk data loss if the master fails before syncing",
    explanation: "In async replication, the master commits writes locally and returns success immediately, forwarding logs to replicas asynchronously. This yields fast writes but leaves a window for replica staleness and data loss during failover.",
    points: 20
  },
  {
    id: "systemdesign-hard-001",
    category: "System Design",
    difficulty: "Hard",
    topic: "Distributed Consensus",
    question: "In the Raft distributed consensus algorithm, how does a candidate node successfully win a leader election?",
    options: [
      "By receiving votes from a strict majority (quorum: > N/2) of cluster nodes within an election term",
      "By having the lowest IP address in the cluster configuration file",
      "By transmitting the largest payload over UDP",
      "By winning an arbitrary coin toss simulated across nodes"
    ],
    correctAnswer: "By receiving votes from a strict majority (quorum: > N/2) of cluster nodes within an election term",
    explanation: "Raft guarantees safety by requiring any prospective leader to gather votes from a majority of servers (> N/2). Because any two majorities must overlap by at least one node, split-brain leaders are prevented.",
    points: 30
  },
  {
    id: "systemdesign-hard-002",
    category: "System Design",
    difficulty: "Hard",
    topic: "Distributed Transactions",
    question: "Why is the Saga Pattern preferred over Two-Phase Commit (2PC) for transactions spanning multiple microservices?",
    options: [
      "2PC requires distributed blocking locks that crush throughput and availability across microservices; Sagas coordinate local transactions with compensating rollback transactions",
      "2PC does not support SQL databases",
      "Sagas execute all steps on a single server without network calls",
      "Sagas eliminate the need for databases entirely"
    ],
    correctAnswer: "2PC requires distributed blocking locks that crush throughput and availability across microservices; Sagas coordinate local transactions with compensating rollback transactions",
    explanation: "2PC holds locks across independent network boundaries until all nodes vote, creating severe latency bottlenecks. Sagas execute individual local transactions sequentially and trigger compensating actions (undos) if a step fails.",
    points: 30
  },
  {
    id: "systemdesign-hard-003",
    category: "System Design",
    difficulty: "Hard",
    topic: "Unique ID Generation",
    question: "How does Twitter's Snowflake distributed ID generation algorithm produce 64-bit globally unique, roughly time-sorted integers without central coordination?",
    options: [
      "By packing a timestamp (milliseconds), worker/machine ID, and a local per-millisecond sequence counter into a 64-bit integer",
      "By hashing the user's password with SHA-256",
      "By requesting auto-increment numbers from a central MySQL cluster",
      "By generating random UUIDs and trimming them"
    ],
    correctAnswer: "By packing a timestamp (milliseconds), worker/machine ID, and a local per-millisecond sequence counter into a 64-bit integer",
    explanation: "Snowflake uses 41 bits for epoch timestamp, 10 bits for machine/datacenter ID, and 12 bits for a local sequence counter. This produces ~4096 IDs per millisecond per node that are naturally sortable by creation time.",
    points: 30
  },
  {
    id: "systemdesign-hard-004",
    category: "System Design",
    difficulty: "Hard",
    topic: "Storage Engines",
    question: "Why do write-heavy distributed databases (like Cassandra, RocksDB, or BigTable) use Log-Structured Merge-trees (LSM-Trees) instead of traditional B-Trees?",
    options: [
      "LSM-Trees convert random disk writes into sequential append-only writes via in-memory MemTables and flushed SSTables, maximizing write throughput",
      "LSM-Trees do not require disk storage",
      "B-Trees cannot store strings",
      "LSM-Trees offer faster single-point random reads than B-Trees"
    ],
    correctAnswer: "LSM-Trees convert random disk writes into sequential append-only writes via in-memory MemTables and flushed SSTables, maximizing write throughput",
    explanation: "B-Trees require random in-place page overwrites. LSM-Trees write immediately to an append-only commit log and an in-memory MemTable, periodically flushing immutable sorted string tables (SSTables) sequentially to disk.",
    points: 30
  },
  {
    id: "systemdesign-hard-005",
    category: "System Design",
    difficulty: "Hard",
    topic: "Resilience Patterns",
    question: "What are the three operational states of the Circuit Breaker design pattern, and what governs the transition from OPEN to CLOSED?",
    options: [
      "CLOSED, OPEN, HALF-OPEN; after a timeout in OPEN state, it enters HALF-OPEN to test canary requests, resetting to CLOSED if they succeed",
      "ACTIVE, PASSIVE, DORMANT; transitions occur only upon manual server restarts",
      "LOCKED, UNLOCKED, SHARED; transitions occur based on CPU clock temperature",
      "READ, WRITE, APPEND; transitions occur based on disk sector availability"
    ],
    correctAnswer: "CLOSED, OPEN, HALF-OPEN; after a timeout in OPEN state, it enters HALF-OPEN to test canary requests, resetting to CLOSED if they succeed",
    explanation: "When failures exceed a threshold, the breaker trips to OPEN (failing fast without calling the dying service). After a sleep window, it switches to HALF-OPEN to test trial requests; if healthy, it restores to CLOSED.",
    points: 30
  }
];
