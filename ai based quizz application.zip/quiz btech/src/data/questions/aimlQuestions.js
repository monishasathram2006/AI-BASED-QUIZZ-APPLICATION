export const aimlQuestions = [
  {
    id: "aiml-easy-001",
    category: "AI & Machine Learning",
    difficulty: "Easy",
    topic: "ML Fundamentals",
    question: "What is the primary difference between Supervised Learning and Unsupervised Learning?",
    options: [
      "Supervised learning trains on labeled input-output pairs; unsupervised learning discovers patterns and structures from unlabeled data",
      "Supervised learning requires human code review for every prediction",
      "Unsupervised learning can only be used with image data",
      "Supervised learning only runs on quantum computers"
    ],
    correctAnswer: "Supervised learning trains on labeled input-output pairs; unsupervised learning discovers patterns and structures from unlabeled data",
    explanation: "In supervised learning, algorithms learn a mapping from input features to known target ground-truth labels. Unsupervised algorithms cluster or project data without pre-existing labels.",
    points: 10
  },
  {
    id: "aiml-easy-002",
    category: "AI & Machine Learning",
    difficulty: "Easy",
    topic: "Problem Types",
    question: "Which of the following is a Regression problem rather than a Classification problem?",
    options: [
      "Predicting the exact sale price of a house in dollars based on square footage and location",
      "Classifying an email as Spam or Not Spam",
      "Diagnosing whether a medical scan is Benign or Malignant",
      "Detecting whether an image contains a cat, dog, or bird"
    ],
    correctAnswer: "Predicting the exact sale price of a house in dollars based on square footage and location",
    explanation: "Regression predicts a continuous numerical quantity (e.g. price, temperature). Classification predicts categorical, discrete class labels.",
    points: 10
  },
  {
    id: "aiml-easy-003",
    category: "AI & Machine Learning",
    difficulty: "Easy",
    topic: "Model Evaluation",
    question: "Why can raw classification 'Accuracy' be dangerously misleading on severely imbalanced datasets?",
    options: [
      "A trivial model predicting only the majority class can score high accuracy while completely failing to detect rare positive cases",
      "Accuracy requires logarithmic computation that overflows RAM",
      "Accuracy can only be evaluated on training data, never test data",
      "Accuracy only works for neural networks with two layers"
    ],
    correctAnswer: "A trivial model predicting only the majority class can score high accuracy while completely failing to detect rare positive cases",
    explanation: "If 99% of transactions are legitimate and 1% fraudulent, a dumb model predicting 'Legitimate' 100% of the time gets 99% accuracy despite 0% fraud detection rate. Precision, recall, and PR-AUC are required.",
    points: 10
  },
  {
    id: "aiml-easy-004",
    category: "AI & Machine Learning",
    difficulty: "Easy",
    topic: "Model Generalization",
    question: "What describes an Overfitted machine learning model?",
    options: [
      "A model that performs exceptionally well on training data but fails to generalize to unseen test data",
      "A model that has too few parameters to capture linear relationships",
      "A model that runs out of GPU memory during inference",
      "A model that predicts random numbers on all inputs"
    ],
    correctAnswer: "A model that performs exceptionally well on training data but fails to generalize to unseen test data",
    explanation: "Overfitting occurs when a model memorizes the noise, outliers, and quirks of the training set rather than learning true underlying patterns, resulting in poor out-of-sample generalization.",
    points: 10
  },
  {
    id: "aiml-easy-005",
    category: "AI & Machine Learning",
    difficulty: "Easy",
    topic: "Neural Networks",
    question: "Why are non-linear Activation Functions (like ReLU or Sigmoid) essential in Deep Neural Networks?",
    options: [
      "Without non-linear activations, multi-layer neural networks collapse mathematically into a simple single-layer linear regression model",
      "They prevent computers from overheating",
      "They convert text inputs into binary numbers",
      "They automatically normalize dataset columns"
    ],
    correctAnswer: "Without non-linear activations, multi-layer neural networks collapse mathematically into a simple single-layer linear regression model",
    explanation: "A composition of purely linear functions W2 * (W1 * x) is just a single linear transformation (W2 * W1) * x. Non-linear activations enable networks to approximate arbitrary complex functions.",
    points: 10
  },
  {
    id: "aiml-easy-006",
    category: "AI & Machine Learning",
    difficulty: "Easy",
    topic: "Clustering",
    question: "What is K-Means clustering?",
    options: [
      "An unsupervised algorithm that partitions n observations into k clusters, assigning each point to the cluster with the nearest centroid",
      "A supervised classification algorithm that requires labeled training sets",
      "A sorting algorithm for multidimensional arrays",
      "A neural network designed for speech synthesis"
    ],
    correctAnswer: "An unsupervised algorithm that partitions n observations into k clusters, assigning each point to the cluster with the nearest centroid",
    explanation: "K-Means iteratively computes cluster centroids and reassigns points to their nearest center until convergence, minimizing within-cluster sum of squares (inertia).",
    points: 10
  },
  {
    id: "aiml-easy-007",
    category: "AI & Machine Learning",
    difficulty: "Easy",
    topic: "Data Preprocessing",
    question: "Why is Feature Scaling (e.g. Standard Scaler or Min-Max) important for gradient-based or distance-based models (like SVM or KNN)?",
    options: [
      "Features with larger numerical ranges would disproportionately dominate distance calculations and slow down gradient descent convergence",
      "Machine learning models cannot process numbers larger than 100",
      "Feature scaling converts non-numeric text columns into floats",
      "It eliminates the need for test datasets"
    ],
    correctAnswer: "Features with larger numerical ranges would disproportionately dominate distance calculations and slow down gradient descent convergence",
    explanation: "If one feature ranges from 0-1 and another from 0-1,000,000, Euclidean distance is driven almost entirely by the second feature. Scaling puts all features on equal footing and spherizes the loss surface.",
    points: 10
  },
  {
    id: "aiml-easy-008",
    category: "AI & Machine Learning",
    difficulty: "Easy",
    topic: "Deep Learning",
    question: "What is Backpropagation in neural network training?",
    options: [
      "Applying the mathematical Chain Rule of calculus backwards through layers to compute partial derivatives of the loss function with respect to weights",
      "Reversing the order of rows in the training dataset",
      "Rolling back an overtrained model to an earlier checkpoint",
      "Passing inputs from the output layer to the input layer during inference"
    ],
    correctAnswer: "Applying the mathematical Chain Rule of calculus backwards through layers to compute partial derivatives of the loss function with respect to weights",
    explanation: "Backpropagation efficiently calculates the gradient of the error function with respect to every weight in the network via recursive application of the chain rule, enabling gradient descent updates.",
    points: 10
  },
  {
    id: "aiml-easy-009",
    category: "AI & Machine Learning",
    difficulty: "Easy",
    topic: "NLP & LLMs",
    question: "In Natural Language Processing and Large Language Models, what is 'Tokenization'?",
    options: [
      "Breaking raw text into discrete chunks (tokens), such as words or subwords (like Byte-Pair Encoding), and mapping them to integer IDs",
      "Creating cryptocurrency tokens to reward user prompts",
      "Encrypting sentences with SHA-256 hashes",
      "Translating English grammar rules into Python code"
    ],
    correctAnswer: "Breaking raw text into discrete chunks (tokens), such as words or subwords (like Byte-Pair Encoding), and mapping them to integer IDs",
    explanation: "Computers cannot consume raw characters directly. Tokenizers (BPE, WordPiece, SentencePiece) segment text into numeric token IDs that index into the model's vocabulary embedding matrix.",
    points: 10
  },
  {
    id: "aiml-easy-010",
    category: "AI & Machine Learning",
    difficulty: "Easy",
    topic: "Bias-Variance Tradeoff",
    question: "What characterizes high Bias in machine learning models?",
    options: [
      "Underfitting: the model makes strong, overly simplistic assumptions and fails to capture underlying patterns in the training data",
      "Overfitting: the model captures every random fluctuation in the training set",
      "The model has too many hidden layers and parameters",
      "The dataset has duplicate labels"
    ],
    correctAnswer: "Underfitting: the model makes strong, overly simplistic assumptions and fails to capture underlying patterns in the training data",
    explanation: "High bias corresponds to underfitting (e.g. fitting a straight line to quadratic data). High variance corresponds to overfitting (excessive sensitivity to small fluctuations in training data).",
    points: 10
  },
  {
    id: "aiml-medium-001",
    category: "AI & Machine Learning",
    difficulty: "Medium",
    topic: "Classification Metrics",
    question: "What is the formula and intuition for 'Precision' in binary classification?",
    options: [
      "True Positives / (True Positives + False Positives); measuring what proportion of positive predictions were actually correct",
      "True Positives / (True Positives + False Negatives); measuring how many actual positives were found",
      "(True Positives + True Negatives) / Total Samples",
      "False Positives / (False Positives + True Negatives)"
    ],
    correctAnswer: "True Positives / (True Positives + False Positives); measuring what proportion of positive predictions were actually correct",
    explanation: "Precision evaluates the purity of positive identifications: out of all cases the model flagged as positive, what fraction were genuinely positive.",
    points: 20
  },
  {
    id: "aiml-medium-002",
    category: "AI & Machine Learning",
    difficulty: "Medium",
    topic: "Regularization",
    question: "How does L1 Regularization (Lasso) differ from L2 Regularization (Ridge) regarding feature weights?",
    options: [
      "L1 adds the absolute value of coefficients and drives less important weights strictly to zero (sparse feature selection); L2 adds squared weights and shrinks them toward zero without setting them to absolute zero",
      "L2 sets weights strictly to zero while L1 increases weight magnitudes",
      "L1 is only used in unsupervised clustering",
      "L2 regularization can only be used on datasets with fewer than 10 rows"
    ],
    correctAnswer: "L1 adds the absolute value of coefficients and drives less important weights strictly to zero (sparse feature selection); L2 adds squared weights and shrinks them toward zero without setting them to absolute zero",
    explanation: "Due to the sharp diamond geometry of the L1 penalty, contours hit axes at corners, producing exact zeros and sparse models. L2's spherical penalty penalizes extreme weights smoothly.",
    points: 20
  },
  {
    id: "aiml-medium-003",
    category: "AI & Machine Learning",
    difficulty: "Medium",
    topic: "Ensemble Learning",
    question: "What is the core difference between Bagging (e.g. Random Forest) and Boosting (e.g. XGBoost)?",
    options: [
      "Bagging trains independent models in parallel on bootstrap samples to reduce variance; Boosting trains sequential models where each step focuses on correcting previous errors to reduce bias",
      "Bagging is used for regression while boosting is only for clustering",
      "Boosting trains models in parallel while bagging is strictly sequential",
      "Random Forests cannot handle categorical data"
    ],
    correctAnswer: "Bagging trains independent models in parallel on bootstrap samples to reduce variance; Boosting trains sequential models where each step focuses on correcting previous errors to reduce bias",
    explanation: "Bagging (Bootstrap Aggregation) combines parallel diverse estimators to tame variance. Boosting builds an ensemble sequentially, re-weighting or fitting negative gradients of residual errors.",
    points: 20
  },
  {
    id: "aiml-medium-004",
    category: "AI & Machine Learning",
    difficulty: "Medium",
    topic: "Optimizers",
    question: "Why is the Adam (Adaptive Moment Estimation) optimizer widely favored over vanilla Stochastic Gradient Descent (SGD)?",
    options: [
      "It maintains adaptive per-parameter learning rates by tracking both first moments (mean gradients) and second moments (uncentered variance of gradients)",
      "It eliminates the need to calculate backpropagation gradients",
      "It guarantees global minimum convergence in all non-convex surfaces",
      "It requires zero hyperparameters"
    ],
    correctAnswer: "It maintains adaptive per-parameter learning rates by tracking both first moments (mean gradients) and second moments (uncentered variance of gradients)",
    explanation: "Adam combines the benefits of Momentum (moving past plateaus with running gradient averages) and RMSprop (scaling steps inversely with gradient magnitudes), delivering fast, robust convergence.",
    points: 20
  },
  {
    id: "aiml-medium-005",
    category: "AI & Machine Learning",
    difficulty: "Medium",
    topic: "Computer Vision",
    question: "What core properties make Convolutional Neural Networks (CNNs) superior to fully connected networks for processing image data?",
    options: [
      "Parameter sharing (reusable learned filters) and translation equivariance/invariance across 2D spatial dimensions",
      "They treat image pixels as independent random variables",
      "They do not use activation functions",
      "They can only process grayscale images"
    ],
    correctAnswer: "Parameter sharing (reusable learned filters) and translation equivariance/invariance across 2D spatial dimensions",
    explanation: "CNN filters slide across images, applying the same weights everywhere (parameter sharing) and detecting local visual features (edges, textures, shapes) regardless of where they appear spatially.",
    points: 20
  },
  {
    id: "aiml-medium-006",
    category: "AI & Machine Learning",
    difficulty: "Medium",
    topic: "Recurrent Networks",
    question: "How do Long Short-Term Memory (LSTM) networks solve the vanishing gradient problem inherent in standard RNNs?",
    options: [
      "Through a dedicated cell state pathway regulated by input, forget, and output gates that allow linear gradient flow over long time horizons",
      "By replacing matrix multiplications with addition only",
      "By resetting network weights every 5 time steps",
      "By running the sequence backwards only"
    ],
    correctAnswer: "Through a dedicated cell state pathway regulated by input, forget, and output gates that allow linear gradient flow over long time horizons",
    explanation: "The constant error carousel in the LSTM cell state allows gradients to backpropagate across hundreds of time steps with minimal decay, dynamically controlled by sigmoid gating units.",
    points: 20
  },
  {
    id: "aiml-medium-007",
    category: "AI & Machine Learning",
    difficulty: "Medium",
    topic: "Transformers",
    question: "What is the core intuition behind the Self-Attention mechanism in Transformer architectures?",
    options: [
      "Every token computes attention weights with every other token in the sequence, dynamically contextualizing representations regardless of token distance",
      "Tokens are processed one by one in a strict linear loop",
      "The network only attends to the first and last word in a paragraph",
      "It replaces weights with random noise vectors"
    ],
    correctAnswer: "Every token computes attention weights with every other token in the sequence, dynamically contextualizing representations regardless of token distance",
    explanation: "Self-attention constructs Query, Key, and Value projections. Dot products between queries and keys capture contextual dependencies across arbitrary distances in O(1) sequential path length.",
    points: 20
  },
  {
    id: "aiml-medium-008",
    category: "AI & Machine Learning",
    difficulty: "Medium",
    topic: "Dimensionality Reduction",
    question: "What objective does Principal Component Analysis (PCA) optimize during linear dimensionality reduction?",
    options: [
      "Finding orthogonal projection axes (eigenvectors of covariance matrix) that maximize the variance of projected data",
      "Grouping data into exactly 3 clusters",
      "Minimizing the classification accuracy of validation data",
      "Removing all non-zero values from a matrix"
    ],
    correctAnswer: "Finding orthogonal projection axes (eigenvectors of covariance matrix) that maximize the variance of projected data",
    explanation: "PCA identifies principal axes ordered by the amount of dataset variance they preserve, allowing high-dimensional data to be compressed onto fewer dimensions while retaining maximum information.",
    points: 20
  },
  {
    id: "aiml-medium-009",
    category: "AI & Machine Learning",
    difficulty: "Medium",
    topic: "Model Validation",
    question: "How does K-Fold Cross-Validation provide a more dependable estimate of model performance than a single train-test split?",
    options: [
      "It splits the dataset into k equal folds, training k models on k-1 folds and testing on the remaining fold, averaging scores across all iterations",
      "It trains k different algorithms and selects the fastest one",
      "It multiplies training dataset size by k using synthetic duplicates",
      "It guarantees 100% test accuracy on unseen data"
    ],
    correctAnswer: "It splits the dataset into k equal folds, training k models on k-1 folds and testing on the remaining fold, averaging scores across all iterations",
    explanation: "K-fold cross-validation ensures every data point is used for both training and validation once, minimizing variance associated with lucky or unlucky random single train-test partition splits.",
    points: 20
  },
  {
    id: "aiml-medium-010",
    category: "AI & Machine Learning",
    difficulty: "Medium",
    topic: "Generative AI & RAG",
    question: "In Retrieval-Augmented Generation (RAG) architectures, how are private knowledge documents integrated with LLMs?",
    options: [
      "Documents are chunked, converted to dense vector embeddings, stored in a Vector DB, and top semantic matches are injected into the LLM context prompt at query time",
      "The LLM model weights are fully re-trained from scratch on every user query",
      "Documents are translated into binary machine code and flashed onto the GPU BIOS",
      "Documents are converted to JSON and uploaded to a public web server"
    ],
    correctAnswer: "Documents are chunked, converted to dense vector embeddings, stored in a Vector DB, and top semantic matches are injected into the LLM context prompt at query time",
    explanation: "RAG combines vector search retrieval with generative LLMs: semantic similarity retrieves relevant document excerpts, which are passed in the prompt context to ground answers with accurate, private data without fine-tuning.",
    points: 20
  },
  {
    id: "aiml-hard-001",
    category: "AI & Machine Learning",
    difficulty: "Hard",
    topic: "Attention Mathematics",
    question: "In the Transformer architecture, why is the dot product of Query (Q) and Key (K) scaled by 1 / sqrt(d_k) before taking the Softmax?",
    options: [
      "For large values of d_k, dot products grow large in magnitude, pushing the Softmax function into regions with extremely small gradients (vanishing gradients)",
      "To ensure the result is always an integer",
      "To convert the attention scores into Euclidean distances",
      "To prevent the GPU from dividing by zero"
    ],
    correctAnswer: "For large values of d_k, dot products grow large in magnitude, pushing the Softmax function into regions with extremely small gradients (vanishing gradients)",
    explanation: "Assuming components of Q and K are independent zero-mean unit-variance variables, their dot product has mean 0 and variance d_k. Scaling by 1 / sqrt(d_k) preserves unit variance, keeping softmax in responsive gradient regions.",
    points: 30
  },
  {
    id: "aiml-hard-002",
    category: "AI & Machine Learning",
    difficulty: "Hard",
    topic: "Deep Architectures",
    question: "Why do Residual Networks (ResNets) with skip/shortcut connections (y = F(x) + x) enable training of networks with hundreds of layers?",
    options: [
      "The identity shortcut creates an unobstructed highway for error gradients to backpropagate directly to early layers without degrading exponentially",
      "They eliminate the need for GPU matrix multiplication",
      "Skip connections double the parameter count in each layer",
      "They convert convolutional layers into linear layers"
    ],
    correctAnswer: "The identity shortcut creates an unobstructed highway for error gradients to backpropagate directly to early layers without degrading exponentially",
    explanation: "The gradient dLoss/dx contains an additive term +1 from the identity path: dLoss/dx = (dLoss/dy) * (dF/dx + 1). Even if dF/dx is small, the signal doesn't vanish, allowing training of deep 100+ layer nets.",
    points: 30
  },
  {
    id: "aiml-hard-003",
    category: "AI & Machine Learning",
    difficulty: "Hard",
    topic: "Generative Models",
    question: "How does the training objective of modern Diffusion Models (e.g. DDPM) differ fundamentally from Generative Adversarial Networks (GANs)?",
    options: [
      "Diffusion models learn to invert a gradual forward Gaussian noise corruption process step-by-step via score matching, avoiding unstable adversarial minimax dynamics",
      "Diffusion models require a discriminator network competing with a generator",
      "GANs cannot generate images with color",
      "Diffusion models train in 1 single forward pass without optimization"
    ],
    correctAnswer: "Diffusion models learn to invert a gradual forward Gaussian noise corruption process step-by-step via score matching, avoiding unstable adversarial minimax dynamics",
    explanation: "GANs suffer from mode collapse and training instability due to delicate minimax game equilibria. Diffusion models optimize stable mean squared error objectives predicting added noise across discrete timesteps.",
    points: 30
  },
  {
    id: "aiml-hard-004",
    category: "AI & Machine Learning",
    difficulty: "Hard",
    topic: "LLM Post-Training",
    question: "How does Direct Preference Optimization (DPO) simplify LLM alignment compared to classic RLHF with PPO?",
    options: [
      "DPO mathematically derives a closed-form substitution that directly optimizes the policy on preferred vs dispreferred pairs, eliminating the need to train a separate reward model or run unstable RL loops",
      "DPO uses supervised learning on random internet scraped text",
      "DPO removes the need for human preference data",
      "DPO only works on models with fewer than 100 million parameters"
    ],
    correctAnswer: "DPO mathematically derives a closed-form substitution that directly optimizes the policy on preferred vs dispreferred pairs, eliminating the need to train a separate reward model or run unstable RL loops",
    explanation: "DPO shows the optimal policy under the Bradley-Terry preference model can be solved implicitly. A simple binary cross-entropy loss trains the LLM directly on chosen vs rejected responses without training a reward model or PPO hyperparameter tuning.",
    points: 30
  },
  {
    id: "aiml-hard-005",
    category: "AI & Machine Learning",
    difficulty: "Hard",
    topic: "Evaluation Metrics",
    question: "What does the Area Under the ROC Curve (AUC-ROC) quantify about a probabilistic binary classifier?",
    options: [
      "The probability that the model will rank a randomly chosen positive instance higher than a randomly chosen negative instance",
      "The accuracy of the model when the decision threshold is set strictly to 0.5",
      "The percentage of true negative predictions in the training set",
      "The average execution time per inference request"
    ],
    correctAnswer: "The probability that the model will rank a randomly chosen positive instance higher than a randomly chosen negative instance",
    explanation: "The ROC curve plots True Positive Rate vs False Positive Rate across all possible discrimination thresholds. AUC-ROC is equivalent to the Wilcoxon-Mann-Whitney statistic, measuring ranking discrimination ability across thresholds.",
    points: 30
  }
];
