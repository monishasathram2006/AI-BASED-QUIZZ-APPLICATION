// Real, hand-authored coding challenges. Only JavaScript challenges can
// actually execute in-browser (via src/utils/codeRunner.js, a Web Worker).
// Every other language shows the full problem (description/examples/
// starter code) but is honest that "Submit" requires a backend execution
// service — no execution is faked.
export const codingChallenges = [
  // ---- JavaScript (real in-browser execution) ----
  {
    id: 'code-js-001',
    language: 'javascript',
    title: 'Reverse a String',
    difficulty: 'Easy',
    timeLimitSeconds: 60,
    description: 'Given a string, return the reversed string.',
    examples: [{ input: 'hello', output: 'olleh' }],
    starterCode: 'function solve(input) {\n  // input is a string\n  return input;\n}',
    testCases: [
      { input: 'hello', expectedOutput: 'olleh' },
      { input: 'JS', expectedOutput: 'SJ' },
      { input: 'a', expectedOutput: 'a' },
    ],
  },
  {
    id: 'code-js-002',
    language: 'javascript',
    title: 'Sum of an Array',
    difficulty: 'Easy',
    timeLimitSeconds: 60,
    description: 'Given an array of numbers, return their sum.',
    examples: [{ input: '[1, 2, 3]', output: '6' }],
    starterCode: 'function solve(input) {\n  // input is an array of numbers\n  return 0;\n}',
    testCases: [
      { input: [1, 2, 3], expectedOutput: 6 },
      { input: [], expectedOutput: 0 },
      { input: [5, -2, 3], expectedOutput: 6 },
    ],
  },
  {
    id: 'code-js-003',
    language: 'javascript',
    title: 'Find the Maximum',
    difficulty: 'Medium',
    timeLimitSeconds: 90,
    description: 'Given a non-empty array of numbers, return the largest number.',
    examples: [{ input: '[3, 1, 4, 1, 5, 9]', output: '9' }],
    starterCode: 'function solve(input) {\n  // input is a non-empty array of numbers\n  return input[0];\n}',
    testCases: [
      { input: [3, 1, 4, 1, 5, 9, 2, 6], expectedOutput: 9 },
      { input: [-5, -1, -10], expectedOutput: -1 },
      { input: [7], expectedOutput: 7 },
    ],
  },

  // ---- Python (backend execution required) ----
  {
    id: 'code-python-001',
    language: 'python',
    title: 'Reverse a String',
    difficulty: 'Easy',
    timeLimitSeconds: 60,
    description: 'Given a string, return the reversed string.',
    examples: [{ input: 'hello', output: 'olleh' }],
    starterCode: 'def solve(input):\n    # input is a string\n    return input',
    testCases: [
      { input: 'hello', expectedOutput: 'olleh' },
      { input: 'python', expectedOutput: 'nohtyp' },
    ],
  },
  {
    id: 'code-python-002',
    language: 'python',
    title: 'Check Palindrome',
    difficulty: 'Medium',
    timeLimitSeconds: 90,
    description: 'Given a string, return True if it reads the same forwards and backwards, otherwise False.',
    examples: [{ input: 'madam', output: 'True' }, { input: 'hello', output: 'False' }],
    starterCode: 'def solve(input):\n    # input is a string\n    return input == input[::-1]',
    testCases: [
      { input: 'madam', expectedOutput: true },
      { input: 'hello', expectedOutput: false },
    ],
  },

  // ---- C (backend execution required) ----
  {
    id: 'code-c-001',
    language: 'c',
    title: 'Sum of Array Elements',
    difficulty: 'Easy',
    timeLimitSeconds: 90,
    description: 'Given an array of integers and its size, return the sum of all elements.',
    examples: [{ input: '[1, 2, 3, 4], n=4', output: '10' }],
    starterCode: 'int solve(int arr[], int n) {\n    int sum = 0;\n    // TODO: sum the elements\n    return sum;\n}',
    testCases: [
      { input: '[1, 2, 3, 4]', expectedOutput: 10 },
      { input: '[5, -5, 10]', expectedOutput: 10 },
    ],
  },
  {
    id: 'code-c-002',
    language: 'c',
    title: 'Find Factorial',
    difficulty: 'Medium',
    timeLimitSeconds: 90,
    description: 'Given a non-negative integer n, return n! (n factorial).',
    examples: [{ input: '5', output: '120' }],
    starterCode: 'long solve(int n) {\n    long result = 1;\n    // TODO: compute n factorial\n    return result;\n}',
    testCases: [
      { input: 5, expectedOutput: 120 },
      { input: 0, expectedOutput: 1 },
    ],
  },

  // ---- C++ (backend execution required) ----
  {
    id: 'code-cpp-001',
    language: 'cpp',
    title: 'Reverse a Vector',
    difficulty: 'Easy',
    timeLimitSeconds: 90,
    description: 'Given a vector of integers, return it reversed.',
    examples: [{ input: '[1, 2, 3]', output: '[3, 2, 1]' }],
    starterCode: 'vector<int> solve(vector<int> input) {\n    // TODO: reverse the vector\n    return input;\n}',
    testCases: [
      { input: [1, 2, 3], expectedOutput: [3, 2, 1] },
      { input: [4, 5], expectedOutput: [5, 4] },
    ],
  },
  {
    id: 'code-cpp-002',
    language: 'cpp',
    title: 'Count Vowels',
    difficulty: 'Medium',
    timeLimitSeconds: 90,
    description: 'Given a string, return the number of vowels (a, e, i, o, u) it contains.',
    examples: [{ input: 'hello world', output: '3' }],
    starterCode: 'int solve(string input) {\n    int count = 0;\n    // TODO: count the vowels\n    return count;\n}',
    testCases: [
      { input: 'hello world', expectedOutput: 3 },
      { input: 'xyz', expectedOutput: 0 },
    ],
  },

  // ---- Java (backend execution required) ----
  {
    id: 'code-java-001',
    language: 'java',
    title: 'Find the Maximum',
    difficulty: 'Easy',
    timeLimitSeconds: 90,
    description: 'Given an array of integers, return the largest value.',
    examples: [{ input: '[3, 7, 2, 9, 4]', output: '9' }],
    starterCode: 'static int solve(int[] arr) {\n    int max = arr[0];\n    // TODO: find the maximum\n    return max;\n}',
    testCases: [
      { input: [3, 7, 2, 9, 4], expectedOutput: 9 },
      { input: [-1, -5, -2], expectedOutput: -1 },
    ],
  },
  {
    id: 'code-java-002',
    language: 'java',
    title: 'Check Prime Number',
    difficulty: 'Medium',
    timeLimitSeconds: 90,
    description: 'Given an integer n, return true if it is prime, otherwise false.',
    examples: [{ input: '7', output: 'true' }, { input: '8', output: 'false' }],
    starterCode: 'static boolean solve(int n) {\n    // TODO: check primality\n    return false;\n}',
    testCases: [
      { input: 7, expectedOutput: true },
      { input: 8, expectedOutput: false },
    ],
  },

  // ---- SQL (backend execution required) ----
  {
    id: 'code-sql-001',
    language: 'sql',
    title: 'Employees Older Than 30',
    difficulty: 'Easy',
    timeLimitSeconds: 90,
    description: 'Given an Employees table with columns (id, name, age, department), write a query that selects the name and age of every employee older than 30.',
    examples: [{ input: 'Employees(id, name, age, department)', output: 'name, age WHERE age > 30' }],
    starterCode: 'SELECT name, age\nFROM Employees\n-- TODO: add the filter condition\n;',
    testCases: [
      { input: 'Employees table', expectedOutput: 'Rows where age > 30' },
    ],
  },
  {
    id: 'code-sql-002',
    language: 'sql',
    title: 'Second Highest Salary',
    difficulty: 'Medium',
    timeLimitSeconds: 120,
    description: 'Given an Employees table with columns (id, name, salary), write a query that returns the second highest distinct salary.',
    examples: [{ input: 'Employees(id, name, salary)', output: 'The second highest distinct salary value' }],
    starterCode: 'SELECT DISTINCT salary\nFROM Employees\nORDER BY salary DESC\n-- TODO: limit/offset to the second row\n;',
    testCases: [
      { input: 'Employees table', expectedOutput: 'Second highest distinct salary' },
    ],
  },
];

export function getChallengesByLanguage(language) {
  return codingChallenges.filter((c) => c.language === language);
}

export const CODING_LANGUAGES = ['javascript', 'python', 'c', 'cpp', 'java', 'sql'];
export const CODING_LANGUAGE_LABELS = { javascript: 'JavaScript', python: 'Python', c: 'C', cpp: 'C++', java: 'Java', sql: 'SQL' };
