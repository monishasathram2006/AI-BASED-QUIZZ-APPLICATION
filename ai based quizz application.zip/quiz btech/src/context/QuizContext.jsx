import { createContext, useCallback, useEffect, useReducer } from 'react';
import { readLocalStorage, writeLocalStorage, removeLocalStorage } from '../hooks/useLocalStorage.js';

export const QuizContext = createContext(null);

const SESSION_KEY = 'codeprep_quiz_session';

const initialState = {
  status: 'idle', // idle | active | submitted
  categorySlug: null,
  categoryName: null,
  difficultyParam: null, // easy | medium | hard | mixed
  difficultyLabel: null, // Easy | Medium | Hard | Mixed
  questions: [],
  currentIndex: 0,
  answers: {},
  checked: {},
  remainingSeconds: 0,
  totalSeconds: 0,
  startedAt: null,
};

function reducer(state, action) {
  switch (action.type) {
    case 'START_QUIZ': {
      const { categorySlug, categoryName, difficultyParam, difficultyLabel, questions, totalSeconds } = action.payload;
      return {
        ...initialState,
        status: 'active',
        categorySlug,
        categoryName,
        difficultyParam,
        difficultyLabel,
        questions,
        remainingSeconds: totalSeconds,
        totalSeconds,
        startedAt: new Date().toISOString(),
      };
    }
    case 'RESTORE':
      return action.payload;
    case 'SELECT_ANSWER':
      return {
        ...state,
        answers: { ...state.answers, [action.payload.questionId]: action.payload.option },
      };
    case 'CHECK_ANSWER':
      return {
        ...state,
        checked: { ...state.checked, [action.payload.questionId]: true },
      };
    case 'GO_TO': {
      const idx = Math.max(0, Math.min(state.questions.length - 1, action.payload));
      return { ...state, currentIndex: idx };
    }
    case 'NEXT':
      return { ...state, currentIndex: Math.min(state.questions.length - 1, state.currentIndex + 1) };
    case 'PREV':
      return { ...state, currentIndex: Math.max(0, state.currentIndex - 1) };
    case 'TICK':
      return { ...state, remainingSeconds: Math.max(0, state.remainingSeconds - 1) };
    case 'SUBMIT':
      return { ...state, status: 'submitted' };
    case 'RESET':
      return initialState;
    default:
      return state;
  }
}

export function QuizProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState, (init) => {
    const stored = readLocalStorage(SESSION_KEY, null);
    if (stored && stored.status === 'active') return stored;
    return init;
  });

  // Persist the active session on every change so a page refresh mid-quiz
  // can resume from where the user left off (#30). Submitted/idle sessions
  // are cleared so a stale attempt never resurfaces as "in progress".
  useEffect(() => {
    if (state.status === 'active') {
      writeLocalStorage(SESSION_KEY, state);
    } else {
      removeLocalStorage(SESSION_KEY);
    }
  }, [state]);

  const startQuiz = useCallback((payload) => dispatch({ type: 'START_QUIZ', payload }), []);
  const selectAnswer = useCallback((questionId, option) =>
    dispatch({ type: 'SELECT_ANSWER', payload: { questionId, option } }), []);
  const checkAnswer = useCallback((questionId) =>
    dispatch({ type: 'CHECK_ANSWER', payload: { questionId } }), []);
  const goTo = useCallback((index) => dispatch({ type: 'GO_TO', payload: index }), []);
  const next = useCallback(() => dispatch({ type: 'NEXT' }), []);
  const prev = useCallback(() => dispatch({ type: 'PREV' }), []);
  const tick = useCallback(() => dispatch({ type: 'TICK' }), []);
  const submit = useCallback(() => dispatch({ type: 'SUBMIT' }), []);
  const reset = useCallback(() => dispatch({ type: 'RESET' }), []);

  const value = { state, startQuiz, selectAnswer, checkAnswer, goTo, next, prev, tick, submit, reset };

  return <QuizContext.Provider value={value}>{children}</QuizContext.Provider>;
}
